
import { GoogleGenAI } from "@google/genai";
import { Block } from "../types";

// Always initialize the client with process.env.API_KEY using a named parameter.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const GeminiService = {
  async completeText(currentText: string, context: string = ''): Promise<string> {
    try {
      // Use 'gemini-3-flash-preview' for basic text tasks.
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `You are a helpful writing assistant. Continue the following text naturally. Keep formatting minimal. Context: ${context}. Text to continue: "${currentText}"`,
      });
      // Use the .text property to access generated content.
      return response.text || "";
    } catch (error) {
      console.error("Gemini API Error", error);
      throw error;
    }
  },

  async summarizeNote(blocks: Block[]): Promise<string> {
    const fullText = blocks.map(b => b.content).join('\n');

    try {
      // Use 'gemini-3-flash-preview' for basic text tasks.
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Summarize the following note into 3 bullet points:\n\n${fullText}`,
      });
      // Use the .text property to access generated content.
      return response.text || "";
    } catch (error) {
      console.error("Gemini API Error", error);
      throw error;
    }
  }
};
