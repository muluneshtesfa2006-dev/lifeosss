
import { Note, Folder, DEFAULT_FOLDERS, Routine, RoutineLog, UserStats, DailyQuest, Task, JournalEntry, Block, BlockType, Plan, PlanPhase, UserIdentity, CanvasBoard, CanvasObject, CanvasConnection, NotebookData, NotebookBlock, AutomationRule, Wallet, FinanceTransaction, FinanceBudget, FinancialGoal, RecurringFrequency } from '../types';

// Update keys to force re-seeding with new data
const STORAGE_KEY_NOTES = 'lifeos_notes_db_v5_massive';
const STORAGE_KEY_FOLDERS = 'lifeos_folders_db_v1';
const STORAGE_KEY_ROUTINES = 'lifeos_routines_db_v5_massive'; 
const STORAGE_KEY_TASKS = 'lifeos_tasks_db_v5_massive'; 
const STORAGE_KEY_LOGS = 'lifeos_logs_db_v5_massive';
const STORAGE_KEY_STATS = 'lifeos_stats_db_v5_massive'; 
const STORAGE_KEY_JOURNAL = 'lifeos_journal_db_v5_massive'; 
const STORAGE_KEY_PLANS = 'lifeos_plans_db_v5_massive';
const STORAGE_KEY_USER = 'lifeos_user_identity_v2'; 
const STORAGE_KEY_QUESTS = 'lifeos_quests_db_v1';
const STORAGE_KEY_BOARDS = 'lifeos_boards_collection_v5_massive'; 
const STORAGE_KEY_WALLETS = 'lifeos_finance_wallets_v2';
const STORAGE_KEY_TRANSACTIONS = 'lifeos_finance_transactions_v2';
const STORAGE_KEY_BUDGETS = 'lifeos_finance_budgets_v2';
const STORAGE_KEY_GOALS = 'lifeos_finance_goals_v2';

const generateId = () => Math.random().toString(36).substr(2, 9);

// --- CACHE LAYER (PERFORMANCE ENGINE) ---
// This prevents expensive JSON.parse calls on every render
const cache: Record<string, any> = {};

const getFromCache = <T>(key: string, defaultVal: T): T => {
    if (cache[key]) return cache[key] as T;
    const raw = localStorage.getItem(key);
    if (!raw) return defaultVal;
    try {
        const parsed = JSON.parse(raw);
        cache[key] = parsed;
        return parsed;
    } catch (e) {
        return defaultVal;
    }
};

const saveToCache = <T>(key: string, data: T) => {
    cache[key] = data;
    // We can debounce the actual write if needed, but for now direct write is safer for consistency
    localStorage.setItem(key, JSON.stringify(data));
};

// --- GENERATOR HELPERS ---
const LOREM_TITLES = [
    "Project Alpha Synthesis", "Quantum Neural Link", "Market Penetration Strategy", "Q3 Financial Audit", "Hypertrophy Phase 4",
    "Dopamine Detox Protocol", "Deep Work Session", "Client Acquisition Flow", "Backend Architecture Refactor", "UI/UX Overhaul",
    "Meditation Insight", "Journal of Solitude", "The Stoic Mindset", "Investment Portfolio Rebalance", "Weekly Review",
    "Monthly Goal Setting", "Yearly Retrospective", "Book Summary: Atomic Habits", "Meeting Notes: Team Sync", "Idea: AI Assistant"
];

const LOREM_PHRASES = [
    "Focus on the essential.", "Minimize friction.", "Execute with intent.", "Optimize for latency.", "Scale horizontally.",
    "Refactor the core logic.", "Align with north star.", "Synergize deliverables.", "Leverage agile methodologies.", "Shift the paradigm.",
    "Sustainable growth trajectory.", "High-leverage activities.", "Deep work blocks.", "Cognitive load management.", "Circadian rhythm synchronization."
];

const getRandom = <T>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
const getRandomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
const getRandomDate = (start: Date, end: Date) => new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime())).toISOString().split('T')[0];

const generateText = (sentences: number) => {
    let text = "";
    for(let i=0; i<sentences; i++) {
        text += getRandom(LOREM_PHRASES) + " ";
    }
    return text.trim();
};

const generateBlocks = (count: number): Block[] => {
    return Array.from({length: count}).map(() => ({
        id: generateId(),
        type: Math.random() > 0.8 ? 'h2' : Math.random() > 0.7 ? 'checklist' : 'body',
        content: generateText(getRandomInt(5, 20)),
        checked: Math.random() > 0.5
    }));
};

// --- SEEDING LOGIC ---

export const StorageService = {
  init: () => {
    const hasData = localStorage.getItem(STORAGE_KEY_TASKS);
    if (!hasData) {
        console.log("Seeding massive dataset...");
        StorageService.seedData();
        StorageService.seedFinanceData();
    }
    // Pre-warm cache
    StorageService.getTasks();
    StorageService.getRoutines();
    StorageService.getNotes();
  },

  seedFinanceData: () => {
      const wallets: Wallet[] = [
          { id: 'w1', name: 'Main Checking', type: 'BANK', balance: 8420.50, currency: 'USD', color: '#3B82F6', icon: 'Landmark', accountNumber: '4921' },
          { id: 'w2', name: 'Cash Wallet', type: 'CASH', balance: 340.00, currency: 'USD', color: '#10B981', icon: 'Banknote' },
          { id: 'w3', name: 'Cold Storage', type: 'CRYPTO', balance: 18500.00, currency: 'USD', color: '#F59E0B', icon: 'Bitcoin' },
      ];
      saveToCache(STORAGE_KEY_WALLETS, wallets);
  },

  seedData: () => {
    const now = new Date();
    const twoYearsAgo = new Date(); twoYearsAgo.setFullYear(now.getFullYear() - 2);
    
    // 1. ROUTINES (15 Definitions)
    const routineDefs: Routine[] = [
        { id: 'r1', title: 'Deep Work Block', description: '90m No Distraction', time: '08:00', category: 'Mental', xpReward: 100, frequency: 'Daily' },
        { id: 'r2', title: 'Morning Hydration', description: '1L Water + Electrolytes', time: '07:00', category: 'Physical', xpReward: 20, frequency: 'Daily' },
        { id: 'r3', title: 'Cold Plunge', description: '3 mins at 45F', time: '07:15', category: 'Physical', xpReward: 50, frequency: 'Daily' },
        { id: 'r4', title: 'Meditation', description: 'Vipassana 20m', time: '07:30', category: 'Spiritual', xpReward: 40, frequency: 'Daily' },
        { id: 'r5', title: 'Journaling', description: 'Brain Dump & Gratitude', time: '21:00', category: 'Mental', xpReward: 30, frequency: 'Daily' },
        { id: 'r6', title: 'Reading', description: '20 Pages Non-fiction', time: '21:30', category: 'Knowledge', xpReward: 50, frequency: 'Daily' },
        { id: 'r7', title: 'Gym: Hypertrophy', description: 'PPL Split', time: '17:00', category: 'Physical', xpReward: 80, frequency: 'Daily' },
        { id: 'r8', title: 'Weekly Review', description: 'GTD Review', time: 'Sunday', category: 'Mental', xpReward: 200, frequency: 'Weekly' },
        { id: 'r9', title: 'Financial Audit', description: 'Check Burn Rate', time: 'Friday', category: 'Financial', xpReward: 150, frequency: 'Weekly' },
        { id: 'r10', title: 'Meal Prep', description: 'Cook for 3 days', time: 'Sunday', category: 'Physical', xpReward: 100, frequency: 'Weekly' },
        { id: 'r11', title: 'Network Sync', description: 'Call 1 friend', time: 'Saturday', category: 'Social', xpReward: 60, frequency: 'Weekly' },
        { id: 'r12', title: 'Goal Review', description: 'OKR Check-in', time: '1st', category: 'Career', xpReward: 300, frequency: 'Monthly' },
        { id: 'r13', title: 'Digital Declutter', description: 'Empty Inbox/Desktop', time: '15th', category: 'Mental', xpReward: 100, frequency: 'Monthly' },
        { id: 'r14', title: 'Fast', description: '24h Water Fast', time: '1st', category: 'Physical', xpReward: 250, frequency: 'Monthly' },
        { id: 'r15', title: 'Learning Sprint', description: 'Complete 1 Course Module', time: '20th', category: 'Knowledge', xpReward: 150, frequency: 'Monthly' }
    ];
    saveToCache(STORAGE_KEY_ROUTINES, routineDefs);

    // 2. ROUTINE LOGS (Last 100 Days)
    const logs: RoutineLog[] = [];
    for (let i = 0; i < 100; i++) {
        const d = new Date(); d.setDate(d.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        
        routineDefs.forEach(r => {
            if (r.frequency === 'Daily' && Math.random() > 0.3) {
                logs.push({ date: dateStr, routineId: r.id, completed: true });
            }
            if (r.frequency === 'Weekly' && d.getDay() === 0 && Math.random() > 0.2) {
                logs.push({ date: dateStr, routineId: r.id, completed: true });
            }
        });
    }
    saveToCache(STORAGE_KEY_LOGS, logs);

    // 3. TASKS (Last 2 years, heavier in last 200 days)
    const tasks: Task[] = [];
    const categories = ['Physical', 'Mental', 'Career', 'Financial', 'Social'];
    const priorities = ['High', 'Medium', 'Low'];
    
    for (let i = 0; i < 730; i++) { // 2 Years back
        const d = new Date(); d.setDate(d.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        const density = i < 200 ? getRandomInt(2, 6) : getRandomInt(0, 2);
        
        for (let j = 0; j < density; j++) {
            tasks.push({
                id: generateId(),
                title: getRandom(LOREM_TITLES),
                description: generateText(2),
                completed: i > 0 ? (Math.random() > 0.2) : false, 
                date: dateStr,
                createdAt: d.getTime(),
                category: getRandom(categories) as any,
                priority: getRandom(priorities) as any,
                status: i > 0 ? (Math.random() > 0.2 ? 'done' : 'todo') : 'todo',
                subtasks: [
                    { id: generateId(), title: 'Phase 1 Init', completed: true },
                    { id: generateId(), title: 'Phase 2 Execute', completed: Math.random() > 0.5 }
                ]
            });
        }
    }
    for (let i = 1; i <= 30; i++) {
        const d = new Date(); d.setDate(d.getDate() + i);
        tasks.push({
            id: generateId(), title: `Future Task ${i}`, completed: false, date: d.toISOString().split('T')[0], createdAt: Date.now(), category: 'Career', priority: 'Medium', status: 'todo'
        });
    }
    saveToCache(STORAGE_KEY_TASKS, tasks);

    // 4. PLANS
    const plans: Plan[] = [];
    const createPlan = (prio: 'High'|'Medium'|'Low', count: number) => {
        for(let i=0; i<count; i++) {
            const start = getRandomDate(twoYearsAgo, now);
            const end = new Date(new Date(start).getTime() + getRandomInt(30, 365) * 86400000).toISOString().split('T')[0];
            plans.push({
                id: generateId(),
                title: `${prio} Priority Protocol ${i+1}: ${getRandom(LOREM_TITLES)}`,
                description: generateText(5),
                category: getRandom(categories) as any,
                startDate: start,
                endDate: end,
                status: Math.random() > 0.5 ? 'Active' : 'Completed',
                createdAt: start,
                xpReward: prio === 'High' ? 5000 : prio === 'Medium' ? 2000 : 500,
                priority: prio,
                phases: [
                    { 
                        id: generateId(), title: 'Phase 1: Foundation', type: 'TIMELINE', width: 'full', startDate: start, endDate: end, color: '#A855F7',
                        milestones: [
                            { id: generateId(), title: 'Research', isCompleted: true, status: 'done' },
                            { id: generateId(), title: 'Development', isCompleted: Math.random() > 0.5, status: 'doing' }
                        ]
                    },
                    {
                        id: generateId(), title: 'Resource Allocation', type: 'BUDGET', width: 'half', startDate: start, endDate: end, color: '#30D158', budgetLimit: getRandomInt(1000, 50000),
                        milestones: []
                    },
                    {
                        id: generateId(), title: 'Execution Log', type: 'TODO', width: 'half', startDate: start, endDate: end, color: '#3B82F6',
                        milestones: [{id: generateId(), title: 'Execute', isCompleted: false, status: 'todo'}]
                    }
                ]
            });
        }
    };
    createPlan('High', 50);
    createPlan('Medium', 30);
    createPlan('Low', 3);
    saveToCache(STORAGE_KEY_PLANS, plans);

    // 5. NOTES
    const notes: Note[] = [];
    for(let i=0; i<110; i++) {
        const d = getRandomDate(twoYearsAgo, now);
        notes.push({
            id: generateId(),
            title: getRandom(LOREM_TITLES) + ` (Vol ${i})`,
            folderId: Math.random() > 0.7 ? 'work' : 'personal',
            blocks: generateBlocks(getRandomInt(3, 8)),
            updatedAt: new Date(d).toISOString(),
            createdAt: new Date(d).toISOString(),
            pinned: Math.random() > 0.95
        });
    }
    saveToCache(STORAGE_KEY_NOTES, notes);

    // 6. JOURNAL
    const entries: JournalEntry[] = [];
    for(let i=0; i<365; i+=2) {
        const d = new Date(); d.setDate(d.getDate() - i);
        entries.push({
            id: generateId(),
            date: d.toISOString().split('T')[0],
            title: `Log Day -${i}: ${getRandom(LOREM_TITLES)}`,
            blocks: generateBlocks(getRandomInt(2, 5)),
            mood: getRandomInt(1, 5),
            tags: [getRandom(['Focus', 'Grind', 'Rest']), getRandom(['Deep', 'Shallow', 'Flow'])],
            timeSpent: getRandomInt(600, 7200),
            updatedAt: d.toISOString()
        });
    }
    saveToCache(STORAGE_KEY_JOURNAL, entries);

    // 7. CANVAS
    const canvasObjects: CanvasObject[] = [];
    const connections: CanvasConnection[] = [];
    for(let i=0; i<60; i++) {
        const x = getRandomInt(-2000, 2000);
        const y = getRandomInt(-2000, 2000);
        const id = generateId();
        canvasObjects.push({
            id, type: Math.random() > 0.8 ? 'STICKY' : Math.random() > 0.5 ? 'SHAPE' : 'TEXT',
            x, y, width: 200, height: 150, text: getRandom(LOREM_TITLES), zIndex: i,
            backgroundColor: getRandom(['#1C1C1E', '#FCD34D', '#34D399', '#60A5FA', '#A855F7']),
            shapeType: 'ROUNDED'
        });
        if (i > 0 && Math.random() > 0.6) {
            connections.push({
                id: generateId(), from: canvasObjects[getRandomInt(0, i-1)].id, to: id,
                type: 'CURVED', color: '#555', endArrow: true
            });
        }
    }
    const board: CanvasBoard = {
        id: generateId(), title: 'Master Mind Map', objects: canvasObjects, connections: connections,
        viewport: { x: 0, y: 0, zoom: 0.5 }, version: 1, lastModified: new Date().toISOString()
    };
    saveToCache(STORAGE_KEY_BOARDS, [board]);
  },

  // --- CRUD HELPERS (OPTIMIZED WITH CACHE) ---
  getUser: (): UserIdentity | null => getFromCache(STORAGE_KEY_USER, null),
  saveUser: (u: UserIdentity) => saveToCache(STORAGE_KEY_USER, u),
  logout: () => { localStorage.removeItem(STORAGE_KEY_USER); delete cache[STORAGE_KEY_USER]; },
  
  getNotes: (): Note[] => getFromCache(STORAGE_KEY_NOTES, []),
  saveNotes: (n: Note[]) => saveToCache(STORAGE_KEY_NOTES, n),
  createNote: (fid: string = 'all'): Note => ({ id: generateId(), title: '', folderId: fid, pinned: false, updatedAt: new Date().toISOString(), createdAt: new Date().toISOString(), blocks: [{ id: generateId(), type: 'body', content: '' }] }),
  
  getRoutines: (): Routine[] => getFromCache(STORAGE_KEY_ROUTINES, []),
  saveRoutines: (r: Routine[]) => saveToCache(STORAGE_KEY_ROUTINES, r),
  
  getTasks: (): Task[] => getFromCache(STORAGE_KEY_TASKS, []),
  saveTasks: (t: Task[]) => saveToCache(STORAGE_KEY_TASKS, t),
  
  getLogs: (): RoutineLog[] => getFromCache(STORAGE_KEY_LOGS, []),
  saveLog: (l: RoutineLog) => {
      const logs = StorageService.getLogs().filter(x => !(x.date === l.date && x.routineId === l.routineId));
      logs.push(l);
      saveToCache(STORAGE_KEY_LOGS, logs);
  },

  getStats: (): UserStats => getFromCache(STORAGE_KEY_STATS, {level:1,currentXp:0,nextLevelXp:1000,streak:0,attributes:{physical:0,mental:0,knowledge:0,spiritual:0,social:0}}),
  saveStats: (s: UserStats) => saveToCache(STORAGE_KEY_STATS, s),

  getJournalEntries: (): JournalEntry[] => getFromCache(STORAGE_KEY_JOURNAL, []),
  saveJournalEntry: (e: JournalEntry) => {
      const entries = StorageService.getJournalEntries();
      const idx = entries.findIndex(x => x.id === e.id);
      if (idx >= 0) entries[idx] = e; else entries.push(e);
      saveToCache(STORAGE_KEY_JOURNAL, entries);
  },
  createJournalEntry: (d: string): JournalEntry => ({ id: generateId(), date: d, blocks: [{ id: generateId(), type: 'body', content: '' }], mood: 3, tags: [], updatedAt: new Date().toISOString() }),

  getPlans: (): Plan[] => getFromCache(STORAGE_KEY_PLANS, []),
  savePlans: (p: Plan[]) => saveToCache(STORAGE_KEY_PLANS, p),
  awardPlanXp: (xp: number) => {
      const s = StorageService.getStats();
      s.currentXp += xp;
      if (s.currentXp >= s.nextLevelXp) { s.level++; s.currentXp -= s.nextLevelXp; s.nextLevelXp = Math.floor(s.nextLevelXp * 1.2); }
      StorageService.saveStats(s);
  },

  getWhiteboard: (): CanvasBoard => {
      const b = getFromCache<CanvasBoard[]>(STORAGE_KEY_BOARDS, []);
      if (b.length) return b[0];
      return { id: generateId(), title: 'Main Board', objects: [], connections: [], viewport: {x:0,y:0,zoom:1}, version: 1, lastModified: new Date().toISOString() };
  },
  saveBoard: (b: CanvasBoard) => {
      saveToCache(STORAGE_KEY_BOARDS, [b]);
  },

  getFolders: (): Folder[] => getFromCache(STORAGE_KEY_FOLDERS, DEFAULT_FOLDERS),

  getWallets: (): Wallet[] => getFromCache(STORAGE_KEY_WALLETS, []),
  saveWallets: (w: Wallet[]) => saveToCache(STORAGE_KEY_WALLETS, w),
  
  getTransactions: (): FinanceTransaction[] => getFromCache(STORAGE_KEY_TRANSACTIONS, []),
  saveTransactions: (t: FinanceTransaction[]) => saveToCache(STORAGE_KEY_TRANSACTIONS, t),
  
  getBudgets: (): FinanceBudget[] => getFromCache(STORAGE_KEY_BUDGETS, []),
  saveBudgets: (b: FinanceBudget[]) => saveToCache(STORAGE_KEY_BUDGETS, b),
  
  getGoals: (): FinancialGoal[] => getFromCache(STORAGE_KEY_GOALS, []),
  saveGoals: (g: FinancialGoal[]) => saveToCache(STORAGE_KEY_GOALS, g),
};
