
import React, { useState, useEffect, useRef } from 'react';
import { StorageService } from '../services/storageService';
import { JournalEntry, Block } from '../types';
import { DrawingCanvas } from './DrawingCanvas';
import { 
    ChevronLeft, Calendar, Camera, X, Save, MoreHorizontal,
    Bold as BoldIcon, Italic as ItalicIcon, Underline as UnderlineIcon, 
    TrendingUp, FileText, Activity, Sparkles, PenTool, History, Image as ImageIcon,
    Mic, MapPin, Music, Search, Filter, Plus, Bookmark, XCircle, ArrowUp, Wand2,
    Settings, Lock, Share, BarChart3, List, Edit3, Brain, Target, CalendarDays, Flame,
    Zap, Trophy, CheckSquare, Tag, Trash2, Check, Timer, Play, Pause, RotateCcw,
    BrainCircuit, Network, Layers, Send, Smartphone, CheckCircle, Infinity,
    Shield, Battery, Wifi, Award, Hourglass, Fingerprint, Disc, Lightbulb, Database,
    Wind, Terminal, Cpu, Radio, BarChart, HelpCircle, ChevronRight, Clock, Link as LinkIcon,
    Ghost, Waves, Cloud, Moon, Sun, MessageSquare
} from 'lucide-react';
import { 
    LineChart, Line, XAxis, Tooltip, ResponsiveContainer, AreaChart, Area, CartesianGrid, PieChart, Pie, Cell, RadialBarChart, RadialBar, Legend, BarChart as ReBarChart, Bar, YAxis
} from 'recharts';

export const Journal: React.FC = () => {
    const [view, setView] = useState<'LIST' | 'EDITOR' | 'INSIGHTS' | 'PRODUCTIVITY' | 'CALENDAR'>('LIST');
    const [entries, setEntries] = useState<JournalEntry[]>([]);
    const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null);
    const [showSuggestions, setShowSuggestions] = useState(false);
    
    useEffect(() => {
        setEntries(StorageService.getJournalEntries());
    }, []);

    const handleSaveEntry = (entry: JournalEntry) => {
        StorageService.saveJournalEntry(entry);
        setEntries(StorageService.getJournalEntries());
        setView('LIST');
        setSelectedEntry(null);
    };

    const handleQuickSave = (text: string) => {
        const newEntry = StorageService.createJournalEntry(new Date().toISOString().split('T')[0]);
        newEntry.blocks[0].content = text;
        StorageService.saveJournalEntry(newEntry);
        setEntries(StorageService.getJournalEntries());
    };

    const handleCreateNew = () => {
        setShowSuggestions(true);
    };

    const startWriting = () => {
        setShowSuggestions(false);
        const newEntry = StorageService.createJournalEntry(new Date().toISOString().split('T')[0]);
        setSelectedEntry(newEntry);
        setView('EDITOR');
    };

    const handleEditEntry = (entry: JournalEntry) => {
        setSelectedEntry(entry);
        setView('EDITOR');
    };

    // Calculate Stats for Header
    const totalWords = entries.reduce((acc, e) => {
        const text = e.blocks.find(b => b.type === 'body')?.content.replace(/<[^>]*>?/gm, '') || '';
        return acc + (text.split(/\s+/).length || 0);
    }, 0);
    const uniqueDays = new Set(entries.map(e => e.date)).size;
    const thisYear = new Date().getFullYear();
    const entriesThisYear = entries.filter(e => new Date(e.date).getFullYear() === thisYear).length;

    return (
        <div className="flex-1 h-full bg-black text-white flex flex-col font-sans relative overflow-hidden">
            
            {/* MAIN LIST VIEW - Unified Scrolling Container */}
            {view === 'LIST' && (
                <div className="flex-1 h-full overflow-y-auto no-scrollbar relative z-10 animate-in slide-in-from-left duration-500">
                    {/* HEADER - No longer sticky, scrolls with content */}
                    <div className="px-6 pt-12 pb-4 bg-gradient-to-b from-black to-transparent">
                        <div className="flex justify-between items-center mb-6">
                            <h1 className="text-4xl font-black tracking-tight text-white">Journal</h1>
                        </div>
                        
                        {/* HERO NAVIGATION CARDS */}
                        <div className="grid grid-cols-3 gap-3 mb-6">
                            <button 
                                onClick={() => setView('PRODUCTIVITY')} 
                                className="h-28 bg-[#1C1C1E] rounded-2xl border border-white/10 flex flex-col items-center justify-center gap-2 hover:bg-ios-purple/10 hover:border-ios-purple/30 transition-all active:scale-95 group relative overflow-hidden shadow-lg"
                            >
                                <div className="absolute inset-0 bg-gradient-to-br from-ios-purple/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"/>
                                <Brain size={28} className="text-ios-purple mb-1 group-hover:scale-110 transition-transform" />
                                <span className="text-xs font-bold uppercase tracking-wider text-white">Neural</span>
                                <div className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                            </button>

                            <button 
                                onClick={() => setView('CALENDAR')} 
                                className="h-28 bg-[#1C1C1E] rounded-2xl border border-white/10 flex flex-col items-center justify-center gap-2 hover:bg-green-500/10 hover:border-green-500/30 transition-all active:scale-95 group relative overflow-hidden shadow-lg"
                            >
                                <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"/>
                                <CalendarDays size={28} className="text-green-500 mb-1 group-hover:scale-110 transition-transform" />
                                <span className="text-xs font-bold uppercase tracking-wider text-white">Calendar</span>
                            </button>

                            <button 
                                onClick={() => setView('INSIGHTS')} 
                                className="h-28 bg-[#1C1C1E] rounded-2xl border border-white/10 flex flex-col items-center justify-center gap-2 hover:bg-ios-blue/10 hover:border-ios-blue/30 transition-all active:scale-95 group relative overflow-hidden shadow-lg"
                            >
                                <div className="absolute inset-0 bg-gradient-to-br from-ios-blue/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"/>
                                <BarChart3 size={28} className="text-ios-blue mb-1 group-hover:scale-110 transition-transform" />
                                <span className="text-xs font-bold uppercase tracking-wider text-white">Insights</span>
                            </button>
                        </div>

                        {/* STATS ROW */}
                        <div className="flex justify-between items-center py-3 px-2 border-t border-b border-white/10 bg-black/20 backdrop-blur-sm rounded-xl">
                            <div className="flex flex-col items-center flex-1 border-r border-white/10">
                                <span className="text-base font-black text-ios-purple">{entriesThisYear}</span>
                                <span className="text-[9px] text-ios-textSec uppercase tracking-wider">Entries</span>
                            </div>
                            <div className="flex flex-col items-center flex-1 border-r border-white/10">
                                <span className="text-base font-black text-ios-blue">{totalWords}</span>
                                <span className="text-[9px] text-ios-textSec uppercase tracking-wider">Words</span>
                            </div>
                            <div className="flex flex-col items-center flex-1">
                                <span className="text-base font-black text-white">{uniqueDays}</span>
                                <span className="text-[9px] text-ios-textSec uppercase tracking-wider">Days</span>
                            </div>
                        </div>
                    </div>

                    {/* Entries List - Part of the same scroll container */}
                    <div className="px-4 pb-32 space-y-8">
                        {entries.length === 0 ? (
                            <div className="text-center py-20 text-white/30 flex flex-col items-center">
                                <Sparkles size={48} className="mb-4 opacity-50"/>
                                <p>Start your journey today.</p>
                            </div>
                        ) : (
                            <EntriesList entries={entries} onSelect={handleEditEntry} />
                        )}
                    </div>

                    {/* Floating Plus Button */}
                    <div className="fixed bottom-24 left-0 right-0 flex justify-center z-50 pointer-events-none">
                        <button 
                            onClick={handleCreateNew}
                            className="pointer-events-auto w-16 h-16 bg-ios-purple text-white rounded-full shadow-[0_0_40px_rgba(191,90,242,0.4)] flex items-center justify-center hover:scale-110 active:scale-95 transition-all duration-300"
                        >
                            <Plus size={32} />
                        </button>
                    </div>
                </div>
            )}

            {/* EDITOR VIEW */}
            {view === 'EDITOR' && selectedEntry && (
                <div className="absolute inset-0 z-50 bg-black animate-in slide-in-from-bottom duration-500">
                    <JournalEditor 
                        entry={selectedEntry} 
                        onClose={() => setView('LIST')} 
                        onSave={handleSaveEntry} 
                    />
                </div>
            )}

            {/* INSIGHTS VIEW */}
            {view === 'INSIGHTS' && (
                <div className="absolute inset-0 z-50 bg-black animate-in slide-in-from-right duration-500 flex flex-col h-full overflow-hidden">
                    <div className="flex-1 overflow-y-auto no-scrollbar relative">
                        <div className="px-6 pt-12 pb-4 flex items-center gap-4 border-b border-white/10 bg-black z-20">
                            <button onClick={() => setView('LIST')} className="p-2 -ml-2 text-ios-purple flex items-center gap-1 font-bold active:scale-95 transition-transform">
                                <ChevronLeft /> Back
                            </button>
                            <h2 className="text-xl font-bold ml-auto mr-auto">Insights</h2>
                            <div className="w-16"></div>
                        </div>
                        <InsightsDashboard entries={entries} />
                    </div>
                </div>
            )}

            {/* PRODUCTIVITY VIEW (NEURAL LINK REDESIGN) */}
            {view === 'PRODUCTIVITY' && (
                <div className="absolute inset-0 z-50 bg-black animate-in slide-in-from-right duration-500 flex flex-col">
                     <div className="flex-1 overflow-y-auto no-scrollbar relative">
                        <div className="px-6 pt-12 pb-4 flex items-center gap-4 border-b border-white/10 bg-black z-20">
                            <button onClick={() => setView('LIST')} className="p-2 -ml-2 text-ios-purple flex items-center gap-1 font-bold active:scale-95 transition-transform">
                                <ChevronLeft /> Back
                            </button>
                            <h2 className="text-xl font-bold ml-auto mr-auto flex items-center gap-2">
                                <Brain size={20} className="text-ios-purple"/> Neural Focus
                            </h2>
                            <div className="w-16"></div>
                        </div>
                        <ProductivityDashboard entries={entries} onQuickSave={handleQuickSave} />
                    </div>
                </div>
            )}

            {/* CALENDAR VIEW */}
            {view === 'CALENDAR' && (
                <div className="absolute inset-0 z-50 bg-black animate-in slide-in-from-right duration-500 flex flex-col">
                    <div className="flex-1 overflow-y-auto no-scrollbar relative">
                        <div className="px-6 pt-12 pb-4 flex items-center gap-4 border-b border-white/10 bg-black z-20">
                            <button onClick={() => setView('LIST')} className="p-2 -ml-2 text-ios-purple flex items-center gap-1 font-bold active:scale-95 transition-transform">
                                <ChevronLeft /> Back
                            </button>
                            <h2 className="text-xl font-bold ml-auto mr-auto flex items-center gap-2">
                                <Calendar size={20} className="text-ios-purple"/> Timeline
                            </h2>
                            <div className="w-16"></div>
                        </div>
                        <JournalCalendar entries={entries} onSelectEntry={handleEditEntry} />
                    </div>
                </div>
            )}

            {/* SUGGESTIONS SHEET */}
            {showSuggestions && (
                <div className="fixed inset-0 z-[60] flex flex-col justify-end">
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowSuggestions(false)} />
                    <div className="bg-[#1C1C1E] rounded-t-3xl p-6 relative z-10 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-500 border-t border-white/10">
                        <div className="flex justify-between items-center mb-6">
                            <button onClick={() => setShowSuggestions(false)} className="text-ios-textSec active:text-white transition-colors">Cancel</button>
                            <h3 className="font-bold text-white">New Entry</h3>
                            <button onClick={startWriting} className="text-ios-purple font-bold flex items-center gap-1 active:scale-95 transition-transform">
                                <Edit3 size={16} /> Write
                            </button>
                        </div>
                        
                        <h4 className="text-2xl font-bold text-white mb-6">Select a Moment & Write</h4>
                        
                        <div className="flex gap-1 bg-white/10 p-1 rounded-xl mb-6">
                            <button className="flex-1 py-1.5 bg-black/50 rounded-lg text-xs font-bold text-white shadow">Recommended</button>
                            <button className="flex-1 py-1.5 text-xs font-bold text-ios-textSec hover:text-white transition-colors">Recent</button>
                        </div>

                        {/* Suggestions Grid */}
                        <div className="grid grid-cols-2 gap-4 mb-8">
                             {/* Music Suggestion */}
                             <div onClick={startWriting} className="aspect-square bg-gradient-to-br from-green-900 to-black rounded-xl p-4 relative overflow-hidden group border border-white/5 cursor-pointer hover:border-white/20 active:scale-95 transition-all">
                                 <div className="absolute inset-0 flex items-center justify-center opacity-30">
                                     <Music size={80} className="text-green-500" />
                                 </div>
                                 <div className="relative z-10 flex flex-col h-full justify-between">
                                     <Music className="text-green-500 bg-black/50 p-1 rounded-full" size={24}/>
                                     <div>
                                         <p className="font-bold text-white text-sm">Afternoon Vibe</p>
                                         <p className="text-xs text-white/50">Listening to Lo-Fi</p>
                                     </div>
                                 </div>
                             </div>

                             {/* Location Suggestion */}
                             <div onClick={startWriting} className="aspect-square bg-gradient-to-br from-blue-900 to-black rounded-xl p-4 relative overflow-hidden group border border-white/5 cursor-pointer hover:border-white/20 active:scale-95 transition-all">
                                 <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=300&q=80')] bg-cover opacity-40 mix-blend-overlay"></div>
                                 <div className="relative z-10 flex flex-col h-full justify-between">
                                     <MapPin className="text-blue-500 bg-black/50 p-1 rounded-full" size={24}/>
                                     <div>
                                         <p className="font-bold text-white text-sm">Downtown Walk</p>
                                         <p className="text-xs text-white/50">San Francisco, CA</p>
                                     </div>
                                 </div>
                             </div>

                             {/* Photo Cluster */}
                             <div onClick={startWriting} className="col-span-2 bg-[#2C2C2E] rounded-xl p-4 border border-white/5 cursor-pointer hover:border-white/20 active:scale-95 transition-all">
                                 <div className="flex items-center gap-2 mb-3">
                                     <ImageIcon size={16} className="text-ios-yellow" />
                                     <span className="text-xs font-bold uppercase tracking-wider text-white/70">From Photos</span>
                                 </div>
                                 <div className="grid grid-cols-4 gap-2">
                                     <div className="aspect-square rounded-lg bg-gray-700 bg-[url('https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=150&q=80')] bg-cover"></div>
                                     <div className="aspect-square rounded-lg bg-gray-700 bg-[url('https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=150&q=80')] bg-cover"></div>
                                     <div className="aspect-square rounded-lg bg-gray-700 bg-[url('https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=150&q=80')] bg-cover"></div>
                                     <div className="aspect-square rounded-lg bg-gray-800 flex items-center justify-center text-xs font-bold text-white">+5</div>
                                 </div>
                                 <p className="mt-3 text-sm font-bold text-white">Weekend Trip to Mountains</p>
                             </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

// ... SUB-COMPONENTS ...

const formatDuration = (seconds: number) => {
    if (!seconds) return '0s';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

// ... EntriesList, ToolBtn, JournalBlockContent, JournalEditor (Existing ones, kept for structure) ...
const EntriesList: React.FC<{ entries: JournalEntry[], onSelect: (entry: JournalEntry) => void }> = ({ entries, onSelect }) => {
    const sorted = [...entries].sort((a,b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
    const grouped: Record<string, JournalEntry[]> = sorted.reduce((acc, entry) => {
        const date = new Date(entry.date);
        const key = date.toLocaleString('default', { month: 'long', year: 'numeric' });
        if (!acc[key]) acc[key] = [];
        acc[key].push(entry);
        return acc;
    }, {} as Record<string, JournalEntry[]>);

    return (
        <div className="space-y-8">
            {Object.entries(grouped).map(([month, monthEntries]) => (
                <div key={month} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <h3 className="text-xs font-bold text-ios-textSec uppercase tracking-widest mb-4 ml-2">{month}</h3>
                    <div className="space-y-3">
                        {monthEntries.map((entry) => (
                            <div 
                                key={entry.id} 
                                onClick={() => onSelect(entry)}
                                className="group bg-[#1C1C1E] p-5 rounded-2xl border border-white/5 hover:bg-white/5 hover:border-ios-purple/30 transition-all cursor-pointer active:scale-98 hover:-translate-y-1 shadow-lg hover:shadow-ios-purple/10"
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div className="flex items-center gap-3">
                                        <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex flex-col items-center justify-center group-hover:border-ios-purple/50 transition-colors">
                                            <span className="text-[10px] font-bold text-ios-textSec uppercase">{new Date(entry.date).toLocaleString('default', { weekday: 'short' })}</span>
                                            <span className="text-xl font-bold text-white leading-none">{new Date(entry.date).getDate()}</span>
                                        </div>
                                        <div>
                                            <div className="flex flex-col">
                                                <h3 className="text-base font-bold text-white line-clamp-1 group-hover:text-ios-purple transition-colors">{entry.title || "Untitled Entry"}</h3>
                                                <div className="flex items-center gap-2 mt-0.5">
                                                    <span className="text-[10px] text-ios-textSec flex items-center gap-1">
                                                        <Clock size={10} /> {formatDuration(entry.timeSpent || 0)}
                                                    </span>
                                                    <span className="text-[10px] text-ios-textSec font-mono">•</span>
                                                    <span className="text-[10px] text-ios-textSec">{new Date(entry.updatedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <ChevronLeft className="rotate-180 text-ios-textSec opacity-0 group-hover:opacity-100 transition-opacity" size={16} />
                                </div>
                                <p className="text-white/70 text-sm line-clamp-2 pl-[60px] leading-relaxed">
                                    {entry.blocks.find(b => b.type === 'body')?.content.replace(/<[^>]*>?/gm, '') || 'No content...'}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
};

const ToolBtn: React.FC<{ icon: React.ReactNode, onClick: () => void }> = ({ icon, onClick }) => (
    <button onMouseDown={(e) => { e.preventDefault(); onClick(); }} className="text-ios-textSec hover:text-white p-2 hover:bg-white/10 rounded-lg transition-colors">
        {icon}
    </button>
);

const JournalBlockContent: React.FC<{ 
    block: Block, 
    onChange: (val: string) => void,
    onEnter: () => void,
    onDelete: () => void,
    autoFocus?: boolean
}> = ({ block, onChange, onEnter, onDelete, autoFocus }) => {
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (autoFocus && ref.current) {
            ref.current.focus();
            const range = document.createRange();
            const sel = window.getSelection();
            range.selectNodeContents(ref.current);
            range.collapse(false);
            sel?.removeAllRanges();
            sel?.addRange(range);
        }
    }, [autoFocus]);

    const handleInput = (e: React.FormEvent<HTMLDivElement>) => {
        onChange(e.currentTarget.innerHTML);
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            onEnter();
        }
        if (e.key === 'Backspace' && (!ref.current?.textContent)) {
             if (ref.current?.innerHTML === '' || ref.current?.innerHTML === '<br>') {
                 e.preventDefault();
                 onDelete();
             }
        }
    };

    if (block.type === 'checklist') {
        return (
            <div className="flex gap-2 items-start group">
                <div className="mt-1 w-5 h-5 border-2 border-white/30 rounded flex items-center justify-center">
                    {block.checked && <div className="w-3 h-3 bg-ios-purple rounded-sm" />}
                </div>
                <div 
                    ref={ref}
                    contentEditable
                    suppressContentEditableWarning
                    onInput={handleInput}
                    onKeyDown={handleKeyDown}
                    className="flex-1 outline-none text-white/90 text-lg text-left"
                    dir="ltr"
                    dangerouslySetInnerHTML={{ __html: block.content }}
                />
            </div>
        )
    }

    return (
        <div 
            ref={ref}
            contentEditable
            suppressContentEditableWarning
            onInput={handleInput}
            onKeyDown={handleKeyDown}
            className="w-full outline-none text-white/90 text-lg leading-relaxed empty:before:content-['Type_something...'] empty:before:text-white/20 text-left"
            dir="ltr"
            dangerouslySetInnerHTML={{ __html: block.content }}
        />
    );
};

const JournalEditor: React.FC<{ entry: JournalEntry, onClose: () => void, onSave: (entry: JournalEntry) => void }> = ({ entry, onClose, onSave }) => {
    const [title, setTitle] = useState(entry.title || '');
    const [blocks, setBlocks] = useState<Block[]>(entry.blocks);
    const [mood, setMood] = useState(entry.mood);
    const [tags, setTags] = useState(entry.tags);
    const [showTagInput, setShowTagInput] = useState(false);
    const [newTag, setNewTag] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    
    const [sessionSeconds, setSessionSeconds] = useState(0);
    const initialTimeSpent = useRef(entry.timeSpent || 0);

    useEffect(() => {
        const timer = setInterval(() => {
            setSessionSeconds(s => s + 1);
        }, 1000);
        return () => clearInterval(timer);
    }, []);

    const handleSave = () => {
        setIsSaving(true);
        setTimeout(() => {
            onSave({ 
                ...entry, 
                title, 
                blocks, 
                mood, 
                tags, 
                timeSpent: Number(initialTimeSpent.current) + Number(sessionSeconds),
                updatedAt: new Date().toISOString() 
            });
            setIsSaving(false);
        }, 500);
    };

    const updateBlock = (id: string, content: string) => {
        setBlocks(blocks.map(b => b.id === id ? { ...b, content } : b));
    };

    const addBlock = (type: Block['type'] = 'body', content: string = '') => {
        setBlocks([...blocks, { id: Math.random().toString(36).substr(2, 9), type, content }]);
    };
    
    const removeBlock = (id: string) => {
        if(blocks.length > 1) setBlocks(blocks.filter(b => b.id !== id));
    }

    const handleAddTag = () => {
        if(newTag && !tags.includes(newTag)) {
            setTags([...tags, newTag]);
            setNewTag('');
            setShowTagInput(false);
        }
    }

    return (
        <div className="h-full flex flex-col bg-black">
            <div className="px-4 py-3 border-b border-white/10 flex justify-between items-center bg-black/80 backdrop-blur-xl sticky top-0 z-50">
                <button onClick={onClose} className="p-2 -ml-2 text-ios-textSec hover:text-white transition-colors">Cancel</button>
                <div className="flex items-center gap-1">
                     <span className="text-xs font-bold uppercase tracking-widest text-ios-textSec flex items-center gap-2">
                        <Clock size={12} />
                        {formatDuration(initialTimeSpent.current + sessionSeconds)}
                     </span>
                </div>
                <button onClick={handleSave} className="p-2 -mr-2 text-ios-purple font-bold flex items-center gap-2 hover:bg-white/5 rounded-lg transition-colors">
                    {isSaving ? <Activity size={18} className="animate-spin" /> : <Save size={18} />}
                    <span>Save</span>
                </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 md:p-8">
                <input 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Title your moment..."
                    className="w-full bg-transparent text-3xl font-black text-white border-none outline-none placeholder-white/20 mb-6 text-left"
                />

                <div className="space-y-4 min-h-[50vh]">
                    {blocks.map((block, index) => (
                        <JournalBlockContent 
                            key={block.id} 
                            block={block} 
                            onChange={(content) => updateBlock(block.id, content)} 
                            onEnter={() => addBlock()}
                            onDelete={() => removeBlock(block.id)}
                            autoFocus={index === blocks.length - 1 && block.content === ''}
                        />
                    ))}
                </div>

                <div className="mt-8 pt-8 border-t border-white/10">
                    <div className="flex flex-wrap gap-2 items-center">
                        <Tag size={16} className="text-ios-textSec mr-2" />
                        {tags.map(tag => (
                            <span key={tag} className="bg-white/5 border border-white/10 text-xs font-bold px-2 py-1 rounded-md text-white flex items-center gap-1 group">
                                #{tag}
                                <button onClick={() => setTags(tags.filter(t => t !== tag))} className="text-white/30 group-hover:text-red-500"><X size={10}/></button>
                            </span>
                        ))}
                        {showTagInput ? (
                            <div className="flex items-center gap-2">
                                <input 
                                    autoFocus
                                    value={newTag}
                                    onChange={e => setNewTag(e.target.value)}
                                    onKeyDown={e => e.key === 'Enter' && handleAddTag()}
                                    onBlur={() => setShowTagInput(false)}
                                    className="bg-transparent border-b border-ios-purple outline-none text-sm text-white w-24"
                                    placeholder="New tag..."
                                />
                            </div>
                        ) : (
                            <button onClick={() => setShowTagInput(true)} className="text-xs text-ios-textSec hover:text-white px-2 py-1 border border-dashed border-white/20 rounded-md">+ Add Tag</button>
                        )}
                    </div>
                </div>
            </div>

            <div className="p-3 bg-[#1C1C1E] border-t border-white/10 flex justify-between items-center safe-area-bottom shadow-[0_-5px_30px_rgba(0,0,0,0.5)]">
                 <div className="flex gap-4">
                     <ToolBtn icon={<FileText size={20}/>} onClick={() => addBlock('body')} />
                     <ToolBtn icon={<CheckSquare size={20}/>} onClick={() => addBlock('checklist')} />
                     <ToolBtn icon={<ImageIcon size={20}/>} onClick={() => {}} />
                 </div>
                 <span className="text-[10px] text-ios-textSec">{blocks.length} blocks</span>
            </div>
        </div>
    );
};

const JournalCalendar: React.FC<{ entries: JournalEntry[], onSelectEntry: (entry: JournalEntry) => void }> = ({ entries, onSelectEntry }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDay, setSelectedDay] = useState<string | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const [tilt, setTilt] = useState({ x: 0, y: 0 });

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left) / rect.width - 0.5;
        const y = (e.clientY - rect.top) / rect.height - 0.5;
        setTilt({ x: y * 5, y: -x * 5 });
    };

    const handleMouseLeave = () => setTilt({ x: 0, y: 0 });

    const getWeekDays = (date: Date) => {
        const start = new Date(date);
        start.setDate(date.getDate() - date.getDay()); 
        const days = [];
        for (let i = 0; i < 7; i++) {
            const d = new Date(start);
            d.setDate(start.getDate() + i);
            days.push({
                date: d,
                iso: d.toISOString().split('T')[0]
            });
        }
        return days;
    };

    const days = getWeekDays(currentDate);
    const selectedEntries = selectedDay ? entries.filter(e => e.date === selectedDay) : [];

    return (
        <div className="p-6 space-y-6 animate-in fade-in duration-500 pb-32">
            <div className="flex justify-between items-center mb-8 relative z-20">
                <button onClick={() => setCurrentDate(new Date(currentDate.setDate(currentDate.getDate() - 7)))} className="p-2 text-white hover:bg-white/10 rounded-full transition-transform hover:scale-110"><ChevronLeft/></button>
                <div className="text-center">
                    <h2 className="text-2xl font-black text-white uppercase tracking-tight drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
                        {days[0].date.toLocaleDateString('en-US', { month: 'short' })} {days[0].date.getDate()} - {days[6].date.toLocaleDateString('en-US', { month: 'short' })} {days[6].date.getDate()}
                    </h2>
                    <div className="flex items-center justify-center gap-2 mt-1">
                        <span className="text-ios-textSec text-sm font-bold tracking-[0.3em]">{currentDate.getFullYear()}</span>
                    </div>
                </div>
                <button onClick={() => setCurrentDate(new Date(currentDate.setDate(currentDate.getDate() + 14)))} className="p-2 text-white hover:bg-white/10 rounded-full transition-transform hover:scale-110"><ChevronRight/></button>
            </div>

            <div 
                ref={containerRef}
                onMouseMove={handleMouseMove}
                onMouseLeave={handleMouseLeave}
                className="perspective-container relative z-10 py-4 min-h-[350px] flex items-center justify-center"
            >
                <div 
                    className="flex gap-4 justify-center w-full transition-transform duration-200 ease-out" 
                    style={{ transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}
                >
                    {days.map((d, i) => {
                        const dayEntries = entries.filter(e => e.date === d.iso);
                        const count = dayEntries.length;
                        const isSelected = d.iso === selectedDay;
                        
                        let bgStyle = 'bg-[#1C1C1E]/80 border-white/5 text-white/40';
                        let glowEffect = '';
                        let heightClass = 'h-64';

                        if (count > 0) {
                            bgStyle = 'bg-[#2C2C2E]/90 text-white border-white/20';
                            if (count >= 3) {
                                glowEffect = 'shadow-[0_0_30px_#BF5AF2] border-ios-purple/50';
                                bgStyle = 'bg-gradient-to-t from-ios-purple/20 to-[#2C2C2E]';
                            } else {
                                glowEffect = 'shadow-[0_0_15px_rgba(255,255,255,0.2)]';
                            }
                        }

                        if (isSelected) {
                            bgStyle = 'bg-white text-black border-white';
                            glowEffect = 'shadow-[0_0_40px_white] scale-110 -translate-y-4';
                        }

                        return (
                            <button 
                                key={i}
                                onClick={() => setSelectedDay(d.iso)}
                                className={`
                                    relative w-16 rounded-2xl border flex flex-col items-center justify-end pb-4
                                    transition-all duration-500 group backdrop-blur-xl overflow-hidden
                                    ${bgStyle} ${glowEffect} ${heightClass}
                                `}
                                style={{ transformStyle: 'preserve-3d' }}
                            >
                                <div className="absolute top-2 left-2 right-2 flex flex-col gap-1">
                                    {Array.from({ length: Math.min(count, 5) }).map((_, idx) => (
                                        <div key={idx} className={`h-1 rounded-full ${isSelected ? 'bg-black/20' : 'bg-white/50'} w-full`} />
                                    ))}
                                </div>

                                <div className="relative z-10 flex flex-col items-center">
                                    <span className="text-xs font-bold uppercase tracking-widest opacity-60 mb-1">{d.date.toLocaleDateString('en-US', {weekday:'short'})}</span>
                                    <span className="text-2xl font-black">{d.date.getDate()}</span>
                                </div>
                                
                                {count > 0 && (
                                    <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/50 to-transparent pointer-events-none" />
                                )}
                            </button>
                        )
                    })}
                </div>
            </div>

            {selectedDay && (
                <div className="relative animate-in slide-in-from-bottom-8 duration-500 fade-in z-30 -mt-10">
                    <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-0.5 h-12 bg-gradient-to-b from-transparent via-white to-white/20" />
                    <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-white rounded-full shadow-[0_0_15px_white]" />

                    <div className="bg-[#1C1C1E] border border-white/10 rounded-3xl p-6 shadow-2xl relative overflow-hidden group">
                        <div className="flex justify-between items-center mb-6 border-b border-white/5 pb-4">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 bg-black rounded-xl flex flex-col items-center justify-center border border-white/10">
                                    <span className="text-[10px] text-ios-textSec uppercase font-bold">{new Date(selectedDay).toLocaleDateString('en-US', {weekday:'short'})}</span>
                                    <span className="text-xl font-black text-white">{new Date(selectedDay).getDate()}</span>
                                </div>
                                <div>
                                    <h3 className="text-white font-bold text-lg flex items-center gap-2">
                                        Active Journals <MessageSquare size={14} className="text-ios-purple"/>
                                    </h3>
                                    <p className="text-xs text-ios-textSec">{selectedEntries.length} entries recorded</p>
                                </div>
                            </div>
                            <button onClick={() => setSelectedDay(null)} className="p-2 hover:bg-white/10 rounded-full text-ios-textSec hover:text-white transition-colors"><X size={18}/></button>
                        </div>
                        
                        {selectedEntries.length === 0 ? (
                            <div className="text-center py-8 opacity-50 flex flex-col items-center gap-2">
                                <Ghost size={32} className="text-ios-textSec" />
                                <span className="text-sm font-medium">No activity recorded...</span>
                            </div>
                        ) : (
                            <div className="space-y-3">
                                {selectedEntries.map((entry, idx) => (
                                    <div 
                                        key={entry.id}
                                        onClick={() => onSelectEntry(entry)}
                                        style={{ animationDelay: `${idx * 100}ms` }}
                                        className="group flex items-center gap-4 p-4 bg-black/40 rounded-2xl hover:bg-white/5 cursor-pointer border border-white/5 hover:border-ios-purple/50 transition-all duration-300 hover:translate-x-1 animate-in slide-in-from-left-4"
                                    >
                                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-ios-purple to-blue-600 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                                            <FileText size={18} />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <h4 className="font-bold text-white text-sm truncate">{entry.title || "Untitled Thought"}</h4>
                                            <p className="text-xs text-ios-textSec truncate opacity-70 group-hover:opacity-100">
                                                {entry.blocks.find(b => b.type==='body')?.content.replace(/<[^>]*>?/gm, '') || 'No preview available...'}
                                            </p>
                                        </div>
                                        <div className="flex flex-col items-end gap-1">
                                            <span className="text-[10px] text-ios-textSec font-mono bg-white/5 px-1.5 py-0.5 rounded">{formatDuration(entry.timeSpent||0)}</span>
                                            <ArrowUp size={12} className="text-ios-textSec rotate-45 group-hover:text-ios-purple transition-colors" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    )
}

const InsightsDashboard: React.FC<{ entries: JournalEntry[] }> = ({ entries }) => {
    const getStatsData = () => {
        // Show last 30 days
        const data: { date: string; fullDate: string; characters: number; timeSpent: number }[] = [];
        for(let i=29; i>=0; i--) {
             const d = new Date();
             d.setDate(d.getDate() - i);
             const dateStr = d.toISOString().split('T')[0];
             const dayEntries = entries.filter(e => e.date === dateStr);
             
             // Calculate stats per day
             let chars = 0;
             let time = 0;
             dayEntries.forEach(e => {
                 const text = e.blocks.find(b => b.type === 'body')?.content.replace(/<[^>]*>?/gm, '') || '';
                 chars += text.length;
                 time += (e.timeSpent || 0);
             });

             data.push({
                 date: d.toLocaleDateString('en-US', { day: 'numeric', month: 'short'}),
                 fullDate: dateStr,
                 characters: chars,
                 timeSpent: time
             });
        }
        return data;
    };
    const statsData = getStatsData();

    return (
        <div className="p-6 space-y-6 pb-20">
            {/* TIME STREAM (Writing Volume) */}
            <div className="bg-[#1C1C1E] rounded-3xl p-6 border border-white/5 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-5 pointer-events-none">
                    <History size={120} />
                </div>
                <h3 className="text-white font-bold mb-6 flex items-center gap-2 relative z-10 text-xl">
                    <History size={20} className="text-ios-purple"/> Time Stream
                </h3>
                
                <div className="flex items-end gap-3 overflow-x-auto no-scrollbar pb-2 h-64">
                    {statsData.map((d, i) => {
                         const fillPercent = Math.min(100, (d.characters / 650) * 100);
                         const isFilled = fillPercent >= 100;
                         
                         return (
                             <div key={i} className="flex-shrink-0 flex flex-col items-center gap-2 group w-12 h-full justify-end">
                                 <div className="relative w-full h-[80%] bg-white/5 rounded-t-xl border border-white/5 overflow-hidden flex items-end hover:border-white/20 transition-colors">
                                     <div 
                                        className={`w-full transition-all duration-1000 ease-out relative ${isFilled ? 'bg-ios-purple shadow-[0_0_20px_#BF5AF2]' : 'bg-ios-blue/50'}`} 
                                        style={{height: `${Math.max(5, fillPercent)}%`}} 
                                     >
                                         {isFilled && <div className="absolute inset-0 bg-white/20 animate-pulse" />}
                                     </div>
                                 </div>
                                 <div className="text-center h-[20%]">
                                     <span className="text-[10px] font-bold text-white block">{d.date.split(' ')[1]}</span>
                                     <span className="text-[8px] text-ios-textSec uppercase">{d.date.split(' ')[0]}</span>
                                 </div>
                                 
                                 {/* Hover Tooltip */}
                                 <div className="absolute bottom-20 bg-black px-2 py-1 rounded text-[10px] text-white opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none border border-white/20 whitespace-nowrap z-20 shadow-xl">
                                     {d.characters} chars
                                 </div>
                             </div>
                         )
                    })}
                </div>
            </div>

            {/* SCREEN TIME (Deep Focus) */}
            <div className="bg-[#1C1C1E] rounded-3xl p-6 border border-white/5 shadow-2xl">
                <h3 className="text-white font-bold mb-6 flex items-center gap-2 text-xl">
                    <Clock size={20} className="text-ios-blue"/> Deep Focus
                </h3>
                <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={statsData}>
                            <defs>
                                <linearGradient id="colorTime" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#0A84FF" stopOpacity={0.4}/>
                                    <stop offset="95%" stopColor="#0A84FF" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                            <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#8E8E93', fontSize: 10}} dy={10} />
                            <Tooltip 
                                contentStyle={{backgroundColor: '#000', borderRadius: '12px', border: '1px solid #333'}} 
                                itemStyle={{color: '#fff', fontSize: '12px'}} 
                                cursor={{stroke: 'rgba(255,255,255,0.1)'}} 
                                formatter={(value: number) => [`${Math.round(value / 60)} min`, 'Time Spent']}
                            />
                            <Area type="monotone" dataKey="timeSpent" stroke="#0A84FF" strokeWidth={3} fillOpacity={1} fill="url(#colorTime)" />
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>
        </div>
    )
}

// ... Hint, ProductivityDashboard (Unchanged logic, just ensure imports match) ...
const Hint: React.FC<{ text: string }> = ({ text }) => (
    <div className="group relative inline-flex items-center ml-2">
        <HelpCircle size={14} className="text-white/30 hover:text-white cursor-help transition-colors" />
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-48 p-3 bg-white/10 backdrop-blur-xl border border-white/20 rounded-xl text-xs font-medium text-white shadow-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 text-center">
            {text}
            <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-white/10" />
        </div>
    </div>
);

const ProductivityDashboard: React.FC<{ entries: JournalEntry[], onQuickSave: (text: string) => void }> = ({ entries, onQuickSave }) => {
    const [timeLeft, setTimeLeft] = useState<number>(25 * 60);
    const [isTimerRunning, setIsTimerRunning] = useState(false);
    const [quickNote, setQuickNote] = useState('');
    const [showSuccess, setShowSuccess] = useState(false);

    useEffect(() => {
        let interval: ReturnType<typeof setInterval>;
        if (isTimerRunning && timeLeft > 0) {
            interval = setInterval(() => {
                setTimeLeft(t => t - 1);
            }, 1000);
        } else if (timeLeft === 0 && isTimerRunning) {
            setIsTimerRunning(false);
        }
        return () => clearInterval(interval);
    }, [isTimerRunning, timeLeft]);

    const toggleTimer = () => setIsTimerRunning(!isTimerRunning);
    const resetTimer = () => { setIsTimerRunning(false); setTimeLeft(25 * 60); };
    
    const formatTime = (seconds: number) => {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    };

    const handleQuickAdd = (e: any) => {
        if ((e.key === 'Enter' || e.type === 'click') && quickNote.trim()) {
            onQuickSave(quickNote);
            setQuickNote('');
            setShowSuccess(true);
            setTimeout(() => setShowSuccess(false), 2000);
        }
    };

    // Calculate Stats
    const tagCounts = entries.reduce((acc: Record<string, number>, e) => {
        e.tags.forEach(t => { const count = acc[t] || 0; acc[t] = count + 1; });
        return acc;
    }, {} as Record<string, number>);
    const topTag = Object.entries(tagCounts).sort((a: [string, number], b: [string, number]) => b[1] - a[1])[0];

    const currentStreak: number = (() => {
        let streak = 0; const now = new Date();
        for(let i = 0; i < 365; i++) {
            const ms = i * 86400000;
            const d = new Date(now.getTime() - ms);
            const dStr = d.toISOString().split('T')[0];
            if(entries.some(e => e.date === dStr)) streak++; else if(i===0) continue; else break;
        }
        return streak;
    })();

    const averageWordsChars = entries.reduce((acc, e) => {
        const text = e.blocks.find(b => b.type === 'body')?.content.replace(/<[^>]*>?/gm, '') || '';
        return acc + text.length;
    }, 0);
    const averageWords = entries.length > 0 ? Math.round(averageWordsChars / entries.length) : 0;

    // --- DATA CALCULATION FOR TIME GRAPH ---
    const last7Days = Array.from({length: 7}, (_, i) => {
        const d = new Date();
        const daysToSubtract = 6 - i;
        d.setDate(d.getDate() - daysToSubtract);
        const dateStr = d.toISOString().split('T')[0];
        const dayEntries = entries.filter(e => e.date === dateStr);
        const totalSeconds = dayEntries.reduce((acc: number, e) => acc + (e.timeSpent || 0), 0);
        // Also score for weekly activity graph
        let score = 0;
        if(dayEntries.length > 0) {
             const entry = dayEntries[0];
             const bodyBlock = entry.blocks.find(b => b.type === 'body');
             const textLen = bodyBlock ? bodyBlock.content.length : 0;
             const tagScore = entry.tags.length * 10;
             score = Math.min(100, (textLen / 50) + tagScore);
        }
        return {
            date: d.toLocaleDateString('en-US', { weekday: 'short' }),
            minutes: Math.round(totalSeconds / 60),
            score: score
        };
    });

    return (
        <div className="p-6 space-y-8 pb-32 animate-in fade-in duration-500 relative overflow-hidden">
            {/* Background Neural Grid */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none opacity-50" />
            
            {/* 1. Header */}
            <div className="relative z-10 text-center mb-8">
                <h2 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-ios-purple via-white to-ios-purple animate-pulse-slow tracking-tighter drop-shadow-2xl">
                    25 MIN DEEP WRITING
                </h2>
                <p className="text-ios-textSec text-xs tracking-[0.5em] uppercase mt-2">Enter the Void</p>
            </div>

            {/* 2. CIRCULAR SOUND WAVE TIMER */}
            <div className="flex justify-center py-4 relative z-10">
                 <div className="relative w-72 h-72 flex items-center justify-center">
                     {[0, 1, 2].map((i) => (
                         <div key={i} className={`absolute inset-0 rounded-full border border-ios-purple/30 ${isTimerRunning ? 'animate-ping' : ''}`} style={{ animationDuration: '3s', animationDelay: `${i}s`, animationPlayState: isTimerRunning ? 'running' : 'paused' }} />
                     ))}
                     <div className="relative w-64 h-64 rounded-full bg-[#1C1C1E] border border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] flex flex-col items-center justify-center z-10 overflow-hidden group hover:scale-105 transition-transform duration-500">
                         <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#BF5AF2_0%,_transparent_70%)] opacity-10 group-hover:opacity-20 transition-opacity" />
                         <span className={`text-6xl font-mono font-black tracking-tighter transition-all duration-300 ${isTimerRunning ? 'text-white scale-110 drop-shadow-[0_0_20px_white]' : 'text-white/50'}`}>{formatTime(timeLeft)}</span>
                         <div className="flex items-center gap-2 mt-4 text-xs font-bold uppercase tracking-widest text-ios-purple"><Waves size={14} className={isTimerRunning ? 'animate-pulse' : ''} />{isTimerRunning ? 'Resonating' : 'Idle'}</div>
                     </div>
                 </div>
            </div>

            {/* Timer Controls */}
            <div className="flex justify-center gap-6 relative z-10">
                <button onClick={toggleTimer} className={`w-16 h-16 rounded-full flex items-center justify-center shadow-2xl transition-all duration-200 active:scale-95 ${isTimerRunning ? 'bg-white text-black' : 'bg-ios-purple text-white shadow-lg shadow-ios-purple/20 hover:scale-110'}`}>{isTimerRunning ? <Pause fill="currentColor" size={24}/> : <Play fill="currentColor" size={24} className="ml-1"/>}</button>
                <button onClick={resetTimer} className="w-16 h-16 rounded-full bg-[#1C1C1E] text-white border border-white/10 flex items-center justify-center hover:bg-white/10 active:scale-95 transition-all"><RotateCcw size={24}/></button>
            </div>

            {/* TIME STATS GRAPH */}
            <div className="relative z-10 bg-[#1C1C1E]/80 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg mt-8">
                <h3 className="font-bold text-white flex items-center gap-2 mb-6 text-sm uppercase tracking-wider"><Clock size={16} className="text-ios-purple"/> Deep Focus History</h3>
                <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <ReBarChart data={last7Days}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                            <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#8E8E93', fontSize: 10}} dy={10} />
                            <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{backgroundColor: '#000', borderRadius: '8px', border: '1px solid #333'}} itemStyle={{color: '#fff'}} formatter={(value: number) => [`${value} min`, 'Focus']} />
                            <Bar dataKey="minutes" fill="#BF5AF2" radius={[4, 4, 0, 0]} maxBarSize={40}>
                                {last7Days.map((entry, index) => (<Cell key={`cell-${index}`} fill={entry.minutes > 25 ? '#BF5AF2' : '#38383A'} />))}
                            </Bar>
                        </ReBarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* WEEKLY ACTIVITY GRAPH (RESTORED) */}
            <div className="relative z-10 bg-[#1C1C1E]/80 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg">
                <h3 className="font-bold text-white flex items-center mb-6">Weekly Activity <Hint text="A visual graph of how much you've written and achieved over the last 7 days." /></h3>
                <div className="h-48 w-full"><ResponsiveContainer width="100%" height="100%"><AreaChart data={last7Days}><defs><linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#BF5AF2" stopOpacity={0.4}/><stop offset="95%" stopColor="#BF5AF2" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} /><XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#8E8E93', fontSize: 12}} dy={10} /><Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{backgroundColor: '#000', borderRadius: '8px', border: '1px solid #333'}} itemStyle={{color: '#fff'}}/><Area type="monotone" dataKey="score" stroke="#BF5AF2" fillOpacity={1} fill="url(#colorScore)" /></AreaChart></ResponsiveContainer></div>
            </div>

            {/* STATS GRID (RESTORED) */}
            <div className="relative z-10 grid grid-cols-2 gap-4">
                <div className="bg-[#1C1C1E]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex flex-col justify-between hover:scale-[1.02] transition-transform">
                     <div className="flex justify-between items-start mb-2"><span className="text-xs font-bold text-ios-textSec uppercase">Daily Streak</span><Hint text="How many consecutive days you've been active." /></div>
                     <span className="text-3xl font-black text-white">{currentStreak} <span className="text-sm font-medium text-ios-textSec">Days</span></span>
                     <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden"><div className="h-full bg-green-500" style={{ width: `${Math.min(100, currentStreak * 10)}%` }} /></div>
                </div>
                <div className="bg-[#1C1C1E]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex flex-col justify-between hover:scale-[1.02] transition-transform">
                     <div className="flex justify-between items-start mb-2"><span className="text-xs font-bold text-ios-textSec uppercase">Avg. Length</span><Hint text="Average number of characters per journal entry." /></div>
                     <span className="text-3xl font-black text-white">{averageWords} <span className="text-sm font-medium text-ios-textSec">Chars</span></span>
                     <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden"><div className="h-full bg-yellow-500" style={{ width: `${Math.min(100, averageWords / 10)}%` }} /></div>
                </div>
                <div className="col-span-2 bg-[#1C1C1E]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 flex items-center justify-between hover:scale-[1.02] transition-transform">
                     <div><div className="flex items-center gap-2 mb-1"><span className="text-xs font-bold text-ios-textSec uppercase">Top Topic</span><Hint text="The tag you use most frequently." /></div><h4 className="text-xl font-bold text-white">#{topTag ? topTag[0] : 'None'}</h4></div>
                     <div className="text-right"><span className="text-2xl font-black text-ios-purple">{topTag ? topTag[1] : 0}</span><span className="block text-[10px] text-ios-textSec uppercase">Mentions</span></div>
                </div>
            </div>

            {/* Quick Capture */}
            <div className="relative z-10 bg-[#1C1C1E]/80 backdrop-blur-xl border border-white/10 rounded-2xl p-5 hover:border-ios-purple/30 transition-colors shadow-lg group">
                 <div className="flex justify-between items-center mb-3"><h3 className="font-bold text-white flex items-center">Quick Capture <Hint text="Instantly save an idea to your journal without opening the editor." /></h3>{showSuccess && <span className="text-xs font-bold text-green-500 animate-in fade-in">Saved!</span>}</div>
                 <div className="flex gap-2"><input className="flex-1 bg-black/40 rounded-xl px-4 py-3 text-white outline-none placeholder-white/20 border border-white/5 focus:border-ios-purple/50 transition-all font-medium group-focus-within:bg-black/60" placeholder="What's on your mind?" value={quickNote} onChange={e => setQuickNote(e.target.value)} onKeyDown={handleQuickAdd}/><button onClick={handleQuickAdd} className="p-3 bg-white text-black rounded-xl hover:scale-105 active:scale-95 transition-transform"><ArrowUp size={20} /></button></div>
            </div>
        </div>
    )
}
