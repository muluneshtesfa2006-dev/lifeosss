
import React, { useState, useEffect, useMemo } from 'react';
import { StorageService } from '../services/storageService';
import { 
    Activity, TrendingUp, TrendingDown, Wallet,
    ArrowUpRight, ArrowDownRight, MoreHorizontal,
    Zap, Brain, Calendar, CheckCircle2, LayoutGrid,
    CreditCard, Bitcoin, Sparkles, Filter, ChevronDown,
    BarChart3, PieChart as PieChartIcon, Search, Wifi,
    Cpu, Timer, Layers
} from 'lucide-react';
import { 
    ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
    BarChart, Bar, Cell, PieChart, Pie
} from 'recharts';

interface MainDashboardProps {
    onNavigate: (tab: any) => void;
    onLogout: () => void;
}

// --- SUB-COMPONENT: SHINING PURPLE STRING ---
const ShiningString: React.FC = () => {
    return (
        <div className="absolute top-0 left-0 right-0 h-[500px] pointer-events-none overflow-hidden z-0">
            <svg className="w-full h-full" viewBox="0 0 1440 500" preserveAspectRatio="none">
                <defs>
                    <linearGradient id="stringGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="rgba(168, 85, 247, 0)" />
                        <stop offset="50%" stopColor="#A855F7" />
                        <stop offset="100%" stopColor="rgba(168, 85, 247, 0)" />
                    </linearGradient>
                    <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                        <feGaussianBlur stdDeviation="8" result="coloredBlur" />
                        <feMerge>
                            <feMergeNode in="coloredBlur" />
                            <feMergeNode in="SourceGraphic" />
                        </feMerge>
                    </filter>
                </defs>
                {/* The Shining String Path */}
                <path 
                    d="M0,200 C300,100 600,400 900,200 C1200,50 1440,250 1440,250" 
                    fill="none" 
                    stroke="url(#stringGradient)" 
                    strokeWidth="2" 
                    filter="url(#glow)"
                    className="animate-pulse-slow opacity-80"
                >
                    <animate 
                        attributeName="d" 
                        dur="10s" 
                        repeatCount="indefinite"
                        values="
                            M0,200 C300,100 600,400 900,200 C1200,50 1440,250 1440,250;
                            M0,220 C300,150 600,350 900,250 C1200,100 1440,220 1440,220;
                            M0,200 C300,100 600,400 900,200 C1200,50 1440,250 1440,250
                        "
                    />
                </path>
                {/* Secondary Echo String */}
                <path 
                    d="M0,220 C320,120 620,420 920,220 C1220,70 1440,270 1440,270" 
                    fill="none" 
                    stroke="#7E22CE" 
                    strokeWidth="1" 
                    opacity="0.3"
                >
                     <animate 
                        attributeName="d" 
                        dur="15s" 
                        repeatCount="indefinite"
                        values="
                            M0,220 C320,120 620,420 920,220 C1220,70 1440,270 1440,270;
                            M0,240 C320,170 620,370 920,270 C1220,120 1440,240 1440,240;
                            M0,220 C320,120 620,420 920,220 C1220,70 1440,270 1440,270
                        "
                    />
                </path>
            </svg>
        </div>
    );
}

// --- SUB-COMPONENT: REAL-TIME AGE TICKER ---
const AgeTicker: React.FC<{ birthDate: string }> = ({ birthDate }) => {
    const [age, setAge] = useState<string>('0.0000');

    useEffect(() => {
        const bDate = new Date(birthDate || '2000-01-01');
        const interval = setInterval(() => {
            const now = new Date();
            const diff = now.getTime() - bDate.getTime();
            const ageVal = diff / (1000 * 60 * 60 * 24 * 365.25);
            setAge(ageVal.toFixed(4));
        }, 50);
        return () => clearInterval(interval);
    }, [birthDate]);

    return (
        <div className="relative w-full h-[400px] bg-[#050505]/50 backdrop-blur-sm rounded-[3rem] border border-white/5 p-8 overflow-hidden shadow-2xl flex flex-col items-center justify-center z-10">
            {/* Soft Glow behind numbers */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(168,85,247,0.15),_transparent_60%)] pointer-events-none" />
            
            <div className="relative z-10 flex flex-col items-center text-center">
                <div className="mb-8 flex items-center gap-3 px-6 py-2 rounded-full bg-white/5 border border-white/10">
                     <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_#22c55e]"></div>
                     <span className="text-[10px] text-white/50 font-bold uppercase tracking-[0.3em]">Temporal Sync</span>
                </div>

                <div className="relative">
                    <h1 className="text-8xl md:text-[10rem] lg:text-[12rem] font-black tracking-tighter tabular-nums leading-none font-sans text-white drop-shadow-[0_0_30px_rgba(255,255,255,0.1)]">
                        {age}
                    </h1>
                </div>

                <div className="mt-8 flex flex-col items-center opacity-40">
                    <h3 className="text-sm font-bold text-white uppercase tracking-[0.5em]">Years Elapsed</h3>
                </div>
            </div>
        </div>
    );
};

export const MainDashboard: React.FC<MainDashboardProps> = ({ onNavigate, onLogout }) => {
    const user = StorageService.getUser();
    const [tasks, setTasks] = useState(StorageService.getTasks());
    const [currentTime, setCurrentTime] = useState(new Date());
    const [timeRange, setTimeRange] = useState<'D'|'W'|'M'|'Y'>('M');

    useEffect(() => {
        setTasks(StorageService.getTasks());
        const timer = setInterval(() => setCurrentTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    const netWorth = 14632.57;
    const income = 4632.57;
    
    const chartData = useMemo(() => {
        return Array.from({ length: 12 }).map((_, i) => ({
            name: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i],
            income: Math.floor(Math.random() * 5000) + 3000,
            expense: Math.floor(Math.random() * 3000) + 1000,
            productivity: Math.floor(Math.random() * 100),
        }));
    }, []);

    const barData = Array.from({length: 24}).map((_, i) => ({
        val: Math.random() * 100
    }));

    return (
        <div className="flex-1 h-full bg-[#020202] text-white font-sans overflow-y-auto overflow-x-hidden relative transition-colors duration-500">
            
            {/* VISUAL EFFECTS LAYER */}
            <ShiningString />
            <div className="fixed inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-[0.02] pointer-events-none mix-blend-overlay z-0"></div>
            
            <div className="relative z-10 p-6 md:p-12 max-w-[1920px] mx-auto">
                
                {/* Header Info Row */}
                <div className="flex justify-between items-end mb-12 relative">
                    <div>
                        <h2 className="text-4xl font-black text-white tracking-tight mb-2">Welcome back, <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-white">{user?.name || 'Architect'}</span></h2>
                        <p className="text-sm font-bold text-white/30 uppercase tracking-[0.3em]">{currentTime.toLocaleDateString(undefined, {weekday:'long', year:'numeric', month:'long', day:'numeric'})}</p>
                    </div>
                    <div className="flex items-center gap-2 text-right">
                        <div className="flex flex-col items-end">
                            <span className="text-[10px] font-bold text-purple-500 uppercase tracking-wider bg-purple-500/10 px-2 py-1 rounded border border-purple-500/20">System Online</span>
                            <span className="text-xl font-mono text-white mt-1 font-bold">{currentTime.toLocaleTimeString()}</span>
                        </div>
                    </div>
                </div>

                {/* BENTO GRID LAYOUT */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-20">

                    {/* --- 1. AGE TICKER (Full Width Top) --- */}
                    <div className="lg:col-span-12">
                        <AgeTicker birthDate={user?.birthDate || ''} />
                    </div>

                    {/* --- 2. TOTAL BALANCE (NET WORTH) --- */}
                    <div className="lg:col-span-5 bg-[#050505] rounded-[3rem] p-10 border border-white/5 relative group overflow-hidden hover:border-purple-500/40 transition-all duration-300 shadow-2xl">
                        <div className="absolute -right-20 -top-20 w-64 h-64 bg-purple-900/10 rounded-full blur-[80px] group-hover:bg-purple-600/20 transition-all duration-500"></div>
                        
                        <div className="relative z-10">
                            <div className="flex justify-between items-start mb-8">
                                <div className="flex items-center gap-3">
                                    <div className="p-3 bg-white/5 rounded-2xl text-white group-hover:scale-110 transition-transform duration-300"><Wallet size={24}/></div>
                                    <span className="text-xs font-bold text-white/40 uppercase tracking-[0.2em]">Net Worth</span>
                                </div>
                                <button className="p-2 hover:bg-white/10 rounded-full text-white/40 hover:text-white transition-all"><ArrowUpRight size={24}/></button>
                            </div>

                            <div className="mb-10">
                                <h2 className="text-6xl font-black text-white tracking-tighter mb-4 drop-shadow-xl">
                                    ${netWorth.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                </h2>
                                <div className="flex items-center gap-3">
                                     <div className="bg-green-500/10 px-4 py-1.5 rounded-full text-green-400 text-sm font-bold flex items-center gap-2 border border-green-500/20 shadow-[0_0_15px_rgba(34,197,94,0.2)]">
                                         <TrendingUp size={16}/> +12.5%
                                     </div>
                                </div>
                            </div>

                            {/* Sub Cards */}
                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-5 bg-[#0A0A0A] rounded-2xl border border-white/5 hover:border-purple-500/30 transition-all cursor-pointer group/card">
                                    <div className="flex items-center gap-4">
                                        <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500">
                                            <CreditCard size={20}/>
                                        </div>
                                        <div>
                                            <div className="text-base font-bold text-white">Liquid Cash</div>
                                            <div className="text-[10px] text-white/30 font-mono tracking-wider">**** 4921</div>
                                        </div>
                                    </div>
                                    <span className="font-bold text-white font-mono text-lg">$8,421.26</span>
                                </div>
                                <div className="flex items-center justify-between p-5 bg-[#0A0A0A] rounded-2xl border border-white/5 hover:border-purple-500/30 transition-all cursor-pointer group/card">
                                    <div className="flex items-center gap-4">
                                        <div className="w-12 h-12 rounded-xl bg-orange-500/10 flex items-center justify-center text-orange-500">
                                            <Bitcoin size={20}/>
                                        </div>
                                        <div>
                                            <div className="text-base font-bold text-white">Crypto Assets</div>
                                            <div className="text-[10px] text-white/30 font-mono tracking-wider">BTC / ETH</div>
                                        </div>
                                    </div>
                                    <span className="font-bold text-white font-mono text-lg">$6,211.31</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* --- 3. MONTHLY INCOME (PRODUCTIVITY VOLUME) --- */}
                    <div className="lg:col-span-7 bg-[#050505] rounded-[3rem] p-10 border border-white/5 relative group overflow-hidden hover:border-purple-500/40 transition-all duration-300 shadow-2xl">
                         <div className="absolute -left-20 -bottom-20 w-64 h-64 bg-purple-900/10 rounded-full blur-[80px] group-hover:bg-purple-600/20 transition-all duration-500"></div>

                         <div className="relative z-10">
                            <div className="flex justify-between items-start mb-6">
                                <div className="flex items-center gap-3">
                                    <div className="p-3 bg-white/5 rounded-2xl text-purple-400 group-hover:rotate-12 transition-transform duration-300"><Zap size={24}/></div>
                                    <span className="text-xs font-bold text-white/40 uppercase tracking-[0.2em]">Productivity Volume</span>
                                </div>
                                <button className="p-2 hover:bg-white/5 rounded-full text-white/40 transition-colors"><ArrowUpRight size={24}/></button>
                            </div>

                            <div className="flex items-baseline gap-4 mb-10">
                                <h2 className="text-6xl font-black text-white tracking-tighter drop-shadow-xl">
                                    ${income.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                                </h2>
                                <span className="text-green-400 text-sm font-bold flex items-center gap-1 bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20">
                                    <TrendingUp size={16}/> +6.12%
                                </span>
                            </div>

                            {/* Custom Bar Chart Visualization */}
                            <div className="h-32 w-full flex items-end justify-between gap-2 mb-10 px-2">
                                {barData.map((d, i) => (
                                    <div 
                                        key={i} 
                                        className="w-full bg-white/5 rounded-t-sm relative group/bar overflow-hidden transition-all duration-300 hover:scale-y-110 origin-bottom"
                                        style={{ height: `${20 + (d.val * 0.8)}%` }}
                                    >
                                        <div className={`absolute inset-0 bg-gradient-to-t ${i % 2 === 0 ? 'from-purple-600 to-indigo-600' : 'from-purple-900/50 to-indigo-900/50'} opacity-70 group-hover/bar:opacity-100 transition-opacity`}></div>
                                    </div>
                                ))}
                            </div>

                            {/* Legend / Stats */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                {[{l:'Mental',v:'44%',c:'bg-purple-500'}, {l:'Physical',v:'27%',c:'bg-blue-500'}, {l:'Deep Work',v:'21%',c:'bg-white'}, {l:'Other',v:'8%',c:'bg-white/30'}].map((item, i) => (
                                    <div key={i} className="bg-[#0A0A0A] rounded-2xl p-5 border border-white/5 flex flex-col items-start gap-2 hover:bg-white/5 transition-all">
                                         <div className="flex items-center gap-2">
                                             <div className={`w-2 h-2 rounded-full ${item.c} shadow-[0_0_10px_currentColor]`}/>
                                             <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">{item.l}</span>
                                         </div>
                                         <span className="text-2xl font-black text-white">{item.v}</span>
                                    </div>
                                ))}
                            </div>
                         </div>
                    </div>

                    {/* --- 4. SYSTEM OUTPUT (MAIN CHART) --- */}
                    <div className="lg:col-span-8 bg-[#050505] rounded-[3rem] p-10 border border-white/5 relative group overflow-hidden hover:border-purple-500/30 transition-all duration-300 shadow-2xl">
                        <div className="relative z-10">
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                                <div>
                                     <div className="flex items-center gap-3 mb-2">
                                        <div className="p-3 bg-white/5 rounded-2xl text-white"><BarChart3 size={20}/></div>
                                        <span className="text-xs font-bold text-white/40 uppercase tracking-[0.2em]">System Output</span>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <span className="text-sm font-medium text-white/50 flex items-center gap-2">Inflow <span className="text-green-400 font-bold bg-green-500/10 px-2 py-0.5 rounded border border-green-500/20">+8.12%</span></span>
                                        <span className="text-sm font-medium text-white/50 flex items-center gap-2">Burn <span className="text-red-400 font-bold bg-red-500/10 px-2 py-0.5 rounded border border-red-500/20">-2.1%</span></span>
                                    </div>
                                </div>
                                
                                <div className="flex bg-[#0A0A0A] p-1.5 rounded-xl border border-white/10">
                                    {['D', 'W', 'M', 'Y'].map(t => (
                                        <button 
                                            key={t}
                                            onClick={() => setTimeRange(t as any)}
                                            className={`w-10 h-9 rounded-lg text-xs font-bold transition-all duration-300 ${timeRange === t ? 'bg-[#1C1C1E] text-white border border-white/10 shadow-lg' : 'text-white/30 hover:text-white'}`}
                                        >
                                            {t}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div className="h-[320px] w-full">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={chartData} barSize={40}>
                                        <defs>
                                            <linearGradient id="purpleBar" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="0%" stopColor="#A855F7" stopOpacity={1}/>
                                                <stop offset="100%" stopColor="#7E22CE" stopOpacity={0.4}/>
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} opacity={0.1} />
                                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#666', fontSize: 11, fontWeight: 'bold'}} dy={10} />
                                        <Tooltip 
                                            cursor={{fill: 'rgba(168,85,247,0.1)', radius: 8}}
                                            contentStyle={{backgroundColor: '#0A0A0A', border: '1px solid #333', borderRadius: '16px', color: '#fff'}}
                                            itemStyle={{color: '#fff', fontSize: '12px', fontWeight: 'bold'}}
                                        />
                                        <Bar dataKey="income" fill="url(#purpleBar)" radius={[8, 8, 0, 0]} animationDuration={1500} />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </div>

                    {/* --- 5. NEURAL ENGINE (AI CARD) --- */}
                    <div className="lg:col-span-4 bg-gradient-to-br from-[#120524] to-black rounded-[3rem] p-10 border border-white/5 relative overflow-hidden flex flex-col justify-between group hover:border-purple-500/50 transition-all duration-500 shadow-2xl">
                        <div className="absolute top-0 right-0 w-[150%] h-[150%] bg-[radial-gradient(circle_at_50%_50%,_rgba(168,85,247,0.15),transparent_70%)] blur-[60px] pointer-events-none animate-pulse-slow"></div>
                        
                        <div className="relative z-10">
                            <div className="w-16 h-16 bg-white/5 backdrop-blur-xl rounded-2xl flex items-center justify-center mb-8 border border-white/10 shadow-[0_0_40px_rgba(168,85,247,0.1)]">
                                <Brain size={32} className="text-white fill-white/10 animate-float-medium"/>
                            </div>
                            <h2 className="text-4xl font-black text-white mb-4 leading-tight tracking-tight">
                                Neural Engine <br/><span className="text-purple-500 drop-shadow-[0_0_15px_#A855F7]">Online</span>
                            </h2>
                            <p className="text-white/50 text-sm font-medium leading-relaxed mb-8 max-w-xs">
                                Analysis complete. Optimization opportunities detected in Sector 7.
                            </p>
                        </div>

                        <div className="relative z-10 mt-auto">
                            <button className="bg-white text-black font-black text-sm uppercase tracking-widest py-6 px-8 rounded-2xl w-full hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 group/btn relative overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.2)]">
                                 <span className="relative z-10 flex items-center gap-2">Execute Analysis <Sparkles size={16} /></span>
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};
