
import React, { useEffect, useState, useRef } from 'react';
import { ArrowRight, Brain, Target, Shield, Zap, Play, Star, Activity, Clock } from 'lucide-react';

interface HomeProps {
    onAction: () => void;
}

export const Home: React.FC<HomeProps> = ({ onAction }) => {
    const [scrolled, setScrolled] = useState(false);
    const observerRef = useRef<IntersectionObserver | null>(null);

    useEffect(() => {
        const handleScroll = () => setScrolled(window.scrollY > 50);
        window.addEventListener('scroll', handleScroll);
        
        // Scroll Reveal Observer
        observerRef.current = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('reveal-visible');
                }
            });
        }, { threshold: 0.1 });

        document.querySelectorAll('.reveal-on-scroll').forEach(el => observerRef.current?.observe(el));

        return () => {
            window.removeEventListener('scroll', handleScroll);
            observerRef.current?.disconnect();
        };
    }, []);

    return (
        <div className="w-full h-full overflow-y-auto bg-[#020202] text-white selection:bg-ios-purple selection:text-white scroll-smooth relative">
            {/* Nebula Background */}
            <div className="absolute inset-0 bg-nebula opacity-40 pointer-events-none fixed"></div>
            
            {/* Nav */}
            <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 px-6 md:px-12 flex justify-between items-center ${scrolled ? 'py-4 glass-panel border-b-0 m-4 rounded-full bg-black/50 backdrop-blur-xl border-white/5' : 'py-8'}`}>
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-white rounded flex items-center justify-center font-black italic text-black shadow-lg shadow-white/10">L</div>
                    <span className="font-black tracking-tighter text-xl">LifeOS</span>
                </div>
                <button 
                    onClick={onAction}
                    className="glass-card hover:bg-white/10 border border-white/10 px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all hover:scale-105"
                >
                    Login
                </button>
            </nav>

            {/* HERO SECTION */}
            <section className="relative pt-48 pb-32 px-6 md:px-12 max-w-7xl mx-auto min-h-screen flex flex-col justify-center items-center text-center reveal-on-scroll">
                <div className="relative z-10 space-y-4 flex flex-col items-center">
                    <div className="inline-flex items-center gap-2 px-6 py-2 rounded-full bg-ios-purple/10 border border-ios-purple/20 text-ios-purple text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-md mb-4 shadow-[0_0_20px_rgba(168,85,247,0.2)]">
                        <Zap size={12} className="fill-current"/> Neural Architecture V4.0
                    </div>
                    
                    {/* Unique H1 for LifeOS */}
                    <h1 className="text-[15vw] md:text-[12vw] font-black leading-[0.8] tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white via-purple-200 to-purple-900 drop-shadow-[0_0_30px_rgba(168,85,247,0.3)] animate-pulse-glow">
                        LifeOS
                    </h1>
                    
                    {/* Smaller H2 for Productivity Tracker */}
                    <h2 className="text-xl md:text-3xl font-medium tracking-[0.5em] uppercase text-white/60 mt-4">
                        Productivity Tracker
                    </h2>
                    
                    <p className="max-w-xl text-sm md:text-lg text-white/40 font-medium leading-relaxed mt-8">
                        The ultimate operating system for high-performance individuals. 
                    </p>

                    <div className="flex flex-wrap justify-center gap-4 pt-12">
                        <button 
                            onClick={onAction}
                            className="bg-white text-black px-12 py-5 rounded-full font-black text-sm uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-[0_0_40px_rgba(255,255,255,0.3)] flex items-center gap-2 group hover:shadow-[0_0_50px_rgba(168,85,247,0.4)]"
                        >
                            Sign In to Dashboard <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform"/>
                        </button>
                    </div>
                </div>
            </section>

            {/* WHAT IT IS & HOW IT WORKS */}
            <section className="px-6 md:px-12 py-32 max-w-7xl mx-auto relative z-10 reveal-on-scroll">
                <div className="glass-panel rounded-[3rem] p-8 md:p-16 flex flex-col md:flex-row gap-16 items-center bg-[#050505]/60 border border-white/5 backdrop-blur-xl">
                    
                    {/* Text Side */}
                    <div className="flex-1 space-y-10">
                        <div>
                            <h2 className="text-4xl md:text-6xl font-black tracking-tighter mb-6 text-white">What is LifeOS?</h2>
                            <p className="text-lg text-white/50 leading-relaxed">
                                LifeOS isn't just a todo list. It's a <strong>second brain</strong> that connects your daily actions to your 10-year vision.
                                It uses AI to analyze your habits, optimize your schedule, and ensure you're always moving forward.
                            </p>
                        </div>

                        <div className="space-y-6">
                            <h3 className="text-xl font-bold uppercase tracking-widest text-ios-purple">How It Works</h3>
                            
                            <div className="flex items-start gap-4 p-4 rounded-2xl hover:bg-white/5 transition-colors group">
                                <div className="p-3 bg-white/5 rounded-xl text-white group-hover:text-ios-purple transition-colors"><Target size={24}/></div>
                                <div>
                                    <h4 className="font-bold text-lg text-white">1. Set Strategic Plans</h4>
                                    <p className="text-sm text-white/40">Define long-term phases, budgets, and milestones.</p>
                                </div>
                            </div>
                            
                            <div className="flex items-start gap-4 p-4 rounded-2xl hover:bg-white/5 transition-colors group">
                                <div className="p-3 bg-white/5 rounded-xl text-white group-hover:text-ios-purple transition-colors"><Activity size={24}/></div>
                                <div>
                                    <h4 className="font-bold text-lg text-white">2. Execute Habits</h4>
                                    <p className="text-sm text-white/40">Daily protocols track your physical and mental stats.</p>
                                </div>
                            </div>

                            <div className="flex items-start gap-4 p-4 rounded-2xl hover:bg-white/5 transition-colors group">
                                <div className="p-3 bg-white/5 rounded-xl text-white group-hover:text-ios-purple transition-colors"><Brain size={24}/></div>
                                <div>
                                    <h4 className="font-bold text-lg text-white">3. AI Synthesis</h4>
                                    <p className="text-sm text-white/40">Gemini AI analyzes your journals to find patterns.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Simulated Phone Dashboard Preview */}
                    <div className="flex-1 w-full max-w-md flex justify-center">
                        <div className="relative w-[320px] h-[650px] rounded-[3rem] border-[8px] border-[#1C1C1E] bg-black shadow-2xl overflow-hidden ring-4 ring-white/5 transform rotate-[-3deg] hover:rotate-0 transition-transform duration-700 hover:shadow-[0_0_60px_rgba(168,85,247,0.2)]">
                             {/* Mock UI Header */}
                             <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-black/80 to-transparent z-30 p-6 flex justify-between items-start pointer-events-none">
                                 <div className="w-20 h-6 bg-black rounded-full mx-auto absolute top-4 left-1/2 -translate-x-1/2 z-40" />
                                 <div className="flex justify-between w-full mt-2 px-2">
                                     <span className="text-[10px] font-bold text-white">9:41</span>
                                     <div className="flex gap-1">
                                         <div className="w-3 h-3 bg-white rounded-full"></div>
                                         <div className="w-3 h-3 bg-white rounded-full"></div>
                                     </div>
                                 </div>
                             </div>

                             {/* Simulated App Content - Mini Dashboard */}
                             <div className="absolute inset-0 bg-[#050505] flex flex-col pt-16 pb-4 px-4 gap-4 overflow-hidden">
                                 {/* Stats Cards */}
                                 <div className="grid grid-cols-2 gap-3">
                                     <div className="bg-[#0A0A0A] p-4 rounded-2xl border border-white/5 flex flex-col justify-between h-24">
                                         <Activity size={16} className="text-ios-purple" />
                                         <div>
                                             <span className="text-2xl font-bold text-white">88%</span>
                                             <span className="text-[9px] text-white/50 block">Efficiency</span>
                                         </div>
                                     </div>
                                     <div className="bg-[#0A0A0A] p-4 rounded-2xl border border-white/5 flex flex-col justify-between h-24">
                                         <Clock size={16} className="text-blue-500" />
                                         <div>
                                             <span className="text-2xl font-bold text-white">4h</span>
                                             <span className="text-[9px] text-white/50 block">Deep Work</span>
                                         </div>
                                     </div>
                                 </div>

                                 {/* Active Plan */}
                                 <div className="bg-[#0A0A0A] p-5 rounded-3xl relative overflow-hidden shadow-lg border border-white/5">
                                     <div className="absolute inset-0 bg-gradient-to-br from-ios-purple/20 to-transparent opacity-50"></div>
                                     <div className="relative z-10">
                                         <div className="flex justify-between mb-4">
                                             <span className="bg-white/10 text-white text-[9px] px-2 py-1 rounded font-bold border border-white/5">ACTIVE</span>
                                             <Target size={16} className="text-white"/>
                                         </div>
                                         <h4 className="text-lg font-black text-white leading-tight mb-1">Project Titan</h4>
                                         <p className="text-xs text-white/60 mb-4">Phase 2: Execution</p>
                                         <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                                             <div className="h-full bg-white w-2/3 shadow-[0_0_10px_white]"></div>
                                         </div>
                                     </div>
                                 </div>

                                 {/* List */}
                                 <div className="flex-1 bg-[#0A0A0A] rounded-3xl p-4 border border-white/5 space-y-3">
                                     <div className="flex justify-between items-center mb-2">
                                         <span className="text-xs font-bold text-white uppercase">Today's Missions</span>
                                         <span className="text-[10px] text-ios-purple">3 Remaining</span>
                                     </div>
                                     {[1, 2, 3].map(i => (
                                         <div key={i} className="flex items-center gap-3 p-2 bg-black/40 rounded-xl border border-white/5">
                                             <div className="w-4 h-4 rounded border border-white/10"></div>
                                             <div className="flex-1">
                                                 <div className="h-2 w-24 bg-white/10 rounded mb-1"></div>
                                                 <div className="h-1.5 w-12 bg-white/5 rounded"></div>
                                             </div>
                                         </div>
                                     ))}
                                 </div>
                             </div>

                             {/* Gradient Overlay */}
                             <div className="absolute inset-0 bg-gradient-to-t from-ios-purple/10 via-transparent to-transparent pointer-events-none" />
                        </div>
                    </div>
                </div>
            </section>

            {/* CUSTOMER FEEDBACK - Shining Static Grid */}
            <section className="py-32 relative z-10 reveal-on-scroll">
                <div className="px-6 md:px-12 max-w-7xl mx-auto mb-16 text-center">
                    <h2 className="text-4xl font-black tracking-tighter mb-4 text-white">Customer Feedback</h2>
                    <p className="text-white/40 text-sm uppercase tracking-widest">Trusted by 10,000+ High Performers</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-6 md:px-12 max-w-7xl mx-auto">
                    {[
                        { name: "Alex Hormozi", role: "Entrepreneur", text: "The only app that actually handles complexity without being complicated. The AI insights are scary good." },
                        { name: "Sara Dietschy", role: "Creator", text: "Finally, a dashboard that looks as good as it functions. The aesthetics keep me coming back." },
                        { name: "Tim Ferriss", role: "Author", text: "LifeOS replaced 5 different subscriptions for me. The data sovereignty feature is a game changer." },
                        { name: "MKBHD", role: "Reviewer", text: "Cleanest UI I've seen this year. The 120Hz animations on mobile feel native." },
                        { name: "Naval Ravikant", role: "Investor", text: "Wealth creation requires clarity. LifeOS provides the architecture for clear thinking." },
                        { name: "James Clear", role: "Author", text: "Atomic Habits in digital form. This system basically forces you to succeed." },
                    ].map((review, i) => (
                        <div 
                            key={i} 
                            className="group relative bg-[#050505] border border-white/5 p-8 rounded-[2rem] backdrop-blur-xl overflow-hidden hover:-translate-y-2 transition-all duration-500 hover:border-ios-purple/30"
                        >
                            {/* Shining Gradient Effect on Hover */}
                            <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                            <div className="absolute -inset-full top-0 block h-full w-1/2 -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-20 group-hover:animate-shine" />
                            
                            <div className="relative z-10">
                                <div className="flex gap-1 mb-4 text-ios-purple">
                                    <Star fill="currentColor" size={16}/><Star fill="currentColor" size={16}/><Star fill="currentColor" size={16}/><Star fill="currentColor" size={16}/><Star fill="currentColor" size={16}/>
                                </div>
                                <p className="text-lg font-medium leading-relaxed mb-6 text-white group-hover:text-white transition-all">"{review.text}"</p>
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-white to-gray-400 flex items-center justify-center font-bold text-black text-xs shadow-lg">
                                        {review.name.charAt(0)}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-sm text-white">{review.name}</h4>
                                        <p className="text-xs text-white/40 uppercase tracking-wider">{review.role}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* FOOTER */}
            <footer className="py-20 text-center border-t border-white/5 mt-20 relative z-10 bg-[#050505] reveal-on-scroll">
                <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 mb-12 text-left">
                    <div>
                        <h4 className="font-bold text-white mb-4">Product</h4>
                        <ul className="space-y-2 text-sm text-white/40">
                            <li className="hover:text-white cursor-pointer">Features</li>
                            <li className="hover:text-white cursor-pointer">Pricing</li>
                            <li className="hover:text-white cursor-pointer">Roadmap</li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold text-white mb-4">Resources</h4>
                        <ul className="space-y-2 text-sm text-white/40">
                            <li className="hover:text-white cursor-pointer">Documentation</li>
                            <li className="hover:text-white cursor-pointer">API</li>
                            <li className="hover:text-white cursor-pointer">Community</li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold text-white mb-4">Company</h4>
                        <ul className="space-y-2 text-sm text-white/40">
                            <li className="hover:text-white cursor-pointer">About</li>
                            <li className="hover:text-white cursor-pointer">Careers</li>
                            <li className="hover:text-white cursor-pointer">Legal</li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold text-white mb-4">LifeOS</h4>
                        <p className="text-xs text-white/30 leading-relaxed">
                            Designed in San Francisco.<br/>
                            Built for the sovereign individual.
                        </p>
                    </div>
                </div>
                <div className="flex items-center justify-center gap-2 mb-4">
                    <div className="w-6 h-6 bg-white rounded flex items-center justify-center font-black italic text-black text-xs shadow-[0_0_10px_white]">L</div>
                    <span className="font-black tracking-tighter text-lg">LifeOS</span>
                </div>
                <p className="text-[10px] text-white/20 uppercase tracking-[0.5em]">© 2025 LifeOS Systems Inc. All Rights Reserved.</p>
            </footer>
        </div>
    );
};
