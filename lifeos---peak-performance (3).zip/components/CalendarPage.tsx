
import React, { useState, useEffect, useMemo } from 'react';
import { 
    ChevronLeft, ChevronRight, Search, Calendar as CalendarIcon, 
    CheckCircle2, Clock, Zap, Filter, LayoutGrid, List, CheckSquare, 
    MoreHorizontal, ArrowUpRight, Bell, Target, Activity, Flame, TrendingUp,
    Shield, Layers, Brain
} from 'lucide-react';
import { StorageService } from '../services/storageService';
import { Task, RoutineLog, Routine, CalendarEvent, PlanMilestone, Plan } from '../types';
import { 
    AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid 
} from 'recharts';

interface CalendarPageProps {
    onNavigate: (tab: any) => void;
}

export const CalendarPage: React.FC<CalendarPageProps> = ({ onNavigate }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [viewMode, setViewMode] = useState<'MONTH' | 'WEEK'>('MONTH');
    const [events, setEvents] = useState<CalendarEvent[]>([]);
    const [routines, setRoutines] = useState<Routine[]>([]);
    const [tasks, setTasks] = useState<Task[]>([]);
    const [plans, setPlans] = useState<Plan[]>([]);
    const [logs, setLogs] = useState<RoutineLog[]>([]);
    const [showIntro, setShowIntro] = useState(false);
    
    // Filters
    const [showTasks, setShowTasks] = useState(true);
    const [showRoutines, setShowRoutines] = useState(true);
    const [showManual, setShowManual] = useState(true);

    // Initial Data Load
    useEffect(() => {
        const loadData = () => {
            const tasksData = StorageService.getTasks();
            const logsData = StorageService.getLogs();
            const routinesData = StorageService.getRoutines();
            const plansData = StorageService.getPlans();
            
            setTasks(tasksData);
            setLogs(logsData);
            setRoutines(routinesData);
            setPlans(plansData);

            const generatedEvents: CalendarEvent[] = [];

            // 1. Map Tasks to Events
            tasksData.forEach(task => {
                generatedEvents.push({
                    id: task.id,
                    title: task.title,
                    date: task.date, // YYYY-MM-DD
                    type: 'TASK',
                    completed: task.completed,
                    color: task.completed ? '#10B981' : '#3B82F6', // Green or Blue
                    metadata: { priority: task.priority }
                });
            });

            // 2. Aggregate Routine Logs per Day
            const logsByDate: Record<string, RoutineLog[]> = {};
            logsData.forEach(log => {
                if (!logsByDate[log.date]) logsByDate[log.date] = [];
                logsByDate[log.date].push(log);
            });

            Object.entries(logsByDate).forEach(([date, dayLogs]) => {
                const completedCount = dayLogs.filter(l => l.completed).length;
                const totalRoutines = routinesData.length;
                if (totalRoutines > 0) {
                    generatedEvents.push({
                        id: `routine-${date}`,
                        title: `${completedCount}/${totalRoutines} Rituals`,
                        date: date,
                        type: 'ROUTINE_SUMMARY',
                        completed: completedCount === totalRoutines,
                        color: '#A855F7', // Purple
                        metadata: { count: completedCount, total: totalRoutines }
                    });
                }
            });

            setEvents(generatedEvents);
        };

        loadData();

        // Check Intro
        const hasSeenIntro = localStorage.getItem('lifeos_calendar_intro_seen');
        if (!hasSeenIntro) {
            setShowIntro(true);
        }
    }, []);

    const dismissIntro = () => {
        localStorage.setItem('lifeos_calendar_intro_seen', 'true');
        setShowIntro(false);
    }

    const filteredEvents = useMemo(() => {
        return events.filter(e => {
            if (!showTasks && e.type === 'TASK') return false;
            if (!showRoutines && e.type === 'ROUTINE_SUMMARY') return false;
            if (!showManual && e.type === 'MANUAL') return false;
            return true;
        });
    }, [events, showTasks, showRoutines, showManual]);

    // Calendar Calculations
    const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay(); // 0 = Sun

    // Month Grid Data
    const calendarDays = useMemo(() => {
        const days = [];
        for (let i = 0; i < firstDayOfMonth; i++) days.push({ date: null, events: [] }); 
        for (let i = 1; i <= daysInMonth; i++) {
            const dateStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            const dayEvents = filteredEvents.filter(e => e.date === dateStr);
            days.push({ date: i, dateStr, events: dayEvents });
        }
        return days;
    }, [currentDate, filteredEvents, firstDayOfMonth, daysInMonth]);

    // Week Grid Data
    const weekDays = useMemo(() => {
        const start = new Date(currentDate);
        start.setDate(currentDate.getDate() - currentDate.getDay()); // Start on Sunday
        const days = [];
        for (let i = 0; i < 7; i++) {
            const d = new Date(start);
            d.setDate(start.getDate() + i);
            const dateStr = d.toISOString().split('T')[0];
            const dayEvents = filteredEvents.filter(e => e.date === dateStr);
            days.push({ date: d, dateStr, events: dayEvents });
        }
        return days;
    }, [currentDate, filteredEvents]);

    // Navigation Handlers
    const handlePrev = () => {
        const d = new Date(currentDate);
        if (viewMode === 'MONTH') d.setMonth(d.getMonth() - 1);
        else d.setDate(d.getDate() - 7);
        setCurrentDate(d);
    };
    const handleNext = () => {
        const d = new Date(currentDate);
        if (viewMode === 'MONTH') d.setMonth(d.getMonth() + 1);
        else d.setDate(d.getDate() + 7);
        setCurrentDate(d);
    };
    const handleToday = () => setCurrentDate(new Date());

    // Header Text Logic
    const getHeaderText = () => {
        if (viewMode === 'MONTH') return currentDate.toLocaleString('default', { month: 'long' });
        const d = new Date(Date.UTC(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate()));
        const dayNum = d.getUTCDay() || 7;
        d.setUTCDate(d.getUTCDate() + 4 - dayNum);
        const yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
        const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1)/7);
        return `Week ${weekNo}`;
    };

    // "System Yield" Stats Calculations
    const activePlans = plans.filter(p => p.status === 'Active');
    const tasksDone = tasks.filter(t => t.completed).length;
    const tasksTotal = tasks.length;
    const routineRate = Math.round((events.filter(e => e.type === 'ROUTINE_SUMMARY' && e.completed).length / Math.max(1, events.filter(e => e.type === 'ROUTINE_SUMMARY').length)) * 100);

    return (
        <div className="flex h-full w-full bg-[#020202] text-white font-sans overflow-hidden relative">
            
            {/* COOL INTRO OVERLAY (Blur + White Text) */}
            {showIntro && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center animate-in fade-in duration-700">
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-3xl"></div>
                    <div className="relative z-10 max-w-xl p-12 text-center">
                        <div className="inline-block px-4 py-1 rounded-full border border-white/20 bg-white/5 backdrop-blur-md text-xs font-bold uppercase tracking-[0.3em] mb-8 text-white">
                            System Notice
                        </div>
                        <h1 className="text-6xl font-black text-white tracking-tighter mb-6 leading-tight drop-shadow-2xl">
                            Temporal<br/>Data Layer
                        </h1>
                        <p className="text-xl text-white/80 font-medium leading-relaxed mb-12">
                            This interface is a read-only visualization of your timeline. 
                            To initiate new protocols or directives, access the <span className="text-white font-bold border-b border-white/30">Rituals Matrix</span>.
                        </p>
                        <button 
                            onClick={dismissIntro}
                            className="bg-white text-black px-10 py-4 rounded-full font-black text-sm uppercase tracking-widest hover:scale-105 transition-transform shadow-[0_0_40px_rgba(255,255,255,0.3)]"
                        >
                            Acknowledge
                        </button>
                    </div>
                </div>
            )}

            {/* LEFT SIDEBAR CONTROLS (Updated "Approaching" Design) */}
            <div className="w-80 border-r border-white/5 bg-[#050505] hidden lg:flex flex-col h-full z-20">
                <div className="p-6 border-b border-white/5">
                    <h2 className="text-xl font-black text-white tracking-tight flex items-center gap-2 mb-6">
                        <CalendarIcon className="text-ios-purple"/> Timeline
                    </h2>
                    
                    {/* Mini Calendar */}
                    <div className="bg-[#0A0A0A] rounded-2xl p-4 border border-white/5 mb-6">
                        <div className="flex justify-between items-center mb-4">
                            <span className="font-bold text-sm">{currentDate.toLocaleString('default', { month: 'long', year: 'numeric' })}</span>
                            <div className="flex gap-1">
                                <button onClick={() => {const d = new Date(currentDate); d.setMonth(d.getMonth()-1); setCurrentDate(d)}} className="p-1 hover:bg-white/10 rounded"><ChevronLeft size={14}/></button>
                                <button onClick={() => {const d = new Date(currentDate); d.setMonth(d.getMonth()+1); setCurrentDate(d)}} className="p-1 hover:bg-white/10 rounded"><ChevronRight size={14}/></button>
                            </div>
                        </div>
                        <div className="grid grid-cols-7 text-center gap-1 text-xs text-white/40 mb-2">
                            {['S','M','T','W','T','F','S'].map(d => <span key={d}>{d}</span>)}
                        </div>
                        <div className="grid grid-cols-7 text-center gap-1 text-sm">
                            {calendarDays.slice(0, 42).map((d, i) => (
                                <div key={i} className={`h-8 w-8 flex items-center justify-center rounded-full ${d.date ? 'hover:bg-white/10 cursor-pointer' : ''} ${d.dateStr === new Date().toISOString().split('T')[0] ? 'bg-ios-purple text-white font-bold shadow-[0_0_10px_#A855F7]' : 'text-white/70'}`}>
                                    {d.date}
                                </div>
                            ))}
                        </div>
                    </div>

                    <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-4">Data Layers</h3>
                    <div className="space-y-2">
                        <FilterToggle label="Daily Rituals" color="bg-purple-500" active={showRoutines} onClick={() => setShowRoutines(!showRoutines)} />
                        <FilterToggle label="Task Matrix" color="bg-blue-500" active={showTasks} onClick={() => setShowTasks(!showTasks)} />
                        <FilterToggle label="Manual Events" color="bg-orange-500" active={showManual} onClick={() => setShowManual(!showManual)} />
                    </div>
                </div>

                {/* REDESIGNED "APPROACHING" SECTION (Data Stream Style) */}
                <div className="flex-1 overflow-y-auto p-6 bg-[#030303]">
                    <h3 className="text-xs font-bold text-white/40 uppercase tracking-widest mb-6 flex justify-between items-center">
                        Approaching <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_#22c55e]"></span>
                    </h3>
                    <div className="relative pl-4 space-y-6">
                        {/* Timeline Line */}
                        <div className="absolute left-0 top-2 bottom-2 w-px bg-gradient-to-b from-white/20 to-transparent"></div>
                        
                        {events.filter(e => e.date >= new Date().toISOString().split('T')[0]).slice(0, 6).map((event, i) => (
                            <div key={event.id} className="relative group pl-2">
                                {/* Node on Timeline */}
                                <div className={`absolute -left-[5px] top-1.5 w-2.5 h-2.5 rounded-full border-2 border-[#030303] ${event.type === 'ROUTINE_SUMMARY' ? 'bg-purple-500' : event.type === 'TASK' ? 'bg-blue-500' : 'bg-orange-500'} group-hover:scale-125 transition-transform z-10`}></div>
                                
                                <div className="flex flex-col gap-1">
                                    <span className="text-[10px] font-mono text-white/30 uppercase tracking-wider">{new Date(event.date).toLocaleDateString(undefined, {month:'short', day:'numeric'})}</span>
                                    <h4 className="text-sm font-bold text-white leading-tight group-hover:text-purple-300 transition-colors">{event.title}</h4>
                                    <div className="h-px w-full bg-white/5 mt-3 group-hover:bg-white/10 transition-colors"></div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* MAIN CONTENT AREA */}
            <div className="flex-1 flex flex-col h-full bg-[#020202] relative overflow-hidden">
                
                {/* Header Toolbar */}
                <div className="h-24 border-b border-white/10 flex items-center justify-between px-8 bg-[#050505]/80 backdrop-blur-xl z-30 flex-shrink-0">
                    <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                            <h2 className="text-4xl font-black text-white tracking-tighter uppercase">
                                {getHeaderText()}
                            </h2>
                            <span className="text-4xl font-thin text-white/20">{currentDate.getFullYear()}</span>
                        </div>
                        <div className="flex bg-[#1C1C1E] p-1 rounded-xl border border-white/10">
                            <button onClick={handlePrev} className="p-3 hover:bg-white/10 rounded-lg text-white/70 hover:text-white transition-colors"><ChevronLeft size={18}/></button>
                            <button onClick={handleToday} className="px-4 text-white hover:bg-white/10 rounded-lg transition-colors flex items-center justify-center">
                                <Target size={20} className="text-ios-purple"/>
                            </button>
                            <button onClick={handleNext} className="p-3 hover:bg-white/10 rounded-lg text-white/70 hover:text-white transition-colors"><ChevronRight size={18}/></button>
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                        <div className="flex bg-[#1C1C1E] p-1 rounded-xl border border-white/10">
                            <button onClick={() => setViewMode('MONTH')} className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'MONTH' ? 'bg-white text-black shadow-lg' : 'text-white/50 hover:text-white'}`}>Month</button>
                            <button onClick={() => setViewMode('WEEK')} className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'WEEK' ? 'bg-white text-black shadow-lg' : 'text-white/50 hover:text-white'}`}>Week</button>
                        </div>
                    </div>
                </div>

                {/* SCROLLABLE CONTENT */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-8">
                    
                    {/* VIEW: MONTH GRID */}
                    {viewMode === 'MONTH' && (
                        <div className="grid grid-cols-7 gap-px bg-white/10 border border-white/10 rounded-2xl overflow-hidden shadow-2xl animate-in fade-in duration-300">
                            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                                <div key={day} className="bg-[#0A0A0A] py-3 text-center text-[10px] font-black text-white/30 uppercase tracking-widest border-b border-white/5">
                                    {day}
                                </div>
                            ))}
                            {calendarDays.map((cell, idx) => {
                                const isToday = cell.dateStr === new Date().toISOString().split('T')[0];
                                return (
                                    <div key={idx} className={`min-h-[140px] bg-[#050505] hover:bg-[#0A0A0A] transition-colors p-3 flex flex-col gap-2 group relative border-white/5`}>
                                        {cell.date && (
                                            <>
                                                <div className="flex justify-between items-start">
                                                    <span className={`text-sm font-medium h-7 w-7 flex items-center justify-center rounded-full ${isToday ? 'bg-ios-purple text-white shadow-[0_0_10px_#A855F7]' : 'text-white/50 group-hover:text-white'}`}>
                                                        {cell.date}
                                                    </span>
                                                </div>
                                                <div className="flex flex-col gap-1.5 mt-1 overflow-y-auto max-h-[100px] no-scrollbar">
                                                    {cell.events.map(evt => (
                                                        <EventPill key={evt.id} evt={evt} compact />
                                                    ))}
                                                </div>
                                            </>
                                        )}
                                    </div>
                                )
                            })}
                        </div>
                    )}

                    {/* VIEW: WEEK GRID (COLUMNS) */}
                    {viewMode === 'WEEK' && (
                        <div className="grid grid-cols-7 gap-4 h-[600px] animate-in fade-in duration-300">
                            {weekDays.map((day, idx) => {
                                const isToday = day.dateStr === new Date().toISOString().split('T')[0];
                                return (
                                    <div key={idx} className={`flex flex-col rounded-2xl border ${isToday ? 'border-ios-purple/50 bg-ios-purple/5' : 'border-white/10 bg-[#1C1C1E]/50'} overflow-hidden`}>
                                        <div className={`p-4 border-b ${isToday ? 'border-ios-purple/20 bg-ios-purple/10' : 'border-white/5 bg-white/5'} text-center`}>
                                            <span className={`text-[10px] font-black uppercase tracking-widest block mb-1 ${isToday ? 'text-ios-purple' : 'text-white/40'}`}>
                                                {day.date.toLocaleDateString(undefined, {weekday:'short'})}
                                            </span>
                                            <span className={`text-2xl font-black ${isToday ? 'text-white' : 'text-white/80'}`}>{day.date.getDate()}</span>
                                        </div>
                                        <div className="flex-1 p-2 space-y-2 overflow-y-auto custom-scrollbar">
                                            {day.events.length === 0 && <div className="text-[10px] text-white/20 text-center mt-10 uppercase tracking-widest">Void</div>}
                                            {day.events.map(evt => <EventPill key={evt.id} evt={evt} />)}
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    )}

                    {/* SYSTEM YIELD (Formerly Monthly Synthesis) - REPLACED WITH REQUESTED COMPONENTS */}
                    <div className="bg-[#0A0A0A] border border-white/10 rounded-3xl p-8 relative overflow-hidden animate-in slide-in-from-bottom-8 duration-500">
                        {/* Background FX */}
                        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-900/10 rounded-full blur-[100px] pointer-events-none"></div>
                        
                        <div className="relative z-10">
                            <div className="flex justify-between items-end mb-8">
                                <div>
                                    <h3 className="text-sm font-bold text-ios-purple uppercase tracking-[0.3em] mb-2">Performance Analytics</h3>
                                    <h2 className="text-3xl font-black text-white tracking-tighter">System Yield</h2>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                
                                {/* 1. DAILY RITUALS (Consistency) */}
                                <div className="bg-[#1C1C1E] border border-white/5 rounded-2xl p-6 relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity"><Activity size={80}/></div>
                                    <h4 className="text-xs font-bold text-white/60 uppercase tracking-widest mb-4 flex items-center gap-2">
                                        <Flame size={14} className="text-orange-500"/> Daily Rituals
                                    </h4>
                                    <div className="flex items-end gap-2 mb-2">
                                        <span className="text-4xl font-black text-white">{routineRate}%</span>
                                        <span className="text-xs text-white/40 mb-1 font-medium">Consistency</span>
                                    </div>
                                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                                        <div className="h-full bg-gradient-to-r from-orange-500 to-red-500" style={{ width: `${routineRate}%` }}></div>
                                    </div>
                                </div>

                                {/* 2. TASK MATRIX (Execution) */}
                                <div className="bg-[#1C1C1E] border border-white/5 rounded-2xl p-6 relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity"><CheckSquare size={80}/></div>
                                    <h4 className="text-xs font-bold text-white/60 uppercase tracking-widest mb-4 flex items-center gap-2">
                                        <Layers size={14} className="text-blue-500"/> Task Matrix
                                    </h4>
                                    <div className="flex items-end gap-2 mb-2">
                                        <span className="text-4xl font-black text-white">{tasksDone}<span className="text-lg text-white/30">/{tasksTotal}</span></span>
                                        <span className="text-xs text-white/40 mb-1 font-medium">Completed</span>
                                    </div>
                                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                                        <div className="h-full bg-gradient-to-r from-blue-500 to-cyan-400" style={{ width: `${tasksTotal > 0 ? (tasksDone/tasksTotal)*100 : 0}%` }}></div>
                                    </div>
                                </div>

                                {/* 3. PLANS (Strategy) */}
                                <div className="bg-[#1C1C1E] border border-white/5 rounded-2xl p-6 relative overflow-hidden group">
                                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity"><Target size={80}/></div>
                                    <h4 className="text-xs font-bold text-white/60 uppercase tracking-widest mb-4 flex items-center gap-2">
                                        <Brain size={14} className="text-purple-500"/> Active Plans
                                    </h4>
                                    <div className="flex items-end gap-2 mb-2">
                                        <span className="text-4xl font-black text-white">{activePlans.length}</span>
                                        <span className="text-xs text-white/40 mb-1 font-medium">Strategic Directives</span>
                                    </div>
                                    <div className="flex gap-1 mt-3">
                                        {activePlans.slice(0, 5).map(p => (
                                            <div key={p.id} className="h-1 flex-1 rounded-full bg-purple-500/50"></div>
                                        ))}
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
};

const EventPill: React.FC<{ evt: CalendarEvent, compact?: boolean }> = ({ evt, compact }) => {
    let bgColor = 'bg-[#1C1C1E] border-white/10';
    let textColor = 'text-white';
    
    if (evt.type === 'ROUTINE_SUMMARY') {
        bgColor = 'bg-purple-500/10 border-purple-500/20';
        textColor = 'text-purple-300';
    } else if (evt.completed) {
        bgColor = 'bg-green-500/10 border-green-500/20';
        textColor = 'text-green-400';
    }

    return (
        <div className={`
            rounded-lg border flex items-center gap-2 cursor-pointer transition-all hover:scale-[1.02] hover:shadow-lg
            ${bgColor} ${textColor}
            ${compact ? 'px-2 py-1 text-[9px]' : 'px-3 py-2 text-xs'}
        `}>
            {evt.type === 'ROUTINE_SUMMARY' && <div className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse" />}
            {evt.type === 'TASK' && <CheckSquare size={10} className={evt.completed ? 'opacity-100' : 'opacity-50'} />}
            <span className={`truncate font-medium ${evt.completed && evt.type === 'TASK' ? 'line-through opacity-70' : ''}`}>{evt.title}</span>
        </div>
    )
}

const FilterToggle: React.FC<{ label: string, color: string, active: boolean, onClick: () => void }> = ({ label, color, active, onClick }) => (
    <div onClick={onClick} className="flex items-center gap-3 p-2 hover:bg-white/5 rounded-lg cursor-pointer group transition-all">
        <div className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all ${active ? `${color} border-transparent` : 'border-white/20 bg-transparent'}`}>
            {active && <CheckCircle2 size={12} className="text-white" />}
        </div>
        <span className={`text-sm font-medium transition-colors ${active ? 'text-white' : 'text-white/50 group-hover:text-white'}`}>{label}</span>
    </div>
);
