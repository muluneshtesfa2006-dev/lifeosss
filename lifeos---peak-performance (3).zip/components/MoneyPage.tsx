
import React, { useState, useEffect, useMemo } from 'react';
import { 
    Search, LayoutGrid, Activity, TrendingUp, DollarSign, 
    ArrowUpRight, ArrowDownLeft, Wallet, Plus, ArrowUpLeft, 
    ChevronDown, Layers, Download, Wifi, Sparkles, Briefcase, 
    Home, GraduationCap, Car, Target, ShoppingCart, Zap, 
    CandlestickChart, LineChart as LineChartIcon, Settings, 
    BarChart3, RefreshCcw, Lock, Globe, CreditCard, Send, X,
    Save, MoreHorizontal, MapPin, Gauge, Cpu, Zap as ZapIcon,
    ArrowRight, ZoomIn, ZoomOut, MousePointer2, Move, Maximize2,
    Calendar, Sliders, Eye, Share2, MoreVertical, Repeat, Gem,
    ArrowLeftRight, Coins, History, TrendingDown, Map as MapIcon,
    PieChart as PieChartIcon, FileText, Flame, ArrowDown, CreditCard as CardIcon,
    EyeOff, Command, Filter, AlertTriangle, PlayCircle, Shield, AlertCircle,
    CalendarDays, Clock, Tag, FileDigit, ChevronUp, Landmark, Percent, Mail, Phone,
    Users, Bitcoin, CreditCard as MasterIcon
} from 'lucide-react';
import { 
    ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, Tooltip, 
    CartesianGrid, XAxis, YAxis, BarChart, Bar, ComposedChart, Line, LineChart,
    RadialBarChart, RadialBar, PolarAngleAxis, Brush, ReferenceLine, ErrorBar
} from 'recharts';

// --- MOCK DATA (STATIC - PREVENT RE-CALCULATION) ---

const generateMarketData = (points: number, basePrice: number) => {
    let price = basePrice;
    return Array.from({ length: points }, (_, i) => {
        const volatility = basePrice * 0.02;
        const change = (Math.random() - 0.5) * volatility;
        const open = price;
        const close = price + change;
        const high = Math.max(open, close) + Math.random() * (volatility * 0.2);
        const low = Math.min(open, close) - Math.random() * (volatility * 0.2);
        price = close; 
        return {
            name: i,
            date: new Date(Date.now() - (points - i) * 86400000).toLocaleDateString(),
            open, close, high, low, value: close, 
            isUp: close >= open
        };
    });
};

// Memoize at module level so it doesn't regen on component mount
const STATIC_CHART_DATA = generateMarketData(40, 14500);

const MOVERS_DATA = {
    gainers: [
        { sym: 'NVDA', name: 'Nvidia Corp', change: 4.2, price: 485.02 },
        { sym: 'BTC', name: 'Bitcoin', change: 2.8, price: 42100.50 },
        { sym: 'TSLA', name: 'Tesla Inc', change: 1.5, price: 245.30 },
    ],
    losers: [
        { sym: 'AAPL', name: 'Apple Inc', change: -1.2, price: 185.90 },
        { sym: 'ETH', name: 'Ethereum', change: -0.8, price: 2250.10 },
        { sym: 'AMZN', name: 'Amazon.com', change: -0.5, price: 145.20 },
    ]
};

// --- TYPES ---

interface FiscalItem {
    id: string;
    type: 'BUDGET' | 'INVESTMENT';
    name: string;
    category: string;
    amount: number;
    spent?: number;
    costBasis?: number;
    startDate: string;
    status: 'ACTIVE' | 'PENDING' | 'COMPLETED';
    transactions: any[];
    history: any[];
}

const INITIAL_FISCAL_ITEMS: FiscalItem[] = [
    { 
        id: 'b1', type: 'BUDGET', name: 'Cloud Infrastructure', category: 'Business', 
        amount: 2500, spent: 1240.50, startDate: '2023-10-01', status: 'ACTIVE',
        transactions: [], history: generateMarketData(20, 1000)
    },
    {
        id: 'i1', type: 'INVESTMENT', name: 'Nvidia Corp (NVDA)', category: 'Equities',
        amount: 14500, costBasis: 8000, startDate: '2022-05-12', status: 'ACTIVE', 
        transactions: [], history: generateMarketData(30, 12000)
    }
];

// Optimized Chart Component to prevent re-renders of the heavy Recharts library
const OptimizedChart = React.memo(({ data, mode }: { data: any[], mode: 'AREA' | 'CANDLE' }) => {
    return (
        <ResponsiveContainer width="100%" height="100%">
            {mode === 'AREA' ? (
                <AreaChart data={data}>
                    <defs>
                        <linearGradient id="colorMain" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#A855F7" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#A855F7" stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#666', fontSize: 10}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#666', fontSize: 10}} domain={['auto', 'auto']} />
                    <Tooltip 
                        contentStyle={{backgroundColor: '#000', border: '1px solid #333', borderRadius: '12px', color: '#fff'}}
                        itemStyle={{color: '#fff', fontSize: '12px', fontWeight: 'bold'}}
                    />
                    <Area type="monotone" dataKey="value" stroke="#A855F7" strokeWidth={3} fill="url(#colorMain)" />
                </AreaChart>
            ) : (
                <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#666', fontSize: 10}} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#666', fontSize: 10}} domain={['auto', 'auto']} />
                    <Tooltip 
                        cursor={{fill: 'rgba(255,255,255,0.05)'}}
                        contentStyle={{backgroundColor: '#000', border: '1px solid #333', borderRadius: '12px', color: '#fff'}}
                    />
                    <Bar dataKey="high" fill="transparent" stroke="none" /> 
                    <Bar dataKey="value" shape={(props: any) => {
                        const { x, y, width, height, payload } = props;
                        const isUp = payload.close >= payload.open;
                        const color = isUp ? '#10B981' : '#EF4444';
                        
                        return (
                            <g>
                                <line x1={x + width/2} y1={y} x2={x + width/2} y2={y + height} stroke={color} strokeWidth={1} />
                                <rect x={x} y={y + height/4} width={width} height={height/2} fill={color} />
                            </g>
                        );
                    }}>
                        {data.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.close > entry.open ? '#10B981' : '#EF4444'} />
                        ))}
                    </Bar>
                </BarChart>
            )}
        </ResponsiveContainer>
    );
});

export const MoneyPage: React.FC = () => {
    // Navigation State
    const [currentView, setCurrentView] = useState<'OVERVIEW' | 'BUDGETS' | 'INVESTMENTS' | 'TRANSACTIONS'>('OVERVIEW');
    
    // Data State
    const [chartMode, setChartMode] = useState<'AREA' | 'CANDLE'>('AREA');
    const [fiscalItems, setFiscalItems] = useState<FiscalItem[]>(INITIAL_FISCAL_ITEMS);
    
    // --- RENDERERS ---

    const renderOverview = useMemo(() => (
        <div className="flex-1 overflow-y-auto custom-scrollbar p-8 pb-32 space-y-8 animate-in fade-in duration-500 relative">
            
            {/* TOP ROW: WALLET (LEFT) + CHART (RIGHT) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-auto lg:h-[450px]">
                
                {/* 1. MASTERCARD WALLET (LEFT - SPANS 4) */}
                <div className="lg:col-span-4 flex flex-col gap-6">
                    <div className="flex-1 bg-gradient-to-br from-[#1a1a1a] to-black rounded-[2.5rem] p-8 border border-white/10 relative overflow-hidden group shadow-2xl flex flex-col justify-between min-h-[300px]">
                        {/* Card Gloss/Texture */}
                        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 mix-blend-overlay"></div>
                        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-gradient-to-br from-white/10 via-transparent to-transparent rotate-45 pointer-events-none"></div>
                        
                        {/* Top Section */}
                        <div className="relative z-10 flex justify-between items-start">
                            <MasterIcon size={40} className="text-white/80" />
                            <span className="text-xl font-black italic text-white/50 tracking-widest">LifeOS</span>
                        </div>

                        {/* Chip & Contactless */}
                        <div className="relative z-10 flex items-center gap-4 my-8">
                            <div className="w-12 h-10 rounded-lg bg-gradient-to-br from-yellow-200 to-yellow-500 border border-yellow-600 shadow-inner flex items-center justify-center opacity-90">
                                <div className="w-full h-[1px] bg-black/20 absolute top-1/2 -translate-y-1/2"></div>
                                <div className="h-full w-[1px] bg-black/20 absolute left-1/2 -translate-x-1/2"></div>
                                <div className="w-6 h-4 border border-black/20 rounded-sm"></div>
                            </div>
                            <Wifi size={24} className="text-white/50 rotate-90" />
                        </div>

                        {/* Balance Section */}
                        <div className="relative z-10 mt-auto">
                            <div className="flex justify-between items-end mb-2">
                                <span className="text-xs font-bold text-white/40 uppercase tracking-[0.2em]">Total Net Worth</span>
                            </div>
                            <h2 className="text-4xl lg:text-5xl font-mono font-medium text-white tracking-tight text-shadow-glow mb-6">
                                $14,632.57
                            </h2>
                            <div className="flex justify-between items-center">
                                <div className="text-sm font-mono text-white/60 tracking-[0.2em]">**** **** **** 4921</div>
                                <span className="text-[10px] font-bold text-white/40">EXP 12/28</span>
                            </div>
                        </div>
                    </div>
                    
                    {/* Mini Actions under card */}
                    <div className="grid grid-cols-2 gap-4">
                        <button className="bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-white/10 rounded-2xl p-4 flex items-center justify-center gap-2 transition-colors group">
                            <ArrowUpRight className="text-green-400 group-hover:scale-110 transition-transform" />
                            <span className="font-bold text-sm">Deposit</span>
                        </button>
                        <button className="bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-white/10 rounded-2xl p-4 flex items-center justify-center gap-2 transition-colors group">
                            <ArrowDownLeft className="text-red-400 group-hover:scale-110 transition-transform" />
                            <span className="font-bold text-sm">Withdraw</span>
                        </button>
                    </div>
                </div>

                {/* 2. NET WORTH GRAPH (RIGHT - SPANS 8) */}
                <div className="lg:col-span-8 bg-[#050505] rounded-[2.5rem] p-8 border border-white/10 relative overflow-hidden shadow-2xl flex flex-col">
                    <div className="relative z-10 flex justify-between items-center mb-6">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <Activity size={16} className="text-purple-500" />
                                <span className="text-xs font-bold text-white/40 uppercase tracking-[0.2em]">Asset Performance</span>
                            </div>
                            <h3 className="text-2xl font-bold text-white">Market Value</h3>
                        </div>
                        
                        <div className="flex items-center gap-2 bg-[#111] p-1 rounded-xl border border-white/5">
                            <button 
                                onClick={() => setChartMode('AREA')}
                                className={`p-2 rounded-lg transition-all ${chartMode === 'AREA' ? 'bg-white/10 text-white' : 'text-white/30 hover:text-white'}`}
                            >
                                <TrendingUp size={18}/>
                            </button>
                            <button 
                                onClick={() => setChartMode('CANDLE')}
                                className={`p-2 rounded-lg transition-all ${chartMode === 'CANDLE' ? 'bg-white/10 text-white' : 'text-white/30 hover:text-white'}`}
                            >
                                <CandlestickChart size={18}/>
                            </button>
                            <div className="w-px h-6 bg-white/10 mx-1"></div>
                            {['1D', '1W', '1M', '1Y', 'ALL'].map(t => (
                                <button key={t} className="px-3 py-1 text-[10px] font-bold text-white/40 hover:text-white transition-colors">{t}</button>
                            ))}
                        </div>
                    </div>

                    <div className="flex-1 w-full min-h-0 relative">
                        <OptimizedChart data={STATIC_CHART_DATA} mode={chartMode} />
                    </div>
                </div>
            </div>

            {/* MIDDLE ROW: GAINERS & LOSERS LISTS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Gainers */}
                <div className="bg-[#0A0A0A] border border-white/5 rounded-3xl p-6">
                    <div className="flex items-center gap-2 mb-6">
                        <div className="p-2 bg-green-500/10 rounded-lg text-green-500"><TrendingUp size={18}/></div>
                        <h3 className="text-sm font-bold text-white uppercase tracking-widest">Top Gainers</h3>
                    </div>
                    <div className="space-y-4">
                        {MOVERS_DATA.gainers.map((m, i) => (
                            <div key={i} className="flex items-center justify-between p-3 hover:bg-white/5 rounded-xl transition-colors cursor-pointer group">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-[#111] flex items-center justify-center text-xs font-bold text-white border border-white/10">{m.sym}</div>
                                    <div>
                                        <div className="text-sm font-bold text-white">{m.name}</div>
                                        <div className="text-xs text-white/40">${m.price}</div>
                                    </div>
                                </div>
                                <div className="text-green-400 font-bold text-sm bg-green-500/10 px-2 py-1 rounded">+{m.change}%</div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Losers */}
                <div className="bg-[#0A0A0A] border border-white/5 rounded-3xl p-6">
                    <div className="flex items-center gap-2 mb-6">
                        <div className="p-2 bg-red-500/10 rounded-lg text-red-500"><TrendingDown size={18}/></div>
                        <h3 className="text-sm font-bold text-white uppercase tracking-widest">Top Losers</h3>
                    </div>
                    <div className="space-y-4">
                        {MOVERS_DATA.losers.map((m, i) => (
                            <div key={i} className="flex items-center justify-between p-3 hover:bg-white/5 rounded-xl transition-colors cursor-pointer group">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-full bg-[#111] flex items-center justify-center text-xs font-bold text-white border border-white/10">{m.sym}</div>
                                    <div>
                                        <div className="text-sm font-bold text-white">{m.name}</div>
                                        <div className="text-xs text-white/40">${m.price}</div>
                                    </div>
                                </div>
                                <div className="text-red-400 font-bold text-sm bg-red-500/10 px-2 py-1 rounded">{m.change}%</div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    ), [chartMode]); // Only re-render overview if chartMode changes

    const renderPlanner = () => {
        const items = fiscalItems.filter(i => currentView === 'BUDGETS' ? i.type === 'BUDGET' : i.type === 'INVESTMENT');
        return (
            <div className="flex-1 p-8 overflow-y-auto custom-scrollbar">
                <div className="flex justify-between items-center mb-8">
                    <h2 className="text-3xl font-black text-white tracking-tighter uppercase">{currentView}</h2>
                    <button className="bg-white text-black px-6 py-2 rounded-xl font-bold text-sm uppercase tracking-wider flex items-center gap-2 hover:scale-105 transition-transform">
                        <Plus size={16}/> New Entry
                    </button>
                </div>
                <div className="grid grid-cols-1 gap-4">
                    {items.length === 0 ? (
                        <div className="text-center py-20 text-white/30 text-sm uppercase tracking-widest border border-dashed border-white/10 rounded-3xl">No records found</div>
                    ) : (
                        items.map(item => (
                            <div key={item.id} className="bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 flex justify-between items-center">
                                <div>
                                    <h3 className="font-bold text-white text-lg">{item.name}</h3>
                                    <span className="text-xs text-white/40 uppercase">{item.category}</span>
                                </div>
                                <div className="text-right">
                                    <div className="text-xl font-mono text-white font-bold">${item.amount.toLocaleString()}</div>
                                    <div className="text-xs text-green-400">Active</div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        );
    };

    return (
        <div className="flex h-full w-full bg-[#020202] text-white font-sans overflow-hidden relative selection:bg-purple-500/30">
            
            {/* MAIN CONTENT AREA */}
            <div className="flex-1 flex flex-col h-full relative z-10">
                {currentView === 'OVERVIEW' ? renderOverview : renderPlanner()}
            </div>

            {/* FLOATING NAVIGATION TOOLBAR */}
            <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50">
                <div className="bg-[#1C1C1E]/90 backdrop-blur-xl border border-white/10 rounded-full p-2 pl-3 flex items-center gap-1 shadow-[0_20px_50px_rgba(0,0,0,0.8)] ring-1 ring-white/5">
                    <button 
                        onClick={() => setCurrentView('OVERVIEW')}
                        className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${currentView === 'OVERVIEW' ? 'bg-white text-black shadow-lg' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
                    >
                        <LayoutGrid size={14}/> Overview
                    </button>
                    <div className="w-px h-6 bg-white/10 mx-1"></div>
                    <button 
                        onClick={() => setCurrentView('BUDGETS')}
                        className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${currentView === 'BUDGETS' ? 'bg-white text-black shadow-lg' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
                    >
                        <PieChartIcon size={14}/> Budgets
                    </button>
                    <button 
                        onClick={() => setCurrentView('INVESTMENTS')}
                        className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${currentView === 'INVESTMENTS' ? 'bg-white text-black shadow-lg' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
                    >
                        <Briefcase size={14}/> Assets
                    </button>
                    <button 
                        onClick={() => setCurrentView('TRANSACTIONS')}
                        className={`px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${currentView === 'TRANSACTIONS' ? 'bg-white text-black shadow-lg' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
                    >
                        <ArrowLeftRight size={14}/> Transfers
                    </button>
                </div>
            </div>
        </div>
    );
};
