import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Routine, RoutineLog, UserStats, RoutineFrequency, StatCategory, Task, Subtask } from '../types';
import { StorageService } from '../services/storageService';
import { 
  Check, Flame, Calendar as CalendarIcon, Filter, 
  MoreHorizontal, Plus, X, Clock, Target, Trash2,
  ChevronLeft, ChevronRight, Play, Square, Circle, Layout, Zap, CheckSquare,
  Search, AlignLeft, Brain, ArrowUpRight, Shield, Layers, Activity, CalendarDays,
  List, Edit3, ChevronDown, ChevronUp
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, XAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';

const QUOTES = [
    "Discipline is freedom.",
    "Focus on the signal, ignore the noise.",
    "Execute with intent.",
    "Momentum is everything.",
    "Build the future, brick by brick.",
    "Consistency compounds.",
    "Do it for the person you're becoming.",
    "Action cures fear.",
    "Simplicity is the ultimate sophistication."
];

// --- VISUAL COMPONENTS ---

const ConsistencyGraph: React.FC<{ logs: RoutineLog[] }> = React.memo(({ logs }) => {
    const data = useMemo(() => {
        return Array.from({length: 30}, (_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - (29 - i));
            const iso = d.toISOString().split('T')[0];
            const count = logs.filter(l => l.date === iso).length;
            return { day: iso, score: count };
        });
    }, [logs]);

    return (
        <div className="h-24 w-full bg-[#080808] rounded-xl border border-white/5 relative overflow-hidden mb-6">
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                    <defs>
                        <linearGradient id="colorWave" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#A855F7" stopOpacity={0.6}/>
                            <stop offset="95%" stopColor="#A855F7" stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <Tooltip cursor={false} content={<></>} />
                    <Area 
                        type="monotone" 
                        dataKey="score" 
                        stroke="#A855F7" 
                        strokeWidth={2} 
                        fill="url(#colorWave)" 
                        animationDuration={1500}
                    />
                </AreaChart>
            </ResponsiveContainer>
        </div>
    )
});

const TaskConsistencyGraph: React.FC<{ tasks: Task[] }> = React.memo(({ tasks }) => {
    const data = useMemo(() => {
        return Array.from({length: 30}, (_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - (29 - i));
            const iso = d.toISOString().split('T')[0];
            const count = tasks.filter(t => t.date === iso && t.completed).length;
            return { day: iso, score: count };
        });
    }, [tasks]);

    return (
        <div className="h-28 w-full opacity-90 hover:opacity-100 transition-opacity">
             <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                    <Tooltip cursor={{fill: 'rgba(168,85,247,0.1)'}} content={<></>} />
                    <Bar 
                        dataKey="score" 
                        fill="#A855F7" 
                        radius={[4, 4, 0, 0]}
                        barSize={12}
                        animationDuration={1500}
                    />
                </BarChart>
            </ResponsiveContainer>
        </div>
    )
});

const CompactCalendarStrip: React.FC<{ 
    selectedDate: Date, 
    onSelect: (d: Date) => void,
    offset: number,
    onPrev: () => void,
    onNext: () => void
}> = ({ selectedDate, onSelect, offset, onPrev, onNext }) => {
    const dates = useMemo(() => {
        const d = new Date();
        const start = new Date(d.setDate(d.getDate() - d.getDay() + (offset * 7))); // Week offset logic
        return Array.from({length: 7}, (_, i) => {
            const date = new Date(start);
            date.setDate(start.getDate() + i);
            return date;
        });
    }, [offset]);

    return (
        <div className="flex items-center gap-2 mb-2 pb-1">
            <button onClick={onPrev} className="p-1.5 bg-[#0A0A0A] hover:bg-white/10 rounded-lg border border-white/5 text-white/50 hover:text-white transition-colors"><ChevronLeft size={12}/></button>
            <div className="flex-1 flex justify-between gap-1 overflow-x-auto no-scrollbar">
                {dates.map((date, i) => {
                    const isSelected = date.toDateString() === selectedDate.toDateString();
                    const isToday = date.toDateString() === new Date().toDateString();
                    return (
                        <button 
                            key={i} 
                            onClick={() => onSelect(date)}
                            className={`
                                flex-1 flex flex-col items-center py-1 rounded-lg border transition-all duration-200 min-w-[2.5rem]
                                ${isSelected 
                                    ? 'bg-purple-600 text-white border-purple-500 scale-105 shadow-lg shadow-purple-900/20' 
                                    : 'bg-[#0A0A0A] text-white/30 border-white/5 hover:border-purple-500/30 hover:text-purple-400'}
                            `}
                        >
                            <span className="text-[7px] font-bold uppercase tracking-widest mb-0.5 opacity-80">{date.toLocaleDateString('en-US', {weekday: 'short'})}</span>
                            <span className="text-xl font-mono font-bold tracking-tighter">{date.getDate()}</span>
                            {isToday && !isSelected && <div className="w-1 h-1 bg-purple-500 rounded-full mt-0.5"></div>}
                        </button>
                    )
                })}
            </div>
            <button onClick={onNext} className="p-1.5 bg-[#0A0A0A] hover:bg-white/10 rounded-lg border border-white/5 text-white/50 hover:text-white transition-colors"><ChevronRight size={12}/></button>
        </div>
    )
}

const RoutineCard: React.FC<{ 
    routine: Routine, 
    logs: RoutineLog[], 
    onToggle: (r: Routine, date?: string) => void, 
    onSubroutineToggle: (rId: string, sId: string, date?: string) => void,
    onEdit: () => void,
    onDelete: () => void 
}> = React.memo(({ routine, logs, onToggle, onSubroutineToggle, onEdit, onDelete }) => {
    const [showFullDesc, setShowFullDesc] = useState(false);
    const [tickerOffset, setTickerOffset] = useState(0); // Weeks back
    
    // Calculate display days based on offset
    const days = useMemo(() => {
        return Array.from({length: 7}, (_, i) => {
            const d = new Date();
            // Shift date by offset weeks
            d.setDate(d.getDate() - (6 - i) + (tickerOffset * 7));
            return {
                iso: d.toISOString().split('T')[0],
                letter: d.toLocaleDateString('en-US', { weekday: 'narrow' }),
                isToday: d.toDateString() === new Date().toDateString(),
                isFuture: d > new Date()
            };
        });
    }, [tickerOffset]);

    return (
        <div className={`bg-gradient-to-b from-[#111] to-[#0A0A0A] border border-white/5 rounded-xl p-5 hover:border-purple-500/30 transition-all group relative overflow-hidden`}>
            {/* Subtle Glow on Hover */}
            <div className="absolute inset-0 bg-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
            
            <div className="relative z-10 flex justify-between items-start mb-2">
                <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                        <h4 className="font-bold text-lg text-white leading-none group-hover/title:text-purple-400 transition-colors">{routine.title}</h4>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] font-bold text-white/30 uppercase tracking-wider mb-2">
                        <span className="flex items-center gap-1"><Clock size={10}/> {routine.time}</span>
                        <span className="text-purple-500">+{routine.xpReward} XP</span>
                    </div>
                </div>
                {/* ALWAYS VISIBLE ACTIONS */}
                <div className="flex gap-2">
                    <button onClick={onEdit} className="text-white/20 hover:text-white transition-colors"><Edit3 size={16}/></button>
                    <button onClick={onDelete} className="text-white/20 hover:text-red-500 transition-colors"><Trash2 size={16}/></button>
                </div>
            </div>

            {/* DESCRIPTION & SUBROUTINES (VISIBLE BY DEFAULT) */}
            <div className="relative z-10 mb-4">
                {routine.description && (
                    <div className="mb-3">
                        <p className={`text-sm text-white/60 leading-relaxed bg-black/40 rounded-lg p-3 border border-white/5 ${showFullDesc ? '' : 'line-clamp-4'}`}>
                            {routine.description}
                        </p>
                        {routine.description.length > 200 && (
                            <button 
                                onClick={() => setShowFullDesc(!showFullDesc)} 
                                className="text-[9px] font-bold text-white/60 mt-1 hover:text-white uppercase tracking-wide"
                            >
                                {showFullDesc ? 'Show Less' : 'See More'}
                            </button>
                        )}
                    </div>
                )}
                
                {routine.subroutines && routine.subroutines.length > 0 && (
                    <div className="space-y-3 pl-1 mb-4">
                        <h5 className="text-[10px] font-bold text-white/40 uppercase">Sub-Directives</h5>
                        {routine.subroutines.map(sub => (
                            <div key={sub.id} className="bg-[#0F0F0F] rounded-lg p-2 border border-white/5">
                                <div className="flex justify-between items-center mb-2">
                                    <span className="text-xs font-medium text-white/80">{sub.title}</span>
                                </div>
                                {/* SUBROUTINE TICKER - RECTANGLES */}
                                <div className="flex justify-between items-center gap-0.5">
                                    {days.map((d) => {
                                        const log = logs.find(l => l.routineId === routine.id && l.date === d.iso);
                                        const isSubDone = log?.completedSubtasks?.includes(sub.id) || false;
                                        return (
                                            <div key={`${sub.id}-${d.iso}`} className="flex flex-col items-center flex-1">
                                                <button 
                                                    onClick={() => !d.isFuture && onSubroutineToggle(routine.id, sub.id, d.iso)}
                                                    disabled={d.isFuture}
                                                    className={`
                                                        w-full h-4 rounded-[2px] transition-all duration-150 relative overflow-hidden flex items-center justify-center
                                                        ${isSubDone 
                                                            ? 'bg-purple-500/80 border border-purple-400' 
                                                            : d.isToday 
                                                                ? 'bg-white/10 border border-white/30' 
                                                                : 'bg-transparent border border-white/10'}
                                                        ${d.isFuture ? 'opacity-20 cursor-default' : 'cursor-pointer hover:border-purple-500'}
                                                    `}
                                                >
                                                    {isSubDone && <div className="w-1.5 h-1.5 bg-black rounded-full" />}
                                                </button>
                                            </div>
                                        )
                                    })}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

            {/* MAIN ROUTINE TICKER w/ NAVIGATION */}
            <div className="flex items-center gap-2 relative z-10">
                <button onClick={() => setTickerOffset(o => o - 1)} className="p-1 text-white/20 hover:text-white transition-colors"><ChevronLeft size={16}/></button>
                <div className="flex-1 flex justify-between items-center bg-black/40 rounded-lg p-2 px-3 border border-white/5">
                    {days.map((d) => {
                        const isDone = logs.some(l => l.routineId === routine.id && l.date === d.iso);
                        return (
                            <div key={d.iso} className="flex flex-col items-center gap-1.5">
                                <span className={`text-[8px] font-bold uppercase ${d.isToday ? 'text-purple-400' : 'text-white/10'}`}>{d.letter}</span>
                                <button 
                                    onClick={() => !d.isFuture && onToggle(routine, d.iso)}
                                    disabled={d.isFuture}
                                    className={`
                                        w-7 h-7 rounded-full transition-all duration-150 relative overflow-hidden flex items-center justify-center active:scale-90
                                        ${isDone 
                                            ? 'bg-purple-500 shadow-[0_0_10px_#A855F7] border border-purple-400 text-white' 
                                            : d.isToday 
                                                ? 'bg-white/10 border-2 border-white/40 hover:bg-white/20 text-white' 
                                                : 'bg-transparent border-2 border-white/10 hover:border-white/30 text-white/30'}
                                        ${d.isFuture ? 'opacity-20 cursor-default' : 'cursor-pointer'}
                                    `}
                                >
                                    {isDone && <Check size={14} strokeWidth={4} />}
                                </button>
                            </div>
                        )
                    })}
                </div>
                <button onClick={() => setTickerOffset(o => o + 1)} className="p-1 text-white/20 hover:text-white transition-colors" disabled={tickerOffset >= 0}><ChevronRight size={16}/></button>
            </div>
        </div>
    )
});

const RectTaskCard: React.FC<{ 
    task: Task, 
    onToggle: () => void, 
    onSubtaskToggle: (id: string) => void, 
    onEdit: () => void,
    onDelete: () => void
}> = React.memo(({ task, onToggle, onSubtaskToggle, onEdit, onDelete }) => {
    const subtasks = task.subtasks || [];
    
    // Priority Colors Config
    let priorityClass = 'text-blue-400 border-blue-900/50 bg-blue-900/10';
    if (task.priority === 'High') priorityClass = 'text-red-400 border-red-900/50 bg-red-900/10';
    if (task.priority === 'Medium') priorityClass = 'text-orange-500 border-orange-900/50 bg-orange-900/10';
    if (task.priority === 'Low') priorityClass = 'text-orange-100 border-orange-200/20 bg-orange-500/5';

    return (
        <div className={`
            bg-[#0A0A0A] border rounded-lg p-5 transition-all group relative overflow-hidden
            ${task.completed 
                ? 'border-purple-500/50 shadow-[0_0_30px_rgba(147,51,234,0.1)] opacity-70' 
                : 'border-white/10 hover:border-purple-500/30'}
        `}>
            <div className="relative z-10 flex items-start gap-4 pl-2">
                <button 
                    onClick={onToggle} 
                    className={`
                        mt-1 w-6 h-6 rounded-full border flex-shrink-0 flex items-center justify-center transition-all duration-150 active:scale-90
                        ${task.completed 
                            ? 'bg-purple-600 border-purple-500 text-white shadow-[0_0_15px_#A855F7]' 
                            : 'border-white/20 hover:border-white text-transparent'}
                    `}
                >
                    <Check size={14} strokeWidth={4} />
                </button>
                
                <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-2">
                        <h4 className={`text-lg font-bold leading-tight transition-colors ${task.completed ? 'text-purple-300 line-through' : 'text-white'}`}>
                            {task.title}
                        </h4>
                        {/* ALWAYS VISIBLE ACTIONS */}
                        <div className="flex gap-2">
                            <button onClick={onEdit} className="text-white/20 hover:text-white transition-colors"><Edit3 size={16}/></button>
                            <button onClick={onDelete} className="text-white/20 hover:text-red-500 transition-colors"><Trash2 size={16}/></button>
                        </div>
                    </div>
                    
                    {/* Details - Always Visible */}
                    {task.description && (
                        <p className="text-sm text-white/60 leading-relaxed bg-[#111] p-3 rounded border border-white/5 mb-3">
                            {task.description}
                        </p>
                    )}

                    {subtasks.length > 0 && (
                        <div className="space-y-2 pl-1 mb-4 mt-2">
                            {subtasks.map(s => (
                                <div key={s.id} className="flex items-center gap-3 group/sub cursor-pointer py-1" onClick={() => onSubtaskToggle(s.id)}>
                                    <div className={`w-4 h-4 rounded border flex items-center justify-center transition-all duration-150 active:scale-90 ${s.completed ? 'bg-purple-500 border-purple-500' : 'border-white/20 bg-transparent group-hover/sub:border-white'}`}>
                                        {s.completed && <Check size={10} className="text-black" strokeWidth={4}/>}
                                    </div>
                                    <span className={`text-sm font-medium transition-colors ${s.completed ? 'text-purple-400 line-through' : 'text-white/80'}`}>{s.title}</span>
                                </div>
                            ))}
                        </div>
                    )}
                    
                    {/* Metadata Row */}
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                        <span className="text-[9px] font-bold uppercase tracking-wider text-white/30 border border-white/10 px-2 py-1 rounded bg-[#111]">{task.category}</span>
                        <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-1 rounded border ${priorityClass}`}>
                            {task.priority || 'Medium'} Priority
                        </span>
                        <span className="text-[9px] font-bold uppercase tracking-wider text-white/20 border border-white/5 px-2 py-1 rounded bg-[#111]">
                            {new Date(task.date).toLocaleDateString()}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    )
});

const RectMacroCard: React.FC<{ 
    routine: Routine, 
    logs: RoutineLog[], 
    onToggle: (r: Routine) => void, 
    view: 'WEEKLY' | 'MONTHLY', 
    onEdit: () => void,
    onDelete: () => void 
}> = React.memo(({ routine, logs, onToggle, view, onEdit, onDelete }) => {
    const isDone = logs.some(l => l.routineId === routine.id && l.completed); 

    return (
        <div 
            onClick={() => !isDone && onToggle(routine)}
            className={`
                bg-[#0A0A0A] border rounded-lg p-5 transition-all group relative overflow-hidden
                ${isDone 
                    ? 'border-purple-500/50 shadow-[0_0_30px_rgba(147,51,234,0.15)] opacity-70' 
                    : 'border-white/10 hover:border-purple-500/30'}
            `}
        >
            <div className="flex items-start gap-4 pl-2">
                <button 
                    className={`
                        mt-1 w-6 h-6 rounded-md border-2 flex-shrink-0 flex items-center justify-center transition-all duration-150 active:scale-90
                        ${isDone 
                            ? 'bg-purple-500 border-purple-500 text-black' 
                            : 'border-white/20 bg-transparent group-hover:border-white'}
                    `}
                >
                    {isDone && <Check size={16} strokeWidth={3}/>}
                </button>

                <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-2">
                        <h3 className={`text-lg font-bold leading-tight ${isDone ? 'text-white/50 line-through' : 'text-white'}`}>{routine.title}</h3>
                        <div className="flex gap-2" onClick={e => e.stopPropagation()}>
                            <button onClick={onEdit} className="text-white/20 hover:text-white transition-colors"><Edit3 size={16}/></button>
                            <button onClick={onDelete} className="text-white/20 hover:text-red-500 transition-colors"><Trash2 size={16}/></button>
                        </div>
                    </div>
                    
                    <p className="text-sm text-white/50 leading-relaxed mb-4 bg-[#111] p-3 rounded border border-white/5">
                        {routine.description || 'Recurring strategic objective.'}
                    </p>

                    <div className="flex items-center gap-2 mt-1">
                        <span className="text-[9px] font-bold uppercase tracking-wider text-white/30 border border-white/10 px-2 py-1 rounded bg-[#111]">{view} Protocol</span>
                        <span className="text-[9px] font-bold uppercase tracking-wider text-purple-500 border border-purple-500/30 bg-purple-500/10 px-2 py-1 rounded">+{routine.xpReward} XP</span>
                    </div>
                </div>
            </div>
        </div>
    )
});

// --- UNIFIED MODAL (Mission Briefing Style) ---
const UnifiedCreateModal: React.FC<{ 
    type: 'ROUTINE' | 'TASK',
    onClose: () => void, 
    onSaveRoutine: (r: Routine) => void, 
    onSaveTask: (t: Task) => void,
    onDeleteRoutine: (id: string) => void,
    onDeleteTask: (id: string) => void,
    existingRoutine: Routine | null,
    existingTask: Task | null,
    frequency: string 
}> = ({ type, onClose, onSaveRoutine, onSaveTask, onDeleteRoutine, onDeleteTask, existingRoutine, existingTask, frequency }) => {
    
    const [title, setTitle] = useState(existingRoutine?.title || existingTask?.title || '');
    const [desc, setDesc] = useState(existingRoutine?.description || existingTask?.description || '');
    const [timeEst, setTimeEst] = useState('15m');
    const [tools, setTools] = useState('');
    const [energy, setEnergy] = useState('High');
    const [xp, setXp] = useState(existingRoutine?.xpReward || 50);
    const [cat, setCat] = useState<StatCategory>(existingRoutine?.category || 'Mental');
    const [freq, setFreq] = useState<RoutineFrequency>(existingRoutine?.frequency || frequency as any);
    const [priority, setPriority] = useState<any>(existingTask?.priority || 'Medium');
    const [subtasks, setSubtasks] = useState<Subtask[]>(existingTask?.subtasks || existingRoutine?.subroutines || []);
    const [newSubtask, setNewSubtask] = useState('');
    const [activeTab, setActiveTab] = useState<'CORE' | 'LOGISTICS' | 'CONTEXT'>('CORE');

    const handleSubmit = () => {
        if(!title) return;
        const fullDesc = desc;

        if (type === 'ROUTINE') {
            onSaveRoutine({
                id: existingRoutine?.id || Math.random().toString(36).substr(2, 9),
                title, description: fullDesc, xpReward: xp, category: cat, frequency: freq, time: '09:00',
                subroutines: subtasks // Save subtasks
            });
        } else {
            onSaveTask({
                id: existingTask?.id || Math.random().toString(36).substr(2, 9),
                title, description: fullDesc, priority, 
                category: cat as any, subtasks,
                completed: existingTask?.completed || false,
                status: existingTask?.status || 'todo',
                createdAt: existingTask?.createdAt || Date.now(),
                date: new Date().toISOString().split('T')[0]
            });
        }
    }

    return (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-[#050505] border border-white/10 w-full max-w-2xl rounded-2xl shadow-2xl animate-in zoom-in-95 custom-scrollbar overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-6 border-b border-white/5 bg-[#0A0A0A] flex justify-between items-center">
                    <div>
                        <h2 className="text-xl font-black text-white uppercase tracking-wider flex items-center gap-2">
                            <Target className="text-purple-500" /> Mission Briefing
                        </h2>
                        <p className="text-[10px] text-white/40 uppercase tracking-widest mt-1">
                            {type === 'ROUTINE' ? (existingRoutine ? 'Modify Protocol' : 'New Protocol') : (existingTask ? 'Edit Directive' : 'New Directive')}
                        </p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-white/50 hover:text-white transition-colors"><X size={20}/></button>
                </div>

                <div className="flex border-b border-white/5">
                    {['CORE', 'LOGISTICS', 'CONTEXT'].map(tab => (
                        <button 
                            key={tab} 
                            onClick={() => setActiveTab(tab as any)}
                            className={`flex-1 py-4 text-xs font-bold uppercase tracking-widest transition-colors ${activeTab === tab ? 'bg-purple-900/20 text-purple-400 border-b-2 border-purple-500' : 'text-white/30 hover:text-white hover:bg-white/5'}`}
                        >
                            {tab}
                        </button>
                    ))}
                </div>

                <div className="p-8 overflow-y-auto flex-1 custom-scrollbar">
                    {activeTab === 'CORE' && (
                        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
                            <div>
                                <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Objective Title</label>
                                <input autoFocus value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-[#111] border border-white/10 rounded-xl px-4 py-4 text-white focus:border-purple-500 transition-all outline-none font-bold text-lg placeholder-white/10" placeholder="Operation Name"/>
                            </div>
                            
                            {/* ENABLED FOR BOTH TASK AND ROUTINE */}
                            <div>
                                <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">
                                    {type === 'TASK' ? 'Sub-Directives' : 'Sub-Routines'}
                                </label>
                                <div className="space-y-2 mb-2">
                                    {subtasks.map((s, i) => (
                                        <div key={i} className="flex items-center gap-2 text-sm text-white/70 bg-white/5 p-3 rounded-lg border border-white/5">
                                            <div className="w-1.5 h-1.5 bg-purple-500 rounded-full shadow-[0_0_5px_#A855F7]"></div> {s.title}
                                            <button onClick={() => setSubtasks(subtasks.filter((_, idx) => idx !== i))} className="ml-auto text-white/30 hover:text-red-500"><X size={14}/></button>
                                        </div>
                                    ))}
                                </div>
                                <div className="flex gap-2">
                                    <input value={newSubtask} onChange={e => setNewSubtask(e.target.value)} onKeyDown={e => e.key === 'Enter' && newSubtask && setSubtasks([...subtasks, {id: Math.random().toString(), title: newSubtask, completed: false}])} className="flex-1 bg-[#111] border border-white/10 rounded-lg p-3 text-sm text-white focus:border-purple-500/50 outline-none" placeholder="Add tactical step..." />
                                    <button onClick={() => { if(newSubtask) { setSubtasks([...subtasks, {id: Math.random().toString(), title: newSubtask, completed: false}]); setNewSubtask(''); } }} className="bg-purple-600/20 text-purple-400 border border-purple-500/50 p-3 rounded-lg hover:bg-purple-600 hover:text-white transition-all"><Plus size={18}/></button>
                                </div>
                            </div>

                            <div>
                                <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Briefing Details</label>
                                <textarea value={desc} onChange={e => setDesc(e.target.value)} className="w-full bg-[#111] border border-white/10 rounded-xl px-4 py-3 text-white focus:border-purple-500 transition-colors outline-none resize-none h-32 text-sm leading-relaxed" placeholder="Detailed instructions..."/>
                            </div>
                        </div>
                    )}

                    {activeTab === 'LOGISTICS' && (
                        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Priority Level</label>
                                    <select value={priority} onChange={e => setPriority(e.target.value)} className="w-full bg-[#111] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-500">
                                        <option value="High">Critical (High)</option>
                                        <option value="Medium">Standard (Medium)</option>
                                        <option value="Low">Backlog (Low)</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Sector</label>
                                    <select value={cat} onChange={e => setCat(e.target.value as any)} className="w-full bg-[#111] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-500">
                                        {['Physical', 'Mental', 'Knowledge', 'Spiritual', 'Social'].map(c => <option key={c} value={c}>{c}</option>)}
                                    </select>
                                </div>
                            </div>

                            {type === 'ROUTINE' && (
                                <div className="grid grid-cols-2 gap-6">
                                    <div>
                                        <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">XP Reward</label>
                                        <input type="number" value={xp} onChange={e => setXp(Number(e.target.value))} className="w-full bg-[#111] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-500"/>
                                    </div>
                                    <div>
                                        <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Frequency</label>
                                        <select value={freq} onChange={e => setFreq(e.target.value as any)} className="w-full bg-[#111] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-500">
                                            <option value="Daily">Daily</option>
                                            <option value="Weekly">Weekly</option>
                                            <option value="Monthly">Monthly</option>
                                        </select>
                                    </div>
                                </div>
                            )}

                            <div>
                                <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Tools Required</label>
                                <input value={tools} onChange={e => setTools(e.target.value)} className="w-full bg-[#111] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-500" placeholder="e.g. Laptop, Notebook, Weights"/>
                            </div>
                        </div>
                    )}

                    {activeTab === 'CONTEXT' && (
                        <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Time Estimate</label>
                                    <input value={timeEst} onChange={e => setTimeEst(e.target.value)} className="w-full bg-[#111] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-500" placeholder="e.g. 30m"/>
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-purple-400 uppercase mb-2 block">Energy Demand</label>
                                    <select value={energy} onChange={e => setEnergy(e.target.value)} className="w-full bg-[#111] border border-white/10 rounded-xl p-3 text-white outline-none focus:border-purple-500">
                                        <option value="High">High</option>
                                        <option value="Medium">Medium</option>
                                        <option value="Low">Low</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div className="bg-purple-900/10 border border-purple-500/20 p-4 rounded-xl">
                                <h4 className="text-purple-400 text-xs font-bold uppercase mb-2 flex items-center gap-2"><Brain size={14}/> AI Suggestion</h4>
                                <p className="text-white/60 text-xs leading-relaxed">
                                    Based on your current load, scheduling this for the morning block (08:00 - 11:00) is recommended for optimal output.
                                </p>
                            </div>
                        </div>
                    )}
                </div>
                
                <div className="flex gap-4 p-6 border-t border-white/5 bg-[#0A0A0A]">
                    {((type === 'ROUTINE' && existingRoutine) || (type === 'TASK' && existingTask)) && (
                        <button onClick={() => type === 'ROUTINE' ? onDeleteRoutine(existingRoutine!.id) : onDeleteTask(existingTask!.id)} className="px-4 py-3 bg-red-900/20 text-red-500 rounded-xl font-bold border border-red-900/30 hover:bg-red-900/40 transition-colors"><Trash2 size={20}/></button>
                    )}
                    <button onClick={handleSubmit} className="flex-1 bg-white text-black font-black text-sm uppercase tracking-widest rounded-xl py-3 hover:bg-gray-200 transition-colors shadow-[0_0_20px_rgba(255,255,255,0.2)]">Confirm Protocol</button>
                </div>
            </div>
        </div>
    )
}

export const Routines: React.FC = () => {
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [logs, setLogs] = useState<RoutineLog[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [stats, setStats] = useState<UserStats>(StorageService.getStats());
  const user = StorageService.getUser();
  
  // View & Filter State
  const [taskView, setTaskView] = useState<'DAILY' | 'WEEKLY' | 'MONTHLY'>('DAILY');
  
  // Date State
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [weekOffset, setWeekOffset] = useState(0); 
  const [monthOffset, setMonthOffset] = useState(0); 
  const [calendarStartOffset, setCalendarStartOffset] = useState(0); 

  const [searchQuery, setSearchQuery] = useState('');
  
  // Quote State
  const [quoteIndex, setQuoteIndex] = useState(0);
  const [fadeQuote, setFadeQuote] = useState(true);

  // Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createType, setCreateType] = useState<'ROUTINE' | 'TASK'>('ROUTINE');
  const [editRoutine, setEditRoutine] = useState<Routine | null>(null);
  const [editTask, setEditTask] = useState<Task | null>(null);

  useEffect(() => {
    loadData();
    
    // Quote rotation - SLOWED DOWN to 30s to reduce re-renders
    const interval = setInterval(() => {
        setFadeQuote(false); // Fade out
        setTimeout(() => {
            setQuoteIndex(prev => (prev + 1) % QUOTES.length);
            setFadeQuote(true); // Fade in
        }, 1000);
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const loadData = () => {
      // These calls are now instant due to cache
      setRoutines(StorageService.getRoutines());
      setLogs(StorageService.getLogs());
      setTasks(StorageService.getTasks());
      setStats(StorageService.getStats());
  };

  // --- LOGIC ---
  const handleToggleRoutine = useCallback((routine: Routine, dateStr?: string) => {
      const targetDate = dateStr || new Date().toISOString().split('T')[0];
      
      setLogs(prevLogs => {
          const alreadyDone = prevLogs.some(l => l.date === targetDate && l.routineId === routine.id);
          let updatedLogs;
          if (alreadyDone) {
              updatedLogs = prevLogs.filter(l => !(l.date === targetDate && l.routineId === routine.id));
              // Note: We don't undo XP locally to keep it simple/safe, or we could fetch stats again
          } else {
              const newLog = { date: targetDate, routineId: routine.id, completed: true };
              updatedLogs = [...prevLogs, newLog];
              // Fire and forget storage update to keep UI snappy
              StorageService.saveLog(newLog);
              
              if(!dateStr || dateStr === new Date().toISOString().split('T')[0]) {
                  setStats(s => {
                      const newS = { ...s, currentXp: s.currentXp + routine.xpReward };
                      StorageService.saveStats(newS);
                      return newS;
                  });
              }
          }
          return updatedLogs;
      });
  }, []);

  const handleSubroutineToggle = useCallback((routineId: string, subtaskId: string, dateStr?: string) => {
      const targetDate = dateStr || new Date().toISOString().split('T')[0];
      
      setLogs(prev => {
          const existingLog = prev.find(l => l.routineId === routineId && l.date === targetDate);
          let newLog: RoutineLog;
          
          if (existingLog) {
              const currentSubs = existingLog.completedSubtasks || [];
              const newSubs = currentSubs.includes(subtaskId) 
                  ? currentSubs.filter(id => id !== subtaskId)
                  : [...currentSubs, subtaskId];
              newLog = { ...existingLog, completedSubtasks: newSubs };
          } else {
              newLog = { date: targetDate, routineId: routineId, completed: false, completedSubtasks: [subtaskId] };
          }
          
          StorageService.saveLog(newLog);
          const others = prev.filter(l => !(l.date === targetDate && l.routineId === routineId));
          return [...others, newLog];
      });
  }, []);

  const handleSaveRoutine = (r: Routine) => {
      const exists = routines.find(ex => ex.id === r.id);
      const updated = exists ? routines.map(ex => ex.id === r.id ? r : ex) : [...routines, r];
      setRoutines(updated);
      StorageService.saveRoutines(updated);
      setShowCreateModal(false);
      setEditRoutine(null);
  };

  const handleDeleteRoutine = (id: string) => {
      const updated = routines.filter(r => r.id !== id);
      setRoutines(updated);
      StorageService.saveRoutines(updated);
  };

  const handleToggleTask = (task: Task) => {
      const newStatus = task.status === 'done' ? 'todo' : 'done';
      const updated = tasks.map(t => t.id === task.id ? { ...t, status: newStatus, completed: newStatus === 'done' } : t);
      setTasks(updated);
      StorageService.saveTasks(updated);
  };

  const handleTaskSubtask = (task: Task, subtaskId: string) => {
      const updatedSubtasks = task.subtasks?.map(s => s.id === subtaskId ? { ...s, completed: !s.completed } : s);
      const updatedTask = { ...task, subtasks: updatedSubtasks };
      const updatedTasks = tasks.map(t => t.id === task.id ? updatedTask : t);
      setTasks(updatedTasks);
      StorageService.saveTasks(updatedTasks);
  };

  const handleSaveTask = (t: Task) => {
      const exists = tasks.find(ex => ex.id === t.id);
      const updated = exists ? tasks.map(ex => ex.id === t.id ? t : ex) : [...tasks, t];
      setTasks(updated);
      StorageService.saveTasks(updated);
      setShowCreateModal(false);
      setEditTask(null);
  };

  const handleDeleteTask = (id: string) => {
      const updated = tasks.filter(t => t.id !== id);
      setTasks(updated);
      StorageService.saveTasks(updated);
  };

  // --- MEMOIZED FILTERING ---
  
  const dailyRoutines = useMemo(() => routines
    .filter(r => r.frequency === 'Daily')
    .filter(r => r.title.toLowerCase().includes(searchQuery.toLowerCase())), [routines, searchQuery]);

  // Create a fast lookup set for logs to avoid O(N) inside the loop
  const logSet = useMemo(() => {
      const s = new Set<string>();
      logs.forEach(l => {
          if (l.completed) s.add(`${l.routineId}-${l.date}`);
      });
      return s;
  }, [logs]);

  const pendingRoutineCount = useMemo(() => dailyRoutines.filter(r => {
      const today = new Date().toISOString().split('T')[0];
      return !logSet.has(`${r.id}-${today}`);
  }).length, [dailyRoutines, logSet]);

  const rightColumnItems = useMemo(() => {
      let items: (Task | Routine)[] = [];

      if (taskView === 'DAILY') {
          const selectedDateStr = selectedDate.toISOString().split('T')[0];
          items = tasks.filter(t => {
              const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase());
              const matchesDate = t.date === selectedDateStr || (!t.completed && t.date < selectedDateStr);
              return matchesSearch && matchesDate;
          });
      } else if (taskView === 'WEEKLY') {
          const d = new Date();
          const day = d.getDay();
          const diff = d.getDate() - day + (day === 0 ? -6 : 1); 
          const start = new Date(d.setDate(diff + (weekOffset * 7)));
          start.setHours(0,0,0,0);
          const end = new Date(start);
          end.setDate(start.getDate() + 6);
          end.setHours(23,59,59,999);

          const weekTasks = tasks.filter(t => {
              const tDate = new Date(t.date);
              return tDate >= start && tDate <= end && t.title.toLowerCase().includes(searchQuery.toLowerCase());
          });
          const weekRoutines = routines.filter(r => r.frequency === 'Weekly' && r.title.toLowerCase().includes(searchQuery.toLowerCase()));
          items = [...weekTasks, ...weekRoutines];

      } else {
          // MONTHLY
          const d = new Date();
          d.setMonth(d.getMonth() + monthOffset);
          const start = new Date(d.getFullYear(), d.getMonth(), 1);
          const end = new Date(d.getFullYear(), d.getMonth() + 1, 0);

          const monthTasks = tasks.filter(t => {
              const tDate = new Date(t.date);
              return tDate >= start && tDate <= end && t.title.toLowerCase().includes(searchQuery.toLowerCase());
          });
          const monthRoutines = routines.filter(r => r.frequency === 'Monthly' && r.title.toLowerCase().includes(searchQuery.toLowerCase()));
          items = [...monthTasks, ...monthRoutines];
      }

      const priorityOrder: Record<string, number> = { 'High': 3, 'Medium': 2, 'Low': 1 };
      
      return items.sort((a, b) => {
          const pA = (a as any).priority ? priorityOrder[(a as any).priority] || 1 : 1; 
          const pB = (b as any).priority ? priorityOrder[(b as any).priority] || 1 : 1;
          if (pB !== pA) return pB - pA;
          return a.title.localeCompare(b.title);
      });

  }, [tasks, routines, taskView, selectedDate, searchQuery, weekOffset, monthOffset]);

  const statsMetrics = useMemo(() => {
      if (rightColumnItems.length === 0) return 0;
      const done = rightColumnItems.filter(i => {
          if ('status' in i) return i.status === 'done';
          return logs.some(l => l.routineId === i.id && l.completed); 
      }).length;
      return Math.round((done / rightColumnItems.length) * 100);
  }, [rightColumnItems, logs]);

  const getWeekLabel = () => {
      const d = new Date();
      d.setDate(d.getDate() + (weekOffset * 7));
      const year = d.getFullYear();
      const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
      date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay()||7));
      const yearStart = new Date(Date.UTC(date.getUTCFullYear(),0,1));
      const weekNo = Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1)/7);
      return `Week ${weekNo} of ${year}`;
  }

  const getMonthLabel = () => {
      const d = new Date();
      d.setMonth(d.getMonth() + monthOffset);
      return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  }

  return (
    <div className="h-full w-full bg-[#050505] text-white font-sans flex flex-col overflow-hidden relative selection:bg-purple-500/30">
        
        {/* --- GLOBAL HEADER --- */}
        <div className="px-8 pt-12 pb-6 border-b border-white/5 bg-[#050505] z-10 flex justify-between items-end">
            <div>
                <h1 className="text-6xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-purple-200 to-purple-500 tracking-tighter mb-2 drop-shadow-xl">Today's Overview</h1>
                <p className="text-sm text-zinc-400 font-medium tracking-wide">
                    Hello, {user?.name || 'Architect'}. You have {pendingRoutineCount} pending protocols.
                </p>
            </div>
            
            {/* Quote on the right */}
            <div className="flex flex-col items-end pb-1 max-w-sm text-right">
                <p 
                    className={`text-[10px] font-bold text-white/30 uppercase tracking-widest transition-opacity duration-1000 ${fadeQuote ? 'opacity-100' : 'opacity-0'}`}
                >
                    "{QUOTES[quoteIndex]}"
                </p>
            </div>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
            
            {/* --- LEFT: ROUTINES --- */}
            <div className="lg:w-[450px] flex-shrink-0 border-r border-white/5 bg-[#030303] flex flex-col">
                <div className="p-6 pb-2 border-b border-white/5 bg-[#030303] sticky top-0 z-10">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-white uppercase tracking-tight flex items-center gap-2">
                            <Activity size={18} className="text-purple-500"/> Routines
                        </h2>
                        <button 
                            onClick={() => { setCreateType('ROUTINE'); setShowCreateModal(true); }} 
                            className="w-8 h-8 flex items-center justify-center bg-[#111] border border-white/10 text-white rounded hover:border-purple-500 hover:text-purple-500 transition-all shadow-lg hover:shadow-purple-500/20"
                        >
                            <Plus size={16}/>
                        </button>
                    </div>
                    <ConsistencyGraph logs={logs} />
                </div>
                
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4">
                    {dailyRoutines.map(routine => (
                        <RoutineCard 
                            key={routine.id}
                            routine={routine}
                            logs={logs}
                            onToggle={handleToggleRoutine}
                            onSubroutineToggle={handleSubroutineToggle}
                            onEdit={() => { setEditRoutine(routine); setCreateType('ROUTINE'); setShowCreateModal(true); }}
                            onDelete={() => handleDeleteRoutine(routine.id)}
                        />
                    ))}
                    {dailyRoutines.length === 0 && <div className="text-center text-white/20 text-xs py-10 uppercase tracking-widest border border-dashed border-white/10 rounded-xl">No Active Protocols</div>}
                </div>
            </div>

            {/* --- RIGHT: TASKS (OBJECTIVES) --- */}
            <div className="flex-1 flex flex-col bg-[#050505] relative">
                
                <div className="p-6 pb-0 space-y-5">
                    
                    {/* Task Consistency Graph (Bar Chart) - Compact */}
                    <div className="h-28 w-full -mb-2">
                        <TaskConsistencyGraph tasks={tasks} />
                    </div>

                    {/* Row 1: Title & Add Button */}
                    <div className="flex justify-between items-center">
                        <h2 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white via-purple-200 to-purple-400 tracking-tighter drop-shadow-md">
                            Tasks & Monthly Plans
                        </h2>
                        <button 
                            onClick={() => { 
                                setCreateType(taskView === 'DAILY' ? 'TASK' : 'ROUTINE'); 
                                setShowCreateModal(true); 
                            }}
                            className="h-8 px-6 border border-white/10 bg-[#111] hover:bg-white/10 text-white rounded-sm flex items-center justify-center transition-all hover:border-white/30 active:scale-95"
                        >
                            <Plus size={16} />
                        </button>
                    </div>

                    {/* Row 2: Search Bar (Full Width) */}
                    <div className="relative w-full group">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-purple-500 transition-colors">
                            <Search size={16} />
                        </div>
                        <input 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="EXECUTE COMMAND / SEARCH"
                            className="w-full bg-[#0A0A0A] border border-white/10 text-white pl-10 pr-4 py-3 rounded-lg outline-none focus:border-purple-500/50 transition-all font-mono text-xs placeholder-white/20"
                        />
                        <div className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] font-bold text-white/20 border border-white/10 px-1.5 py-0.5 rounded">CMD+K</div>
                    </div>

                    {/* Row 3: Progress (Left) & Tabs (Right) */}
                    <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4">
                        
                        {/* Left: Rectangular Purple-Black Gradient Progress */}
                        <div className="flex-1 bg-[#0A0A0A] border border-white/10 rounded-lg p-1 relative overflow-hidden h-10">
                            <div 
                                className="absolute inset-y-0 left-0 bg-gradient-to-r from-purple-900 via-purple-600 to-black transition-all duration-700 ease-out opacity-90" 
                                style={{ width: `${statsMetrics}%` }} 
                            />
                            <div className="relative z-10 flex justify-between items-center h-full px-4">
                                <span className="text-[9px] font-bold uppercase tracking-widest text-white/70 shadow-black drop-shadow-md">Completion Status</span>
                                <span className="text-xs font-bold text-white drop-shadow-md">{statsMetrics}%</span>
                            </div>
                        </div>

                        {/* Right: Tab Switcher (PURPLE ACTIVE STATE) */}
                        <div className="flex bg-[#0A0A0A] p-1 rounded-lg border border-white/10 flex-shrink-0">
                            {(['DAILY', 'WEEKLY', 'MONTHLY'] as const).map(v => (
                                <button 
                                    key={v}
                                    onClick={() => setTaskView(v)}
                                    className={`
                                        px-4 py-2 text-[9px] font-bold uppercase tracking-widest rounded-md transition-all
                                        ${taskView === v ? 'bg-purple-600 text-white shadow-lg shadow-purple-900/30' : 'text-white/40 hover:text-white hover:bg-white/5'}
                                    `}
                                >
                                    {v}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Row 4: Navigation / Calendar (THIN VERSION) */}
                    <div className="relative">
                        {/* Gradient Mask for Smooth Scroll */}
                        <div className="absolute inset-y-0 left-0 w-8 bg-gradient-to-r from-[#050505] to-transparent z-10 pointer-events-none"></div>
                        <div className="absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-[#050505] to-transparent z-10 pointer-events-none"></div>
                        
                        {taskView === 'DAILY' ? (
                            <CompactCalendarStrip 
                                selectedDate={selectedDate} 
                                onSelect={setSelectedDate} 
                                offset={calendarStartOffset}
                                onPrev={() => setCalendarStartOffset(o => o - 1)}
                                onNext={() => setCalendarStartOffset(o => o + 1)}
                            />
                        ) : (
                            <div className="flex justify-between items-center border-b border-white/5 pb-2">
                                <div className="flex items-center gap-4">
                                    <button onClick={() => taskView === 'WEEKLY' ? setWeekOffset(o => o - 1) : setMonthOffset(o => o - 1)} className="p-1.5 hover:bg-white/10 rounded-full text-white/50 hover:text-white"><ChevronLeft size={16}/></button>
                                    <span className="text-lg font-bold text-white uppercase tracking-tight">
                                        {taskView === 'WEEKLY' ? getWeekLabel() : getMonthLabel()}
                                    </span>
                                    <button onClick={() => taskView === 'WEEKLY' ? setWeekOffset(o => o + 1) : setMonthOffset(o => o + 1)} className="p-1.5 hover:bg-white/10 rounded-full text-white/50 hover:text-white"><ChevronRight size={16}/></button>
                                </div>
                                <span className="text-[10px] font-mono text-purple-500 font-bold bg-purple-500/10 px-2 py-1 rounded border border-purple-500/20">
                                    {taskView} OVERVIEW
                                </span>
                            </div>
                        )}
                    </div>
                </div>

                {/* LIST CONTENT */}
                <div className="flex-1 overflow-y-auto custom-scrollbar px-6 pb-20 pt-4">
                    <div className="space-y-4">
                        {rightColumnItems.length === 0 ? (
                            <div className="text-center py-20 border border-dashed border-white/10 rounded-lg flex flex-col items-center gap-4">
                                <Target size={32} className="text-white/10" />
                                <span className="text-xs text-white/30 uppercase tracking-widest">No Directives Found</span>
                            </div>
                        ) : (
                            rightColumnItems.map(item => {
                                if ('status' in item) {
                                    return (
                                        <RectTaskCard 
                                            key={item.id} 
                                            task={item as Task} 
                                            onToggle={() => handleToggleTask(item as Task)}
                                            onSubtaskToggle={(sid) => handleTaskSubtask(item as Task, sid)}
                                            onEdit={() => { setEditTask(item as Task); setCreateType('TASK'); setShowCreateModal(true); }}
                                            onDelete={() => handleDeleteTask(item.id)}
                                        />
                                    );
                                } else {
                                    return (
                                        <RectMacroCard 
                                            key={item.id}
                                            routine={item as Routine}
                                            logs={logs}
                                            onToggle={handleToggleRoutine}
                                            view={taskView}
                                            onEdit={() => { setEditRoutine(item as Routine); setCreateType('ROUTINE'); setShowCreateModal(true); }}
                                            onDelete={() => handleDeleteRoutine(item.id)}
                                        />
                                    );
                                }
                            })
                        )}
                    </div>
                </div>
            </div>

            {/* --- MODAL --- */}
            {showCreateModal && (
                <UnifiedCreateModal 
                    type={createType}
                    onClose={() => { setShowCreateModal(false); setEditRoutine(null); setEditTask(null); }} 
                    onSaveRoutine={handleSaveRoutine}
                    onSaveTask={handleSaveTask}
                    onDeleteRoutine={(id) => {
                        const updated = routines.filter(r => r.id !== id);
                        setRoutines(updated);
                        StorageService.saveRoutines(updated);
                        setShowCreateModal(false);
                    }}
                    onDeleteTask={(id) => {
                        const updated = tasks.filter(t => t.id !== id);
                        setTasks(updated);
                        StorageService.saveTasks(updated);
                        setShowCreateModal(false);
                    }}
                    existingRoutine={editRoutine}
                    existingTask={editTask}
                    frequency={taskView === 'MONTHLY' ? 'Monthly' : taskView === 'WEEKLY' ? 'Weekly' : 'Daily'}
                />
            )}
    </div>
  );
};
