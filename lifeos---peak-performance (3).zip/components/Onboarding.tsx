
import React, { useState } from 'react';
import { StorageService } from '../services/storageService';
import { 
    ArrowLeft, Target, Shield, 
    User, Activity, Flame, Cpu, Layers, Battery, X,
    ChevronRight, CheckCircle2, Star, Clock, Zap
} from 'lucide-react';

interface OnboardingProps {
    onComplete: () => void;
    onAbort?: () => void;
}

export const Onboarding: React.FC<OnboardingProps> = ({ onComplete, onAbort }) => {
    const [step, setStep] = useState(1);
    const [isTransitioning, setIsTransitioning] = useState(false);
    
    // Simplified Data States
    const [name, setName] = useState('');
    const [northStar, setNorthStar] = useState(''); // Replaces 'Main Goal'
    const [commitment, setCommitment] = useState(2); // Hours per day
    const [birthDate, setBirthDate] = useState(''); // Keep for age ticker
    
    const totalSteps = 4;

    const handleNext = () => {
        if (step < totalSteps) setStep(step + 1);
        else finishOnboarding();
    };

    const handleBack = () => {
        if (step > 1) setStep(step - 1);
    };

    const finishOnboarding = () => {
        const age = new Date().getFullYear() - new Date(birthDate).getFullYear();
        
        const user = { 
            name, 
            age: age.toString(), 
            birthDate, 
            mainGoal: northStar, 
            onboarded: true 
        };
        StorageService.saveUser(user as any);
        
        setIsTransitioning(true);
        // Hold the welcome screen for 2.5 seconds before unmounting
        setTimeout(() => {
            onComplete();
        }, 2500);
    };

    if (isTransitioning) {
        return (
            <div className="fixed inset-0 bg-black z-[100] flex flex-col items-center justify-center font-sans overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#2e1065_0%,_#000000_100%)] animate-pulse-slow opacity-50" />
                <div className="relative z-10 text-center animate-in zoom-in-50 duration-1000 slide-in-from-bottom-10">
                    <div className="mb-8 relative inline-block">
                        <div className="absolute inset-0 bg-ios-purple blur-[60px] opacity-50 rounded-full animate-pulse"></div>
                        <Zap size={80} className="text-white relative z-10 fill-white drop-shadow-[0_0_30px_rgba(168,85,247,0.8)]" />
                    </div>
                    <h1 className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white via-white to-purple-400 tracking-tighter mb-4 drop-shadow-2xl">
                        WELCOME TO<br/>THE NEXUS
                    </h1>
                    <p className="text-ios-purple font-mono text-sm uppercase tracking-[0.5em] animate-pulse">
                        Initializing Dashboard...
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 bg-black flex flex-col items-center justify-center p-6 overflow-hidden font-sans animate-in fade-in duration-1000">
            
            {/* Blinking Motion Background */}
            <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-900/10 rounded-full blur-[100px] animate-pulse-slow"></div>
                <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-900/10 rounded-full blur-[100px] animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
            </div>

            {/* Top Bar Progress */}
            <div className="absolute top-0 left-0 right-0 p-8 flex justify-between items-start z-50">
                <div className="flex gap-2">
                    {Array.from({ length: totalSteps }).map((_, i) => (
                        <div 
                            key={i} 
                            className={`h-1 rounded-full transition-all duration-500 ${
                                i + 1 === step 
                                    ? 'w-16 bg-ios-purple shadow-[0_0_15px_#A855F7]' 
                                    : i + 1 < step 
                                        ? 'w-4 bg-purple-500/40' 
                                        : 'w-4 bg-white/5'
                            }`} 
                        />
                    ))}
                </div>
            </div>

            {/* GLASS CARD CONTAINER */}
            <div className="relative z-10 w-full max-w-xl">
                <div className="bg-[#050505]/80 backdrop-blur-2xl border border-white/5 rounded-[3rem] p-8 md:p-12 shadow-[0_0_60px_rgba(0,0,0,0.8)] overflow-hidden relative min-h-[500px] flex flex-col justify-between transition-all duration-500 ring-1 ring-white/5 group hover:border-ios-purple/20 hover:shadow-[0_0_80px_rgba(168,85,247,0.1)]">
                    
                    {/* Content Area */}
                    <div key={step} className="flex-1 flex flex-col justify-center animate-in slide-in-from-right duration-500">
                        
                        {/* STEP 1: IDENTITY */}
                        {step === 1 && (
                            <div className="space-y-8 text-center">
                                <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-2xl mx-auto flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.05)]">
                                    <User size={32} className="text-white" />
                                </div>
                                <div>
                                    <h2 className="text-4xl font-black text-white mb-2 tracking-tighter">Identity Protocol</h2>
                                    <p className="text-white/40 text-sm font-medium">Enter your callsign for the system.</p>
                                </div>
                                <input 
                                    autoFocus
                                    value={name}
                                    onChange={e => setName(e.target.value)}
                                    onKeyDown={e => e.key === 'Enter' && name && handleNext()}
                                    className="w-full bg-transparent border-b-2 border-white/10 text-center text-white text-4xl font-bold py-4 outline-none focus:border-ios-purple transition-all placeholder-white/5"
                                    placeholder="Name"
                                />
                            </div>
                        )}

                        {/* STEP 2: NORTH STAR */}
                        {step === 2 && (
                            <div className="space-y-8 text-center">
                                <div className="w-16 h-16 bg-ios-purple/10 border border-ios-purple/20 rounded-2xl mx-auto flex items-center justify-center shadow-[0_0_30px_rgba(168,85,247,0.2)]">
                                    <Target size={32} className="text-ios-purple" />
                                </div>
                                <div>
                                    <h2 className="text-4xl font-black text-white mb-2 tracking-tighter">Prime Directive</h2>
                                    <p className="text-white/40 text-sm font-medium">What is your single most important goal?</p>
                                </div>
                                <input 
                                    autoFocus
                                    value={northStar}
                                    onChange={e => setNorthStar(e.target.value)}
                                    onKeyDown={e => e.key === 'Enter' && northStar && handleNext()}
                                    className="w-full bg-transparent border-b-2 border-ios-purple/30 text-center text-white text-2xl font-bold py-4 outline-none focus:border-ios-purple transition-all placeholder-white/5"
                                    placeholder="e.g. Build a Startup"
                                />
                            </div>
                        )}

                        {/* STEP 3: COMMITMENT */}
                        {step === 3 && (
                            <div className="space-y-8 text-center">
                                <div className="w-16 h-16 bg-blue-500/10 border border-blue-500/20 rounded-2xl mx-auto flex items-center justify-center shadow-[0_0_30px_rgba(59,130,246,0.2)]">
                                    <Clock size={32} className="text-blue-500" />
                                </div>
                                <div>
                                    <h2 className="text-4xl font-black text-white mb-2 tracking-tighter">Time Allocation</h2>
                                    <p className="text-white/40 text-sm font-medium">Daily Deep Work commitment.</p>
                                </div>
                                <div className="flex items-center justify-center gap-6">
                                    <button onClick={() => setCommitment(Math.max(1, commitment - 1))} className="w-14 h-14 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-center text-white hover:bg-white/10 hover:scale-105 transition-all text-2xl font-bold">-</button>
                                    <span className="text-7xl font-black text-white font-mono tracking-tighter">{commitment}h</span>
                                    <button onClick={() => setCommitment(commitment + 1)} className="w-14 h-14 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-center text-white hover:bg-white/10 hover:scale-105 transition-all text-2xl font-bold">+</button>
                                </div>
                            </div>
                        )}

                        {/* STEP 4: ORIGIN (Required for Age Ticker) */}
                        {step === 4 && (
                            <div className="space-y-8 text-center">
                                <div className="w-16 h-16 bg-green-500/10 border border-green-500/20 rounded-2xl mx-auto flex items-center justify-center shadow-[0_0_30px_rgba(34,197,94,0.2)]">
                                    <Activity size={32} className="text-green-500" />
                                </div>
                                <div>
                                    <h2 className="text-4xl font-black text-white mb-2 tracking-tighter">Origin Point</h2>
                                    <p className="text-white/40 text-sm font-medium">To calibrate the Life Clock.</p>
                                </div>
                                <input 
                                    autoFocus
                                    type="date"
                                    value={birthDate}
                                    onChange={e => setBirthDate(e.target.value)}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-6 text-center text-white text-2xl font-bold outline-none focus:bg-white/10 focus:border-ios-purple/50 transition-all uppercase tracking-widest"
                                />
                            </div>
                        )}
                    </div>

                    {/* Bottom Controls */}
                    <div className="flex justify-between items-center mt-12 pt-6 border-t border-white/5">
                        <button 
                            onClick={handleBack}
                            disabled={step === 1}
                            className="w-12 h-12 rounded-full flex items-center justify-center text-white/30 hover:text-white transition-all disabled:opacity-0"
                        >
                            <ArrowLeft size={20} />
                        </button>

                        <button 
                            onClick={handleNext}
                            disabled={(step === 1 && !name) || (step === 2 && !northStar) || (step === 4 && !birthDate)}
                            className="bg-white text-black px-8 py-4 rounded-xl font-black text-sm uppercase tracking-widest flex items-center gap-3 hover:scale-105 active:scale-95 transition-all shadow-[0_0_30px_rgba(255,255,255,0.2)] disabled:opacity-30 disabled:cursor-not-allowed disabled:shadow-none hover:shadow-[0_0_40px_rgba(168,85,247,0.4)]"
                        >
                            {step === totalSteps ? 'Launch System' : 'Continue'} <ChevronRight size={16} />
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
