
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
    MousePointer2, Hand, Square, Circle, StickyNote, Type as TypeIcon, 
    Frame, ZoomIn, ZoomOut, Lock, Trash2, 
    Workflow, Layout
} from 'lucide-react';
import { StorageService } from '../services/storageService';
import { CanvasBoard, CanvasObject, CanvasObjectType, CanvasConnection, ShapeType } from '../types';

const ZOOM_MIN = 0.1;
const ZOOM_MAX = 4;

type ToolType = 'SELECT' | 'HAND' | 'SHAPE' | 'STICKY' | 'TEXT' | 'CONNECTOR';
type InteractionMode = 'IDLE' | 'PAN' | 'DRAG' | 'RESIZE' | 'CONNECTING';

const screenToCanvas = (sx: number, sy: number, viewport: {x:number, y:number, zoom:number}, rect: DOMRect) => ({
    x: (sx - rect.left - viewport.x) / viewport.zoom,
    y: (sy - rect.top - viewport.y) / viewport.zoom
});

/**
 * High-reliability anchor point logic. 
 * Connects to the center of a box but clamps to the edges.
 */
const getAnchor = (box: {x: number, y: number, width: number, height: number}, target: {x: number, y: number}) => {
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;
    
    const dx = target.x - cx;
    const dy = target.y - cy;
    
    if (Math.abs(dx) < 1 && Math.abs(dy) < 1) return { x: cx, y: cy };

    const halfW = box.width / 2;
    const halfH = box.height / 2;
    
    const scale = Math.min(
        halfW / Math.abs(dx || 1),
        halfH / Math.abs(dy || 1)
    );

    return {
        x: cx + dx * scale,
        y: cy + dy * scale
    };
};

const ObjectRenderer: React.FC<{ 
    obj: CanvasObject, 
    isSelected: boolean,
    isHovered: boolean,
    isTarget: boolean,
    isEditing: boolean,
    onEdit: (id: string, updates: Partial<CanvasObject>) => void 
}> = React.memo(({ obj, isSelected, isHovered, isTarget, isEditing, onEdit }) => {
    const style: React.CSSProperties = {
        position: 'absolute',
        left: obj.x, top: obj.y,
        width: obj.width, height: obj.height,
        zIndex: obj.zIndex,
        pointerEvents: obj.locked ? 'none' : 'auto',
        borderRadius: obj.type === 'STICKY' ? '2px' : obj.shapeType === 'CIRCLE' ? '50%' : '8px'
    };

    let ringClass = 'transition-all duration-200 ';
    if (isTarget) ringClass += 'ring-4 ring-cyan-400 shadow-[0_0_20px_cyan] scale-[1.02]';
    else if (isSelected) ringClass += 'ring-2 ring-purple-500 shadow-xl';
    else if (isHovered) ringClass += 'ring-1 ring-white/30';

    return (
        <div id={obj.id} className={`absolute group select-none flex items-center justify-center overflow-hidden border border-white/10 ${ringClass} ${obj.backgroundColor ? '' : 'bg-zinc-900'}`} style={{...style, backgroundColor: obj.backgroundColor}}>
            {isEditing ? (
                <textarea 
                    autoFocus 
                    value={obj.text} 
                    onChange={e => onEdit(obj.id, {text: e.target.value})} 
                    className="w-full h-full bg-transparent border-none outline-none resize-none p-4 text-center font-bold text-white" 
                />
            ) : (
                <div className="p-4 text-center font-bold text-white leading-tight break-words pointer-events-none uppercase tracking-tight">
                    {obj.text || (obj.type === 'STICKY' ? 'Note' : '')}
                </div>
            )}
        </div>
    );
});

const ConnectionRenderer: React.FC<{ conn: CanvasConnection, objects: CanvasObject[] }> = ({ conn, objects }) => {
    const from = objects.find(o => o.id === conn.from);
    const to = objects.find(o => o.id === conn.to);
    if (!from || !to) return null;

    const fromCenter = { x: from.x + from.width/2, y: from.y + from.height/2 };
    const toCenter = { x: to.x + to.width/2, y: to.y + to.height/2 };

    const start = getAnchor(from, toCenter);
    const end = getAnchor(to, fromCenter);

    const dx = Math.abs(end.x - start.x) * 0.5;
    const dy = (end.y - start.y) * 0.1;
    const path = `M ${start.x} ${start.y} C ${start.x + dy + 50} ${start.y}, ${end.x - dy - 50} ${end.y}, ${end.x} ${end.y}`;

    // A simpler curve if the complex one is glitching:
    // const path = `M ${start.x} ${start.y} C ${start.x} ${start.y + 100}, ${end.x} ${end.y - 100}, ${end.x} ${end.y}`;

    return (
        <g>
            <path d={path} stroke={conn.color || '#A855F7'} strokeWidth={2} fill="none" strokeLinecap="round" markerEnd="url(#arrowhead)" className="transition-all duration-300" />
            <path d={path} stroke="transparent" strokeWidth="20" fill="none" pointerEvents="stroke" className="cursor-pointer" />
        </g>
    );
};

export const Whiteboard: React.FC = () => {
    const [board, setBoard] = useState<CanvasBoard>(StorageService.getWhiteboard());
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [viewport, setViewport] = useState({ x: 0, y: 0, zoom: 1 });
    const [tool, setTool] = useState<ToolType>('SELECT');
    const [hoveredId, setHoveredId] = useState<string | null>(null);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [connStartId, setConnStartId] = useState<string | null>(null);
    const [connTargetId, setConnTargetId] = useState<string | null>(null);
    const [dragLine, setDragLine] = useState<{x:number, y:number} | null>(null);

    const interactionMode = useRef<InteractionMode>('IDLE');
    const canvasRef = useRef<HTMLDivElement>(null);
    const dragStart = useRef({ x: 0, y: 0 });
    const initialObjects = useRef<CanvasObject[]>([]);

    useEffect(() => {
        if (board.objects.length === 0) {
            const id1 = 'demo-1', id2 = 'demo-2';
            setBoard({
                ...board,
                objects: [
                    { id: id1, type: 'SHAPE', x: 200, y: 100, width: 150, height: 100, text: 'Goal One', backgroundColor: '#3b82f6', zIndex: 1 },
                    { id: id2, type: 'STICKY', x: 200, y: 350, width: 150, height: 150, text: 'Action Item', backgroundColor: '#fbbf24', zIndex: 2 }
                ],
                connections: [
                    { id: 'conn-1', from: id1, to: id2, type: 'CURVED', color: '#A855F7' }
                ]
            });
        }
    }, []);

    useEffect(() => { StorageService.saveBoard(board); }, [board]);

    const handlePointerDown = (e: React.PointerEvent) => {
        const canvas = canvasRef.current!;
        canvas.setPointerCapture(e.pointerId);
        const rect = canvas.getBoundingClientRect();
        const pt = screenToCanvas(e.clientX, e.clientY, viewport, rect);
        dragStart.current = { x: e.clientX, y: e.clientY };

        if (e.button === 1 || tool === 'HAND') {
            interactionMode.current = 'PAN';
            return;
        }

        const hit = [...board.objects].sort((a,b) => b.zIndex - a.zIndex).find(o => 
            pt.x >= o.x && pt.x <= o.x + o.width && pt.y >= o.y && pt.y <= o.y + o.height
        );

        if (tool === 'CONNECTOR' && hit) {
            interactionMode.current = 'CONNECTING';
            setConnStartId(hit.id);
            setDragLine(pt);
            return;
        }

        if (hit) {
            if (!selectedIds.has(hit.id)) setSelectedIds(new Set([hit.id]));
            interactionMode.current = 'DRAG';
            initialObjects.current = board.objects.filter(o => selectedIds.has(o.id) || o.id === hit.id);
            setEditingId(null);
        } else {
            setSelectedIds(new Set());
            interactionMode.current = 'IDLE';
            setEditingId(null);
        }
    };

    const handlePointerMove = (e: React.PointerEvent) => {
        const rect = canvasRef.current!.getBoundingClientRect();
        const pt = screenToCanvas(e.clientX, e.clientY, viewport, rect);
        const dx = (e.clientX - dragStart.current.x) / viewport.zoom;
        const dy = (e.clientY - dragStart.current.y) / viewport.zoom;

        if (interactionMode.current === 'PAN') {
            setViewport(v => ({ ...v, x: v.x + (e.clientX - dragStart.current.x), y: v.y + (e.clientY - dragStart.current.y) }));
            dragStart.current = { x: e.clientX, y: e.clientY };
        } else if (interactionMode.current === 'DRAG') {
            setBoard(prev => ({
                ...prev,
                objects: prev.objects.map(obj => {
                    const start = initialObjects.current.find(o => o.id === obj.id);
                    return start ? { ...obj, x: start.x + dx, y: start.y + dy } : obj;
                })
            }));
        } else if (interactionMode.current === 'CONNECTING') {
            setDragLine(pt);
            const target = [...board.objects].reverse().find(o => 
                o.id !== connStartId &&
                pt.x >= o.x && pt.x <= o.x + o.width && pt.y >= o.y && pt.y <= o.y + o.height
            );
            setConnTargetId(target?.id || null);
        } else {
            const hit = [...board.objects].sort((a,b) => b.zIndex - a.zIndex).find(o => 
                pt.x >= o.x && pt.x <= o.x + o.width && pt.y >= o.y && pt.y <= o.y + o.height
            );
            setHoveredId(hit?.id || null);
        }
    };

    const handlePointerUp = (e: React.PointerEvent) => {
        canvasRef.current!.releasePointerCapture(e.pointerId);
        if (interactionMode.current === 'CONNECTING' && connStartId && connTargetId) {
            setBoard(prev => ({
                ...prev,
                connections: [...prev.connections, { id: Math.random().toString(), from: connStartId, to: connTargetId, type: 'CURVED', color: '#A855F7' }]
            }));
        }
        interactionMode.current = 'IDLE';
        setConnStartId(null); setConnTargetId(null); setDragLine(null);
    };

    const handleWheel = (e: React.WheelEvent) => {
        if (e.ctrlKey) {
            e.preventDefault();
            const s = Math.exp(-e.deltaY * 0.002);
            setViewport(v => ({ ...v, zoom: Math.min(Math.max(ZOOM_MIN, v.zoom * s), ZOOM_MAX) }));
        } else {
            setViewport(v => ({ ...v, x: v.x - e.deltaX, y: v.y - e.deltaY }));
        }
    };

    return (
        <div className="h-full w-full bg-[#050505] overflow-hidden relative select-none">
            <svg style={{ position: 'absolute', width: 0, height: 0 }}><defs><marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto"><polygon points="0 0, 10 3.5, 0 7" fill="currentColor" /></marker></defs></svg>
            
            <div className="absolute top-6 left-1/2 -translate-x-1/2 bg-black/80 border border-white/10 p-2 rounded-2xl shadow-2xl flex items-center gap-2 z-[200] backdrop-blur-xl">
                <ToolBtn active={tool === 'SELECT'} icon={<MousePointer2 size={18}/>} onClick={() => setTool('SELECT')} label="Select" />
                <ToolBtn active={tool === 'HAND'} icon={<Hand size={18}/>} onClick={() => setTool('HAND')} label="Hand" />
                <div className="w-px h-6 bg-white/10 mx-1" />
                <ToolBtn active={tool === 'SHAPE'} icon={<Square size={18}/>} onClick={() => {
                    const id = Math.random().toString();
                    setBoard({...board, objects: [...board.objects, { id, type: 'SHAPE', x: 100, y: 100, width: 120, height: 80, text: 'New', backgroundColor: '#3b82f6', zIndex: board.objects.length + 1 }]});
                }} label="Shape" />
                <ToolBtn active={tool === 'STICKY'} icon={<StickyNote size={18}/>} onClick={() => {
                    const id = Math.random().toString();
                    setBoard({...board, objects: [...board.objects, { id, type: 'STICKY', x: 100, y: 100, width: 150, height: 150, text: 'Note', backgroundColor: '#fbbf24', zIndex: board.objects.length + 1 }]});
                }} label="Sticky" />
                <ToolBtn active={tool === 'CONNECTOR'} icon={<Workflow size={18}/>} onClick={() => setTool('CONNECTOR')} label="Connect" />
                <div className="w-px h-6 bg-white/10 mx-1" />
                <button onClick={() => {
                    const targets = Array.from(selectedIds);
                    setBoard(prev => ({ ...prev, objects: prev.objects.filter(o => !targets.includes(o.id)), connections: prev.connections.filter(c => !targets.includes(c.from) && !targets.includes(c.to)) }));
                    setSelectedIds(new Set());
                }} className="p-2 text-white/40 hover:text-red-500 transition-colors"><Trash2 size={18}/></button>
            </div>

            <div ref={canvasRef} className="w-full h-full cursor-crosshair" onPointerDown={handlePointerDown} onPointerMove={handlePointerMove} onPointerUp={handlePointerUp} onWheel={handleWheel} onDoubleClick={() => { const hit = board.objects.find(o => selectedIds.has(o.id)); if (hit) setEditingId(hit.id); }}>
                <div className="w-full h-full relative origin-top-left" style={{ transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.zoom})` }}>
                    <div className="absolute inset-[-2000%] opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
                    <svg className="absolute inset-[-2000%] w-[5000%] h-[5000%] pointer-events-none overflow-visible">
                        {board.connections.map(c => <ConnectionRenderer key={c.id} conn={c} objects={board.objects} />)}
                        {interactionMode.current === 'CONNECTING' && dragLine && connStartId && (
                            <path d={`M ${board.objects.find(o => o.id === connStartId)!.x + board.objects.find(o => o.id === connStartId)!.width/2} ${board.objects.find(o => o.id === connStartId)!.y + board.objects.find(o => o.id === connStartId)!.height/2} L ${dragLine.x} ${dragLine.y}`} stroke="#06b6d4" strokeWidth="2" fill="none" strokeDasharray="5,5" className="animate-pulse" />
                        )}
                    </svg>
                    {board.objects.map(obj => <ObjectRenderer key={obj.id} obj={obj} isSelected={selectedIds.has(obj.id)} isHovered={hoveredId === obj.id} isTarget={connTargetId === obj.id} isEditing={editingId === obj.id} onEdit={(id, u) => setBoard(prev => ({...prev, objects: prev.objects.map(o => o.id === id ? {...o, ...u} : o)}))} />)}
                </div>
            </div>

            <div className="absolute bottom-8 right-8 bg-black/80 border border-white/10 p-2 rounded-2xl shadow-xl flex items-center gap-4 z-[200]">
                <button onClick={() => setViewport(v => ({...v, zoom: Math.max(0.1, v.zoom - 0.1)}))} className="text-white/60 hover:text-white p-2"><ZoomOut size={16}/></button>
                <span className="text-[10px] font-black text-white w-10 text-center uppercase">{Math.round(viewport.zoom * 100)}%</span>
                <button onClick={() => setViewport(v => ({...v, zoom: Math.min(4, v.zoom + 0.1)}))} className="text-white/60 hover:text-white p-2"><ZoomIn size={16}/></button>
            </div>
        </div>
    );
};

const ToolBtn: React.FC<{ active: boolean, icon: React.ReactNode, onClick: () => void, label: string }> = ({ active, icon, onClick, label }) => (
    <button onClick={onClick} className={`p-3 rounded-xl transition-all group relative ${active ? 'bg-purple-600 text-white' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}>
        {icon}
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 px-2 py-1 bg-black border border-white/10 rounded text-[9px] font-black text-white opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-[300] uppercase tracking-widest">{label}</div>
    </button>
);
