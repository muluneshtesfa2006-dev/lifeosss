
import React, { useState, useEffect, useRef } from 'react';
import { Note, Block } from '../types';
import { 
  CheckSquare, Image as ImageIcon, PenTool, Type, Wand2, ArrowLeft, Trash, Star, 
  Bold as BoldIcon, Italic as ItalicIcon, Underline as UnderlineIcon, X, Heading, Palette,
  MoreHorizontal, Sparkles, Clock, Layout, Mic, Play, Pause, Square, FileText, Mic2, Calendar,
  MousePointer2, Music, Video, Layers, Table as TableIcon, Plus, ChevronUp, AlignLeft
} from 'lucide-react';
import { DrawingCanvas } from './DrawingCanvas';
import { GeminiService } from '../services/geminiService';

interface EditorProps {
  note: Note | null;
  allNotes: Note[];
  onUpdateNote: (note: Note) => void;
  onDeleteNote: (noteId: string) => void;
  onBack: () => void;
  onCreateNote: () => void;
}

export const Editor: React.FC<EditorProps> = ({ note, allNotes, onUpdateNote, onDeleteNote, onBack, onCreateNote }) => {
  const [showSketch, setShowSketch] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  
  const contentEditableRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  if (!note) {
    const totalWords = allNotes.reduce((acc, n) => {
        const textBlocks = n.blocks.filter(b => b.type === 'body');
        const text = textBlocks.map(b => b.content.replace(/<[^>]*>?/gm, '')).join(' ');
        return acc + text.split(/\s+/).length;
    }, 0);
    
    return (
      <div className="flex-1 bg-white dark:bg-black flex flex-col items-center justify-center dark:text-white text-slate-900 relative overflow-hidden p-6 transition-colors duration-500">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-ios-purple/5 dark:from-ios-purple/10 to-transparent animate-pulse-fast" />
        <div className="relative z-10 w-full max-w-2xl animate-in slide-in-from-bottom-8 duration-700">
            <div className="text-center mb-12">
                <h1 className="text-5xl font-black mb-2 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-slate-500 dark:from-white dark:to-white/50">Writer's Dashboard</h1>
                <p className="text-slate-400 dark:text-ios-textSec font-mono text-[9px] uppercase tracking-[0.3em]">Neural System Active</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
                <DashboardCard icon={<FileText size={24} />} value={allNotes.length} label="Total Notes" delay={0} />
                <DashboardCard icon={<Type size={24} />} value={totalWords} label="Words Written" delay={100} />
                <DashboardCard icon={<Mic2 size={24} />} value={allNotes.reduce((a,n)=>a+n.blocks.filter(b=>b.type==='audio').length,0)} label="Voice Memos" delay={200} />
            </div>
            <div className="flex justify-center">
                <button onClick={onCreateNote} className="group relative px-8 py-4 bg-ios-purple text-white rounded-full font-bold text-lg overflow-hidden shadow-xl shadow-ios-purple/20 hover:scale-105 transition-transform">
                    <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                    <span className="relative flex items-center gap-2">Create New Entry <Sparkles size={18} className="animate-pulse"/></span>
                </button>
            </div>
        </div>
      </div>
    );
  }

  const mainBlock = note.blocks.find(b => b.type === 'body') || note.blocks[0];

  const handleContentChange = (e: React.FormEvent<HTMLDivElement>) => {
      const newContent = e.currentTarget.innerHTML;
      const newBlocks = note.blocks.map(b => b.id === mainBlock.id ? { ...b, content: newContent } : b);
      onUpdateNote({ ...note, blocks: newBlocks, updatedAt: new Date().toISOString() });
  };

  const handleTitleChange = (newTitle: string) => {
    onUpdateNote({ ...note, title: newTitle, updatedAt: new Date().toISOString() });
  };

  const execCmd = (command: string, value: string | undefined = undefined) => {
      document.execCommand(command, false, value);
      if (contentEditableRef.current) {
          contentEditableRef.current.focus();
      }
  };

  const addSpecialBlock = (type: Block['type'], content: string) => {
      const newBlock: Block = {
          id: Math.random().toString(36).substr(2, 9),
          type,
          content,
          checked: type === 'checklist' ? false : undefined
      };
      const newBlocks = [...note.blocks, newBlock];
      onUpdateNote({ ...note, blocks: newBlocks, updatedAt: new Date().toISOString() });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => addSpecialBlock('image', reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === 'Tab') {
          e.preventDefault();
          execCmd('insertHTML', '&nbsp;&nbsp;&nbsp;&nbsp;');
      }
  };

  return (
    <div className="flex flex-col h-full bg-white dark:bg-black relative font-sans transition-colors duration-500 overflow-hidden">
      {/* HEADER */}
      <header className="flex items-center justify-between p-4 px-6 absolute top-0 left-0 right-0 z-20 pointer-events-none">
        <div className="flex items-center gap-4 pointer-events-auto">
           <button onClick={onBack} className="md:hidden text-slate-900 dark:text-white/80 hover:text-ios-purple flex items-center gap-2 bg-slate-100 dark:bg-black/20 backdrop-blur-md px-3 py-1.5 rounded-full border border-black/5 dark:border-white/5">
             <ArrowLeft size={18} />
           </button>
           <div className="hidden md:flex items-center gap-3 bg-white/50 dark:bg-black/30 backdrop-blur-md border border-black/5 dark:border-white/10 rounded-full pl-2 pr-4 py-1.5 shadow-lg">
               <div className="w-8 h-8 relative flex items-center justify-center">
                   <div className="absolute inset-0 border-2 border-ios-purple/50 rounded-full animate-spin-slow border-t-transparent" />
                   <div className="w-2 h-2 bg-ios-purple rounded-full shadow-[0_0_10px_#BF5AF2] animate-pulse" />
               </div>
               <div className="flex flex-col leading-none">
                    <span className="text-sm font-bold font-mono text-slate-900 dark:text-white">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    <span className="text-[9px] text-slate-400 dark:text-ios-textSec uppercase tracking-wider">Free Flow Mode</span>
               </div>
           </div>
        </div>
        <div className="flex gap-2 pointer-events-auto">
           <button onClick={() => onUpdateNote({ ...note, pinned: !note.pinned })} className={`p-2 rounded-full backdrop-blur-md border border-black/5 dark:border-white/5 transition-all ${note.pinned ? 'bg-ios-yellow/20 text-ios-yellow' : 'bg-slate-100 dark:bg-black/20 text-slate-400 dark:text-white/50'}`}><Star size={18} className={note.pinned ? 'fill-current' : ''} /></button>
           <button onClick={() => onDeleteNote(note.id)} className="p-2 rounded-full bg-slate-100 dark:bg-black/20 backdrop-blur-md border border-black/5 dark:border-white/5 text-slate-400 dark:text-white/50 hover:text-red-500 hover:bg-red-500/10"><Trash size={18} /></button>
        </div>
      </header>

      {/* EDITOR CANVAS */}
      <div className="flex-1 overflow-y-auto p-4 md:p-12 space-y-4 no-scrollbar pt-24 cursor-text">
        <div className="max-w-4xl mx-auto w-full pb-48">
            <input
              value={note.title}
              onChange={(e) => handleTitleChange(e.target.value)}
              placeholder="Untitled Document"
              className="w-full bg-transparent text-4xl md:text-6xl font-black text-slate-900 dark:text-white border-none outline-none placeholder-slate-200 dark:placeholder-white/10 mb-8 caret-ios-purple tracking-tight text-left"
            />

            <div
                ref={contentEditableRef}
                contentEditable
                suppressContentEditableWarning
                onInput={handleContentChange}
                onKeyDown={handleKeyDown}
                dir="ltr"
                dangerouslySetInnerHTML={{ __html: mainBlock.content }}
                className="w-full min-h-[50vh] outline-none text-xl md:text-2xl text-slate-700 dark:text-white/90 leading-relaxed caret-ios-purple empty:before:content-['Capture_the_signal...'] empty:before:text-slate-300 dark:empty:before:text-white/20 whitespace-pre-wrap text-left"
            />

            <div className="mt-8 space-y-4">
                {note.blocks.filter(b => b.type !== 'body').map(block => (
                    <div key={block.id} className="relative group">
                        {block.type === 'image' && <img src={block.content} className="rounded-2xl max-w-full shadow-2xl border border-black/5 dark:border-white/10" />}
                        {block.type === 'sketch' && <img src={block.content} className="rounded-2xl max-w-full bg-white p-2 shadow-2xl border border-black/5" />}
                        {block.type === 'checklist' && (
                            <div className="flex items-center gap-3 bg-slate-50 dark:bg-white/5 p-4 rounded-xl border border-black/5 dark:border-white/5">
                                <CheckSquare size={20} className={block.checked ? "text-ios-purple" : "text-slate-300 dark:text-white/30"} />
                                <span className={block.checked ? "line-through text-slate-400 dark:text-white/30" : "text-slate-800 dark:text-white"}>{block.content}</span>
                            </div>
                        )}
                        <button onClick={() => {
                            const newBlocks = note.blocks.filter(b => b.id !== block.id);
                            onUpdateNote({ ...note, blocks: newBlocks, updatedAt: new Date().toISOString() });
                        }} className="absolute top-2 right-2 bg-black/50 p-2 rounded-full text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><Trash size={16}/></button>
                    </div>
                ))}
            </div>
        </div>
      </div>

      {/* RICH TEXT FORMATTING BAR */}
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-white dark:bg-[#1C1C1E] border-t border-black/5 dark:border-white/10 z-30 flex items-center justify-center gap-2 md:gap-4 safe-area-bottom shadow-[0_-10px_40px_rgba(0,0,0,0.2)]">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-black p-1.5 rounded-xl border border-black/5 dark:border-white/10">
              <FormatBtn icon={<BoldIcon size={20}/>} onClick={() => execCmd('bold')} active={false} />
              <FormatBtn icon={<ItalicIcon size={20}/>} onClick={() => execCmd('italic')} active={false} />
          </div>

          <div className="w-px h-8 bg-black/10 dark:bg-white/10" />

          <div className="flex items-center gap-1 bg-slate-100 dark:bg-black p-1.5 rounded-xl border border-black/5 dark:border-white/10">
              <FormatBtn icon={<Heading size={20} />} onClick={() => execCmd('formatBlock', 'H1')} active={false} label="H1" />
              <FormatBtn icon={<AlignLeft size={20} />} onClick={() => execCmd('formatBlock', 'P')} active={false} label="P" />
          </div>

          <div className="w-px h-8 bg-black/10 dark:bg-white/10" />

          <div className="flex items-center gap-1 bg-slate-100 dark:bg-black p-1.5 rounded-xl border border-black/5 dark:border-white/10">
              <FormatBtn icon={<CheckSquare size={20} />} onClick={() => addSpecialBlock('checklist', 'New Entry')} active={false} />
              <FormatBtn icon={<ImageIcon size={20} />} onClick={() => fileInputRef.current?.click()} active={false} />
              <FormatBtn icon={<PenTool size={20} />} onClick={() => setShowSketch(true)} active={false} />
          </div>
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
      </div>

      {showSketch && <DrawingCanvas onSave={(dataUrl) => { addSpecialBlock('sketch', dataUrl); setShowSketch(false); }} onCancel={() => setShowSketch(false)} />}
    </div>
  );
};

const FormatBtn: React.FC<{ icon: React.ReactNode, onClick: () => void, active: boolean, label?: string }> = ({ icon, onClick, active, label }) => (
    <button 
        onMouseDown={(e) => { e.preventDefault(); onClick(); }} 
        className={`w-10 h-10 flex items-center justify-center rounded-lg transition-all ${active ? 'bg-ios-purple text-white' : 'text-slate-500 dark:text-white/70 hover:bg-slate-200 dark:hover:bg-white/20 hover:text-slate-900 dark:hover:text-white'}`}
    >
        {icon}
        {label && <span className="ml-1 text-[10px] font-black uppercase">{label}</span>}
    </button>
);

const DashboardCard: React.FC<{ icon: React.ReactNode, value: number, label: string, delay: number }> = ({ icon, value, label, delay }) => (
    <div className="bg-white dark:bg-ios-gray/40 border border-black/5 dark:border-white/5 rounded-3xl p-6 flex flex-col items-center justify-center gap-2 hover:border-ios-purple/30 transition-all group cursor-default shadow-sm animate-in zoom-in-50 duration-500" style={{ animationDelay: `${delay}ms` }}>
        <div className="text-ios-purple group-hover:scale-110 transition-transform duration-300 bg-ios-purple/10 p-3 rounded-xl mb-2">{icon}</div>
        <span className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter">{value}</span>
        <span className="text-[10px] font-black uppercase text-slate-400 dark:text-ios-textSec tracking-widest">{label}</span>
    </div>
)
