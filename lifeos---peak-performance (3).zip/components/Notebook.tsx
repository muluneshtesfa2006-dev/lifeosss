
import React, { useState, useEffect, useRef } from 'react';
import { 
    ChevronRight, MoreHorizontal, Sparkles, CheckSquare, 
    Type, Heading1, Heading2, Heading3, List, Image as ImageIcon,
    Link, ArrowUpRight, Search, FileText, Download, X
} from 'lucide-react';
import { NotebookData, NotebookBlock, WhiteboardItem, WhiteboardItemType } from '../types';
import { GeminiService } from '../services/geminiService';

interface NotebookProps {
    data: NotebookData;
    onUpdate: (data: NotebookData) => void;
    onLinkClick: (itemId: string) => void; // Focus board item
    onBlockUpdate: (blockId: string, content: string, linkedId?: string) => void; // Sync back to board
    isOpen: boolean;
    onClose: () => void;
}

export const Notebook: React.FC<NotebookProps> = ({ 
    data, onUpdate, onLinkClick, onBlockUpdate, isOpen, onClose 
}) => {
    const [title, setTitle] = useState(data.title);
    const [blocks, setBlocks] = useState<NotebookBlock[]>(data.blocks);
    const [focusedBlockId, setFocusedBlockId] = useState<string | null>(null);
    const [showSlashMenu, setShowSlashMenu] = useState<{ x: number, y: number, blockIndex: number } | null>(null);
    const [isAiProcessing, setIsAiProcessing] = useState(false);

    useEffect(() => {
        setBlocks(data.blocks);
        setTitle(data.title);
    }, [data]);

    const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setTitle(e.target.value);
        onUpdate({ ...data, title: e.target.value, updatedAt: new Date().toISOString() });
    };

    const updateBlockContent = (id: string, content: string) => {
        const newBlocks = blocks.map(b => b.id === id ? { ...b, content } : b);
        setBlocks(newBlocks);
        
        // Find if this block is linked to the board
        const block = blocks.find(b => b.id === id);
        if (block && block.linkedBoardId) {
            onBlockUpdate(block.id, content, block.linkedBoardId);
        }
        
        // Debounced save
        const timer = setTimeout(() => {
            onUpdate({ ...data, blocks: newBlocks, updatedAt: new Date().toISOString() });
        }, 500);
        return () => clearTimeout(timer);
    };

    const addBlock = (index: number, type: NotebookBlock['type'] = 'paragraph') => {
        const newBlock: NotebookBlock = {
            id: Math.random().toString(36).substr(2, 9),
            type,
            content: ''
        };
        const newBlocks = [...blocks];
        newBlocks.splice(index + 1, 0, newBlock);
        setBlocks(newBlocks);
        onUpdate({ ...data, blocks: newBlocks });
        setFocusedBlockId(newBlock.id);
        setShowSlashMenu(null);
    };

    const handleKeyDown = (e: React.KeyboardEvent, index: number, blockId: string) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            addBlock(index);
        }
        if (e.key === '/' && blocks[index].content === '') {
            const rect = (e.target as HTMLElement).getBoundingClientRect();
            setShowSlashMenu({ x: rect.left, y: rect.bottom + 10, blockIndex: index });
        }
        if (e.key === 'Backspace' && blocks[index].content === '' && blocks.length > 1) {
            e.preventDefault();
            const newBlocks = blocks.filter(b => b.id !== blockId);
            setBlocks(newBlocks);
            onUpdate({ ...data, blocks: newBlocks });
            if (index > 0) setFocusedBlockId(blocks[index - 1].id);
        }
    };

    // --- DRAG AND DROP HANDLERS (Transform Engine) ---
    const handleDragOver = (e: React.DragEvent) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault();
        const itemData = e.dataTransfer.getData('whiteboard-item');
        if (!itemData) return;

        const item: WhiteboardItem = JSON.parse(itemData);
        let newBlockType: NotebookBlock['type'] = 'paragraph';
        
        // 1. Transformation Logic
        if (item.type === 'STICKY') newBlockType = 'bullet';
        else if (item.type === 'TEXT') newBlockType = 'h2';
        else if (item.type === 'SHAPE') newBlockType = 'h3';

        const newBlock: NotebookBlock = {
            id: Math.random().toString(36).substr(2, 9),
            type: newBlockType,
            content: item.content || 'Untitled Object',
            linkedBoardId: item.id,
            accentColor: item.color
        };

        setBlocks([...blocks, newBlock]);
        onUpdate({ ...data, blocks: [...blocks, newBlock] });
    };

    const handleAiSummarize = async () => {
        setIsAiProcessing(true);
        try {
            const text = blocks.map(b => b.content).join('\n');
            const summary = await GeminiService.completeText(text, "Summarize these notes into a concise paragraph.");
            
            const summaryBlock: NotebookBlock = {
                id: Math.random().toString(36).substr(2, 9),
                type: 'synthesis',
                content: summary
            };
            
            const newBlocks = [...blocks, summaryBlock];
            setBlocks(newBlocks);
            onUpdate({ ...data, blocks: newBlocks });
        } catch (e) {
            console.error(e);
        } finally {
            setIsAiProcessing(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div 
            className="absolute top-4 bottom-4 right-4 w-[450px] bg-white dark:bg-[#1C1C1E] rounded-3xl shadow-2xl border border-black/5 dark:border-white/10 z-[60] flex flex-col overflow-hidden animate-in slide-in-from-right duration-300"
            onDragOver={handleDragOver}
            onDrop={handleDrop}
        >
            {/* Header */}
            <div className="flex justify-between items-center p-4 border-b border-black/5 dark:border-white/5 bg-gray-50/50 dark:bg-white/5 backdrop-blur-md">
                <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 font-medium">
                    <span>Project Alpha</span>
                    <ChevronRight size={14} />
                    <span className="text-black dark:text-white font-bold">Notes</span>
                </div>
                <div className="flex gap-2">
                    <button onClick={handleAiSummarize} className="p-2 hover:bg-black/5 dark:hover:bg-white/10 rounded-full text-ios-purple" title="AI Synthesize">
                        <Sparkles size={18} className={isAiProcessing ? "animate-pulse" : ""} />
                    </button>
                    <button className="p-2 hover:bg-black/5 dark:hover:bg-white/10 rounded-full text-gray-500 dark:text-gray-400">
                        <MoreHorizontal size={18} />
                    </button>
                    <button onClick={onClose} className="p-2 hover:bg-black/5 dark:hover:bg-white/10 rounded-full text-gray-500 dark:text-gray-400">
                        <X size={18} />
                    </button>
                </div>
            </div>

            {/* Document Area */}
            <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                <input 
                    value={title}
                    onChange={handleTitleChange}
                    className="w-full bg-transparent text-3xl font-black text-gray-900 dark:text-white border-none outline-none placeholder-gray-300 mb-8"
                    placeholder="Untitled Page"
                />

                <div className="space-y-2">
                    {blocks.map((block, index) => (
                        <div key={block.id} className="group relative flex items-start -ml-6 pl-6">
                            {/* Hover Controls */}
                            <div className="absolute left-0 top-1.5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                                {block.linkedBoardId ? (
                                    <button 
                                        onClick={() => onLinkClick(block.linkedBoardId!)}
                                        className="p-1 hover:bg-black/5 dark:hover:bg-white/10 rounded text-ios-purple"
                                        title="Locate on Board"
                                    >
                                        <ArrowUpRight size={14} />
                                    </button>
                                ) : (
                                    <button className="p-1 hover:bg-black/5 dark:hover:bg-white/10 rounded text-gray-300 drag-handle cursor-grab">
                                        <MoreHorizontal size={14} />
                                    </button>
                                )}
                            </div>

                            {/* Accent Bar for Linked Items */}
                            {block.linkedBoardId && block.accentColor && (
                                <div className="absolute left-0 top-0 bottom-0 w-1 rounded-full mr-2" style={{ backgroundColor: block.accentColor }} />
                            )}

                            {/* Block Renderer */}
                            <div className="flex-1 min-w-0">
                                <BlockRenderer 
                                    block={block} 
                                    index={index}
                                    focused={focusedBlockId === block.id}
                                    onUpdate={(content) => updateBlockContent(block.id, content)}
                                    onKeyDown={(e) => handleKeyDown(e, index, block.id)}
                                    setFocus={() => setFocusedBlockId(block.id)}
                                />
                            </div>
                        </div>
                    ))}
                    
                    {/* Empty State / Drop Zone Hint */}
                    {blocks.length === 0 && (
                        <div className="h-32 border-2 border-dashed border-gray-200 dark:border-white/10 rounded-xl flex flex-col items-center justify-center text-gray-400 text-sm">
                            <Download size={24} className="mb-2 opacity-50" />
                            Drag items from board here
                        </div>
                    )}
                </div>
            </div>

            {/* Slash Menu */}
            {showSlashMenu && (
                <>
                    <div className="fixed inset-0 z-[70]" onClick={() => setShowSlashMenu(null)} />
                    <div 
                        className="fixed bg-white dark:bg-[#2C2C2E] border border-black/10 dark:border-white/10 rounded-xl shadow-xl z-[80] w-48 py-2 animate-in fade-in zoom-in-95 duration-200 overflow-hidden"
                        style={{ top: showSlashMenu.y, left: showSlashMenu.x }}
                    >
                        <SlashOption icon={<Type size={14}/>} label="Text" onClick={() => { const ns = [...blocks]; ns[showSlashMenu.blockIndex].type = 'paragraph'; setBlocks(ns); setShowSlashMenu(null); }} />
                        <SlashOption icon={<Heading1 size={14}/>} label="Heading 1" onClick={() => { const ns = [...blocks]; ns[showSlashMenu.blockIndex].type = 'h1'; setBlocks(ns); setShowSlashMenu(null); }} />
                        <SlashOption icon={<Heading2 size={14}/>} label="Heading 2" onClick={() => { const ns = [...blocks]; ns[showSlashMenu.blockIndex].type = 'h2'; setBlocks(ns); setShowSlashMenu(null); }} />
                        <SlashOption icon={<List size={14}/>} label="Bullet List" onClick={() => { const ns = [...blocks]; ns[showSlashMenu.blockIndex].type = 'bullet'; setBlocks(ns); setShowSlashMenu(null); }} />
                        <SlashOption icon={<CheckSquare size={14}/>} label="Checklist" onClick={() => { const ns = [...blocks]; ns[showSlashMenu.blockIndex].type = 'checkbox'; setBlocks(ns); setShowSlashMenu(null); }} />
                        <SlashOption icon={<Sparkles size={14}/>} label="AI Synthesis" onClick={() => { const ns = [...blocks]; ns[showSlashMenu.blockIndex].type = 'synthesis'; setBlocks(ns); setShowSlashMenu(null); }} />
                    </div>
                </>
            )}
        </div>
    );
};

const BlockRenderer: React.FC<{ 
    block: NotebookBlock, 
    index: number,
    focused: boolean, 
    onUpdate: (val: string) => void, 
    onKeyDown: (e: React.KeyboardEvent) => void,
    setFocus: () => void
}> = ({ block, focused, onUpdate, onKeyDown, setFocus }) => {
    const ref = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (focused && ref.current) {
            ref.current.focus();
        }
    }, [focused]);

    const commonClass = "outline-none empty:before:content-['Type_something...'] empty:before:text-gray-300 dark:empty:before:text-white/20";

    if (block.type === 'h1') return <div ref={ref} contentEditable onInput={e => onUpdate(e.currentTarget.innerText)} onKeyDown={onKeyDown} onClick={setFocus} className={`text-2xl font-bold mb-2 text-black dark:text-white ${commonClass}`}>{block.content}</div>;
    if (block.type === 'h2') return <div ref={ref} contentEditable onInput={e => onUpdate(e.currentTarget.innerText)} onKeyDown={onKeyDown} onClick={setFocus} className={`text-xl font-bold mt-4 mb-2 text-black dark:text-white ${commonClass}`}>{block.content}</div>;
    if (block.type === 'h3') return <div ref={ref} contentEditable onInput={e => onUpdate(e.currentTarget.innerText)} onKeyDown={onKeyDown} onClick={setFocus} className={`text-lg font-bold mt-2 mb-1 text-black dark:text-white ${commonClass}`}>{block.content}</div>;
    
    if (block.type === 'bullet') {
        return (
            <div className="flex items-start gap-2 mb-1">
                <span className="text-gray-400 mt-1.5">•</span>
                <div ref={ref} contentEditable onInput={e => onUpdate(e.currentTarget.innerText)} onKeyDown={onKeyDown} onClick={setFocus} className={`flex-1 text-base text-gray-800 dark:text-gray-200 ${commonClass}`}>{block.content}</div>
            </div>
        );
    }

    if (block.type === 'checkbox') {
        return (
            <div className="flex items-start gap-2 mb-1">
                <input type="checkbox" className="mt-1.5 accent-ios-purple" checked={block.checked} onChange={() => {}} />
                <div ref={ref} contentEditable onInput={e => onUpdate(e.currentTarget.innerText)} onKeyDown={onKeyDown} onClick={setFocus} className={`flex-1 text-base text-gray-800 dark:text-gray-200 ${commonClass} ${block.checked ? 'line-through opacity-50' : ''}`}>{block.content}</div>
            </div>
        );
    }

    if (block.type === 'synthesis') {
        return (
            <div className="bg-ios-purple/5 border border-ios-purple/20 rounded-xl p-4 my-2 text-sm text-gray-700 dark:text-gray-300 leading-relaxed relative overflow-hidden">
                <div className="absolute top-0 right-0 p-2 opacity-10"><Sparkles size={40} /></div>
                <div className="font-bold text-ios-purple text-xs uppercase tracking-widest mb-1 flex items-center gap-1"><Sparkles size={10}/> AI Synthesis</div>
                {block.content}
            </div>
        )
    }

    return <div ref={ref} contentEditable onInput={e => onUpdate(e.currentTarget.innerText)} onKeyDown={onKeyDown} onClick={setFocus} className={`text-base leading-relaxed mb-2 text-gray-800 dark:text-gray-200 ${commonClass}`}>{block.content}</div>;
};

const SlashOption: React.FC<{ icon: React.ReactNode, label: string, onClick: () => void }> = ({ icon, label, onClick }) => (
    <button onClick={onClick} className="w-full flex items-center gap-3 px-4 py-2 hover:bg-black/5 dark:hover:bg-white/10 text-sm text-black dark:text-white transition-colors">
        {icon} <span>{label}</span>
    </button>
);
