
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Plan, PlanCategory, PlanPhase, PlanMilestone, ModuleType, Attachment, TableColumn } from '../types';
import { StorageService } from '../services/storageService';
import { 
  ChevronLeft, Plus, Target, Activity, Layers, Clock, CheckCircle2, 
  Dumbbell, Briefcase, Wallet, Heart, Lightbulb, Trash2, X,
  Zap, Trophy, Rocket, ChevronDown, Flame, Radar as RadarIcon, Timer,
  Edit3, Calendar, Maximize2, Sliders, Play, RotateCcw, AlertCircle,
  Eye, EyeOff, LayoutList, Kanban as KanbanIcon, Network, Circle,
  DollarSign, Repeat, Info, ChevronUp, BarChart3, Scale, Link, File,
  MoreVertical, Check, ExternalLink, Download, UploadCloud, ChevronRight,
  Database, Image as ImageIcon, Mic, Table as TableIcon, Move, Grid, List, StickyNote, Square, CheckSquare,
  ArrowRight, Settings, CalendarRange, TrendingUp, LayoutTemplate, Paperclip, Pause
} from 'lucide-react';
import { 
  ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, XAxis, CartesianGrid, 
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip, BarChart, Bar, YAxis
} from 'recharts';

export const Plans: React.FC = () => {
    const [view, setView] = useState<'DASHBOARD' | 'DETAIL'>('DASHBOARD');
    const [plans, setPlans] = useState<Plan[]>([]);
    const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [showAchievement, setShowAchievement] = useState(false);
    const [xpGained, setXpGained] = useState(0);

    useEffect(() => {
        setPlans(StorageService.getPlans());
    }, []);

    const handleCreatePlan = (newPlan: Plan) => {
        const updated = [...plans, newPlan];
        setPlans(updated);
        StorageService.savePlans(updated);
        setShowCreateModal(false);
        setSelectedPlan(newPlan);
        setView('DETAIL');
    };

    const handleUpdatePlan = (updatedPlan: Plan) => {
        const updated = plans.map(p => p.id === updatedPlan.id ? updatedPlan : p);
        setPlans(updated);
        StorageService.savePlans(updated);
        setSelectedPlan(updatedPlan);
    };

    const handleDeletePlan = (id: string) => {
        const updated = plans.filter(p => p.id !== id);
        setPlans(updated);
        StorageService.savePlans(updated);
        setView('DASHBOARD');
        setSelectedPlan(null);
    };

    const handleFinishPlan = (plan: Plan) => {
        if(plan.status === 'Completed') return;
        const updated = { ...plan, status: 'Completed' as const };
        handleUpdatePlan(updated);
        StorageService.awardPlanXp(plan.xpReward);
        setXpGained(plan.xpReward);
        setShowAchievement(true);
    };

    return (
        <div className="flex-1 h-full bg-black text-white flex flex-col font-sans relative overflow-hidden">
            {showAchievement && <AchievementOverlay xp={xpGained} onClose={() => setShowAchievement(false)} />}

            {view === 'DASHBOARD' && (
                <div className="flex-1 h-full overflow-y-auto no-scrollbar relative z-10 animate-in fade-in duration-500">
                    <div className="px-6 pt-12 pb-8 bg-gradient-to-b from-black via-black/95 to-black/80">
                        <div className="flex justify-between items-center mb-10">
                            <div>
                                <h1 className="text-5xl font-black tracking-tighter text-white mb-2">Master Plans</h1>
                                <p className="text-ios-textSec text-sm uppercase tracking-[0.3em]">Strategic Life Architecture</p>
                            </div>
                            <button onClick={() => setShowCreateModal(true)} className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center hover:scale-110 transition-transform shadow-[0_0_30px_rgba(255,255,255,0.3)] group">
                                <Plus size={28} className="group-hover:rotate-90 transition-transform duration-300" />
                            </button>
                        </div>
                        <PlansDashboardHeader plans={plans} />
                    </div>

                    <div className="px-6 pb-32 grid grid-cols-1 md:grid-cols-2 gap-6">
                        {plans.map(plan => (
                            <PlanCard 
                                key={plan.id} 
                                plan={plan} 
                                onClick={() => { setSelectedPlan(plan); setView('DETAIL'); }} 
                            />
                        ))}
                    </div>
                </div>
            )}

            {view === 'DETAIL' && selectedPlan && (
                <PlanDetailView 
                    plan={selectedPlan} 
                    onBack={() => setView('DASHBOARD')}
                    onUpdate={handleUpdatePlan}
                    onDelete={() => handleDeletePlan(selectedPlan.id)}
                    onFinish={() => handleFinishPlan(selectedPlan)}
                />
            )}

            {showCreateModal && <CreatePlanModal onClose={() => setShowCreateModal(false)} onSave={handleCreatePlan} />}
        </div>
    );
};

// --- VISUAL COMPONENTS ---

const AchievementOverlay: React.FC<{ xp: number, onClose: () => void }> = ({ xp, onClose }) => (
    <div className="fixed inset-0 z-[100] bg-black/95 flex flex-col items-center justify-center animate-in fade-in duration-1000 cursor-pointer backdrop-blur-xl" onClick={onClose}>
         <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#BF5AF2_0%,_transparent_70%)] opacity-30 animate-pulse-slow"></div>
         <div className="relative z-10 text-center scale-110 transform transition-all duration-1000 animate-zoom-in">
             <div className="w-64 h-64 mx-auto bg-gradient-to-tr from-ios-yellow via-orange-500 to-red-500 rounded-full flex items-center justify-center shadow-[0_0_150px_rgba(255,214,10,0.8)] mb-12 animate-bounce border-4 border-white/20">
                 <Trophy size={128} className="text-white fill-white drop-shadow-2xl" />
             </div>
             <h2 className="text-8xl md:text-9xl font-black text-white mb-6 tracking-tighter drop-shadow-2xl uppercase">Legacy Secured</h2>
             <div className="inline-block bg-white/10 rounded-full px-12 py-6 border border-white/20 backdrop-blur-md mb-12 shadow-2xl">
                 <span className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-ios-yellow to-white">+{xp} XP</span>
             </div>
         </div>
         <p className="absolute bottom-20 text-white/30 text-sm uppercase tracking-[0.5em] animate-pulse">Touch to Ascend</p>
    </div>
)

const PlansDashboardHeader: React.FC<{ plans: Plan[] }> = ({ plans }) => {
    const activePlans = plans.filter(p => p.status === 'Active').length;
    let totalXP = 0;
    const categoryCounts: Record<string, number> = { Physical: 0, Career: 0, Financial: 0, Lifestyle: 0, Skill: 0 };
    
    plans.forEach(p => {
        if(p.status === 'Active') {
            totalXP += p.xpReward;
            categoryCounts[p.category] = (categoryCounts[p.category] || 0) + 1;
        }
    });

    const radarData = Object.keys(categoryCounts).map(k => ({ subject: k, A: categoryCounts[k], fullMark: 5 }));
    const areaData = [{name:'M',val:20},{name:'T',val:40},{name:'W',val:30},{name:'T',val:70},{name:'F',val:50},{name:'S',val:90},{name:'S',val:60}];

    return (
        <div className="animate-in slide-in-from-bottom-8 duration-700 space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-[#1C1C1E] border border-white/10 rounded-2xl p-4 flex items-center gap-4">
                    <div className="p-3 bg-white/5 rounded-full text-ios-purple"><Target size={24}/></div>
                    <div><span className="text-[10px] text-ios-textSec uppercase font-bold">Active Protocols</span><div className="text-2xl font-black text-white">{activePlans}</div></div>
                </div>
                <div className="bg-[#1C1C1E] border border-white/10 rounded-2xl p-4 flex items-center gap-4">
                    <div className="p-3 bg-white/5 rounded-full text-ios-yellow"><Zap size={24}/></div>
                    <div><span className="text-[10px] text-ios-textSec uppercase font-bold">Total Potential</span><div className="text-2xl font-black text-white">{totalXP.toLocaleString()} XP</div></div>
                </div>
                <div className="bg-[#1C1C1E] border border-white/10 rounded-2xl p-4 flex items-center gap-4">
                    <div className="p-3 bg-white/5 rounded-full text-ios-blue"><Activity size={24}/></div>
                    <div><span className="text-[10px] text-ios-textSec uppercase font-bold">Velocity</span><div className="text-2xl font-black text-white">High</div></div>
                </div>
                <div className="bg-[#1C1C1E] border border-white/10 rounded-2xl p-4 flex items-center gap-4">
                    <div className="p-3 bg-white/5 rounded-full text-ios-green"><CheckCircle2 size={24}/></div>
                    <div><span className="text-[10px] text-ios-textSec uppercase font-bold">Completion</span><div className="text-2xl font-black text-white">42%</div></div>
                </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-[#1C1C1E] border border-white/10 rounded-3xl p-6 relative overflow-hidden h-80">
                    <div className="flex justify-between items-center mb-6"><h3 className="text-xs font-bold text-ios-textSec uppercase tracking-widest flex items-center gap-2"><TrendingUp size={14} className="text-ios-blue"/> Execution Velocity</h3></div>
                    <div className="h-64 w-full"><ResponsiveContainer width="100%" height="100%"><AreaChart data={areaData}><defs><linearGradient id="colorVel" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#0A84FF" stopOpacity={0.5}/><stop offset="95%" stopColor="#0A84FF" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} /><XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#8E8E93', fontSize: 10}} dy={10} /><Area type="monotone" dataKey="val" stroke="#0A84FF" strokeWidth={3} fill="url(#colorVel)" /></AreaChart></ResponsiveContainer></div>
                </div>
                <div className="bg-[#1C1C1E] border border-white/10 rounded-3xl p-6 relative overflow-hidden h-80"><h3 className="text-xs font-bold text-ios-textSec uppercase tracking-widest mb-4 text-center">Strategic Balance</h3><div className="h-64 w-full"><ResponsiveContainer width="100%" height="100%"><RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}><PolarGrid stroke="#333" /><PolarAngleAxis dataKey="subject" tick={{ fill: '#8E8E93', fontSize: 10, fontWeight: 'bold' }} /><Radar name="Count" dataKey="A" stroke="#BF5AF2" strokeWidth={2} fill="#BF5AF2" fillOpacity={0.4} /></RadarChart></ResponsiveContainer></div></div>
            </div>
        </div>
    )
}

const PlanCard: React.FC<{ plan: Plan, onClick: () => void }> = ({ plan, onClick }) => {
    const end = new Date(plan.endDate);
    const now = new Date();
    const daysLeft = Math.max(0, Math.ceil((end.getTime() - now.getTime()) / (1000 * 3600 * 24)));
    const total = plan.phases?.reduce((acc, p) => acc + p.milestones.length, 0) || 0;
    const done = plan.phases?.reduce((acc, p) => acc + p.milestones.filter(m => m.isCompleted).length, 0) || 0;
    const progress = total > 0 ? (done / total) * 100 : 0;

    return (
        <div onClick={onClick} className="group bg-[#1C1C1E] border border-white/10 hover:border-ios-purple/50 rounded-3xl p-6 cursor-pointer transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_10px_40px_rgba(0,0,0,0.5)] relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            <div className="relative z-10">
                <div className="flex justify-between items-start mb-6">
                    <div className="flex gap-2">
                        <span className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full border ${plan.category === 'Physical' ? 'text-red-500 border-red-500/30 bg-red-500/10' : plan.category === 'Career' ? 'text-blue-500 border-blue-500/30 bg-blue-500/10' : 'text-yellow-500 border-yellow-500/30 bg-yellow-500/10'}`}>{plan.category}</span>
                        {plan.priority && (<span className={`text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-full border ${plan.priority === 'High' ? 'text-red-500 border-red-500 bg-red-500/10' : 'text-gray-400 border-gray-600 bg-gray-500/10'}`}>{plan.priority}</span>)}
                    </div>
                    <div className="flex items-center gap-1 text-xs font-mono text-ios-textSec"><Clock size={12} /> {daysLeft}D</div>
                </div>
                <h3 className="text-3xl font-black text-white mb-2 leading-tight group-hover:text-ios-purple transition-colors">{plan.title}</h3>
                <p className="text-ios-textSec text-sm line-clamp-2 mb-8 font-medium">{plan.description}</p>
                <div className="h-16 flex items-end gap-1 mb-4 opacity-50 group-hover:opacity-100 transition-opacity">{[...Array(15)].map((_, i) => (<div key={i} className="flex-1 bg-white/20 rounded-sm" style={{ height: `${Math.random() * 100}%` }} />))}</div>
                <div className="flex items-center gap-4"><div className="flex-1 h-2 bg-black rounded-full overflow-hidden border border-white/10"><div className="h-full bg-white group-hover:bg-ios-purple transition-colors duration-500" style={{ width: `${progress}%` }} /></div><span className="text-xs font-bold text-white">{Math.round(progress)}%</span></div>
            </div>
        </div>
    )
}

// --- 3D TIME DILATION UNIT ---
const TimeDilationUnit: React.FC<{ endDate: string }> = ({ endDate }) => {
    const [timeLeft, setTimeLeft] = useState<{ days: number, hours: number, mins: number, secs: number }>({ days: 0, hours: 0, mins: 0, secs: 0 });
    
    useEffect(() => {
        const interval = setInterval(() => {
            const now = new Date().getTime();
            const end = new Date(endDate).getTime();
            const distance = end - now;
            if (distance < 0) {
                setTimeLeft({ days: 0, hours: 0, mins: 0, secs: 0 });
            } else {
                setTimeLeft({
                    days: Math.floor(distance / (1000 * 60 * 60 * 24)),
                    hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
                    mins: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
                    secs: Math.floor((distance % (1000 * 60)) / 1000)
                });
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [endDate]);

    return (
        <div className="relative w-full h-64 overflow-hidden rounded-[3rem] bg-black border border-white/10 mb-8 group perspective-container shadow-2xl">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#1C1C1E_0%,_#000000_100%)] opacity-80" />
            <div className="absolute inset-0 flex items-center justify-center opacity-30 pointer-events-none">
                <div className="w-96 h-96 border border-ios-purple/30 rounded-full animate-[spin_20s_linear_infinite]" style={{ transform: 'rotateX(60deg)' }}></div>
                <div className="absolute w-80 h-80 border border-blue-500/30 rounded-full animate-[spin_15s_linear_infinite_reverse]" style={{ transform: 'rotateY(60deg)' }}></div>
            </div>
            <div className="relative z-10 h-full flex flex-col items-center justify-center gap-6">
                <div className="flex items-center gap-3">
                    <Activity size={16} className="text-ios-green animate-pulse" />
                    <span className="text-xs font-bold text-ios-textSec uppercase tracking-[0.5em]">Temporal Sync Active</span>
                </div>
                <div className="flex gap-4 md:gap-8 text-center">
                    <TimeSegment val={timeLeft.days} label="DAYS" />
                    <div className="text-4xl font-thin text-white/20 self-center mb-6">:</div>
                    <TimeSegment val={timeLeft.hours} label="HRS" />
                    <div className="text-4xl font-thin text-white/20 self-center mb-6">:</div>
                    <TimeSegment val={timeLeft.mins} label="MIN" />
                    <div className="text-4xl font-thin text-white/20 self-center mb-6">:</div>
                    <TimeSegment val={timeLeft.secs} label="SEC" highlight />
                </div>
            </div>
        </div>
    )
}

const TimeSegment = ({ val, label, highlight }: { val: number, label: string, highlight?: boolean }) => (
    <div className="flex flex-col items-center">
        <div className={`relative bg-gradient-to-b from-[#2C2C2E] to-black border border-white/10 w-20 h-24 md:w-24 md:h-32 rounded-2xl flex items-center justify-center shadow-lg transform transition-transform hover:scale-110 ${highlight ? 'shadow-[0_0_20px_rgba(191,90,242,0.3)] border-ios-purple/30' : ''}`}>
            <span className={`text-4xl md:text-6xl font-black font-mono ${highlight ? 'text-ios-purple' : 'text-white'}`}>
                {val.toString().padStart(2, '0')}
            </span>
            <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/5 to-transparent rounded-t-2xl pointer-events-none" />
        </div>
        <span className="mt-3 text-[10px] font-bold text-ios-textSec tracking-[0.2em]">{label}</span>
    </div>
)

// --- PLAN DETAIL VIEW ---

const PlanDetailView: React.FC<{ plan: Plan, onBack: () => void, onUpdate: (p: Plan) => void, onDelete: () => void, onFinish: () => void }> = ({ plan, onBack, onUpdate, onDelete, onFinish }) => {
    const [editingPhase, setEditingPhase] = useState<PlanPhase | null>(null);
    const [editingMilestone, setEditingMilestone] = useState<{ pId: string, m: PlanMilestone } | null>(null);
    const [showModulePicker, setShowModulePicker] = useState(false);
    const [showTemplatePicker, setShowTemplatePicker] = useState(false);
    const [setupModuleType, setSetupModuleType] = useState<ModuleType | null>(null);
    const [expandedMilestoneId, setExpandedMilestoneId] = useState<string | null>(null);
    
    // Drag & Drop
    const [draggedPhaseIndex, setDraggedPhaseIndex] = useState<number | null>(null);
    const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

    // FIX: Completion Logic needs to check ALL milestones in ALL phases
    const isPlanComplete = useMemo(() => {
        if (!plan.phases || plan.phases.length === 0) return false;
        // Collect all milestones across all phases
        const allMilestones = plan.phases.flatMap(p => p.milestones);
        if (allMilestones.length === 0) return false;
        // Check if every milestone is completed
        return allMilestones.every(m => m.isCompleted);
    }, [plan.phases]);

    // Aggregate Budget from ALL modules
    const aggregatedBudget = useMemo(() => {
        let totalCost = 0;
        let totalPaid = 0;
        plan.phases?.forEach(p => {
            p.milestones.forEach(m => {
                if (m.cost) totalCost += m.cost;
                if (m.paid) totalPaid += m.paid;
            });
        });
        return { totalCost, totalPaid };
    }, [plan.phases]);

    const handleApplyTemplate = (templateName: string) => {
        const startDate = new Date().toISOString().split('T')[0];
        const endDate = new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0];
        
        let newPhases: PlanPhase[] = [];
        
        // TEMPLATES 1-9
        switch(templateName) {
            case '1': // Genesis (Startup)
                newPhases = [
                    { id: Math.random().toString(), title: 'Phase 1: Validation', type: 'TIMELINE', width: 'full', startDate, endDate, milestones: [], color: '#BF5AF2' },
                    { id: Math.random().toString(), title: 'Burn Rate', type: 'BUDGET', width: 'half', startDate, endDate, milestones: [], budgetLimit: 5000, color: '#30D158' },
                    { id: Math.random().toString(), title: 'Launch Tasks', type: 'TODO', width: 'half', startDate, endDate, milestones: [], color: '#FF9F0A' }
                ]; break;
            case '2': // Titan (Fitness)
                newPhases = [
                    { id: Math.random().toString(), title: 'Workout Logs', type: 'DATA_TABLE', width: 'full', startDate, endDate, milestones: [], tableColumns: [{id:'c1',name:'Exercise',type:'text'}, {id:'c2',name:'Weight',type:'number'}, {id:'c3',name:'Reps',type:'number'}], color: '#FF375F' },
                    { id: Math.random().toString(), title: 'Diet Plan', type: 'TIMELINE', width: 'half', startDate, endDate, milestones: [], color: '#64D2FF' },
                    { id: Math.random().toString(), title: 'Rest Timer', type: 'TIMER', width: 'half', startDate, endDate, milestones: [], color: '#FFD60A' }
                ]; break;
            case '3': // Odyssey (Travel)
                newPhases = [
                    { id: Math.random().toString(), title: 'Itinerary', type: 'TIMELINE', width: 'full', startDate, endDate, milestones: [], color: '#0A84FF' },
                    { id: Math.random().toString(), title: 'Trip Budget', type: 'BUDGET', width: 'full', startDate, endDate, milestones: [], budgetLimit: 2000, color: '#30D158' },
                ]; break;
            case '4': // Scholar (Study)
                newPhases = [
                    { id: Math.random().toString(), title: 'Study Schedule', type: 'TIMELINE', width: 'full', startDate, endDate, milestones: [], color: '#BF5AF2' },
                    { id: Math.random().toString(), title: 'Focus Timer', type: 'TIMER', width: 'half', startDate, endDate, milestones: [], color: '#FFD60A' },
                    { id: Math.random().toString(), title: 'Assignments', type: 'TODO', width: 'half', startDate, endDate, milestones: [], color: '#FF9F0A' }
                ]; break;
            case '5': // Monarch (Finance)
                newPhases = [
                    { id: Math.random().toString(), title: 'Master Budget', type: 'BUDGET', width: 'full', startDate, endDate, milestones: [], budgetLimit: 10000, color: '#30D158' },
                    { id: Math.random().toString(), title: 'Investments', type: 'DATA_TABLE', width: 'full', startDate, endDate, milestones: [], tableColumns: [{id:'c1',name:'Asset',type:'text'}, {id:'c2',name:'Value',type:'money'}], color: '#64D2FF' },
                ]; break;
            case '6': // Architect (Coding)
                newPhases = [
                    { id: Math.random().toString(), title: 'Roadmap', type: 'TIMELINE', width: 'full', startDate, endDate, milestones: [], color: '#BF5AF2' },
                    { id: Math.random().toString(), title: 'Bugs', type: 'TODO', width: 'half', startDate, endDate, milestones: [], color: '#FF375F' },
                    { id: Math.random().toString(), title: 'Sprint Timer', type: 'TIMER', width: 'half', startDate, endDate, milestones: [], color: '#FFD60A' }
                ]; break;
            case '7': // Zenith (Habit)
                newPhases = [
                    { id: Math.random().toString(), title: 'Morning Routine', type: 'TODO', width: 'half', startDate, endDate, milestones: [], color: '#FFD60A' },
                    { id: Math.random().toString(), title: 'Night Routine', type: 'TODO', width: 'half', startDate, endDate, milestones: [], color: '#64D2FF' },
                    { id: Math.random().toString(), title: 'Meditation Timer', type: 'TIMER', width: 'full', startDate, endDate, milestones: [], color: '#BF5AF2' }
                ]; break;
            case '8': // Vortex (Creative)
                newPhases = [
                    { id: Math.random().toString(), title: 'Idea Board', type: 'NOTE', width: 'full', startDate, endDate, milestones: [], color: '#FF9F0A', content: 'Brainstorm here...' },
                    { id: Math.random().toString(), title: 'Drafts', type: 'DATA_TABLE', width: 'full', startDate, endDate, milestones: [], tableColumns: [{id:'c1',name:'Title',type:'text'},{id:'c2',name:'Status',type:'status'}], color: '#64D2FF' }
                ]; break;
            case '9': // Horizon (Life)
                newPhases = [
                    { id: Math.random().toString(), title: 'Bucket List', type: 'TODO', width: 'full', startDate, endDate, milestones: [], color: '#FF375F' },
                    { id: Math.random().toString(), title: 'Savings', type: 'BUDGET', width: 'half', startDate, endDate, milestones: [], budgetLimit: 50000, color: '#30D158' },
                    { id: Math.random().toString(), title: 'Milestones', type: 'TIMELINE', width: 'half', startDate, endDate, milestones: [], color: '#0A84FF' }
                ]; break;
        }

        onUpdate({ ...plan, phases: [...(plan.phases || []), ...newPhases] });
        setShowTemplatePicker(false);
    };

    // ... (Drag logic - Keep same as before) ...
    const handleDragStart = (e: React.DragEvent, index: number) => { setDraggedPhaseIndex(index); e.dataTransfer.effectAllowed = 'move'; (e.target as HTMLElement).style.opacity = '0.5'; };
    const handleDragEnd = (e: React.DragEvent) => { setDraggedPhaseIndex(null); setDragOverIndex(null); (e.target as HTMLElement).style.opacity = '1'; };
    const handleDragOver = (e: React.DragEvent, index: number) => { e.preventDefault(); if (draggedPhaseIndex !== index) setDragOverIndex(index); };
    const handleDrop = (e: React.DragEvent, targetIndex: number) => { e.preventDefault(); if (draggedPhaseIndex === null || draggedPhaseIndex === targetIndex) return; const newPhases = [...(plan.phases || [])]; const [moved] = newPhases.splice(draggedPhaseIndex, 1); newPhases.splice(targetIndex, 0, moved); onUpdate({ ...plan, phases: newPhases }); setDraggedPhaseIndex(null); setDragOverIndex(null); };

    const initSetup = (type: ModuleType) => {
        setSetupModuleType(type);
        setShowModulePicker(false);
    };

    const confirmNewModule = (config: { title: string, budgetLimit?: number, desc?: string }) => {
        if (!setupModuleType) return;
        const newPhase: PlanPhase = {
            id: Math.random().toString(36).substr(2, 9),
            title: config.title,
            type: setupModuleType,
            width: setupModuleType === 'BUDGET' ? 'half' : 'full',
            startDate: plan.startDate,
            endDate: plan.endDate,
            color: '#BF5AF2',
            milestones: [],
            budgetLimit: config.budgetLimit,
            content: config.desc, 
            tableColumns: setupModuleType === 'DATA_TABLE' ? [{id: 'c1', name: 'Item', type: 'text'}] : undefined
        };
        onUpdate({ ...plan, phases: [...(plan.phases || []), newPhase] });
        setSetupModuleType(null);
    };

    // --- Phase Rendering ---
    const renderPhaseCard = (phase: PlanPhase, index: number) => {
        const isBudget = phase.type === 'BUDGET';
        
        let displayCost = 0; let displayLimit = 0; let displayPaid = 0;
        if (isBudget) {
            displayCost = aggregatedBudget.totalCost;
            displayPaid = aggregatedBudget.totalPaid;
            displayLimit = phase.budgetLimit || 5000;
        }
        
        const remaining = Math.max(0, displayLimit - displayPaid);
        const percent = displayLimit > 0 ? Math.min(100, (displayPaid / displayLimit) * 100) : 0;

        return (
            <div 
                className={`relative group transition-all duration-300 ${draggedPhaseIndex === index ? 'scale-95 opacity-50' : 'opacity-100'}`}
                draggable
                onDragStart={(e) => handleDragStart(e, index)}
                onDragEnd={handleDragEnd}
                onDragOver={(e) => handleDragOver(e, index)}
                onDrop={(e) => handleDrop(e, index)}
            >
                {dragOverIndex === index && <div className="absolute -top-4 left-0 right-0 h-1 bg-ios-purple shadow-[0_0_10px_#BF5AF2] rounded-full z-50 animate-pulse" />}
                <div className="bg-[#1C1C1E] border border-white/5 rounded-2xl overflow-hidden hover:border-white/20 transition-all shadow-lg flex flex-col h-full">
                    {/* Header */}
                    <div className="flex flex-col p-4 bg-white/[0.02] border-b border-white/5 cursor-grab active:cursor-grabbing">
                        <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-white/5 rounded-lg text-white/70">{getModuleIcon(phase.type)}</div>
                                <span className="font-bold text-white text-lg">{phase.title}</span>
                            </div>
                            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => togglePhaseWidth(phase.id)} className="p-1.5 hover:bg-white/10 rounded"><Grid size={14}/></button>
                                <button onClick={() => setEditingPhase(phase)} className="p-1.5 hover:bg-white/10 rounded"><Edit3 size={14}/></button>
                                <button onClick={() => deletePhase(phase.id)} className="p-1.5 hover:bg-red-500/20 hover:text-red-500 rounded"><Trash2 size={14}/></button>
                            </div>
                        </div>
                        {phase.content && <p className="text-xs text-ios-textSec pl-12 line-clamp-2">{phase.content}</p>}
                    </div>

                    <div className="p-4 flex-1 flex flex-col">
                        {isBudget && (
                            <div className="mb-6 bg-gradient-to-br from-green-900/20 to-black rounded-xl p-6 border border-green-500/20 relative overflow-hidden group/budget">
                                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10 mix-blend-overlay"></div>
                                <div className="relative z-10">
                                    <div className="flex justify-between items-start mb-2">
                                        <span className="text-xs font-bold uppercase text-green-400 tracking-widest">Global Budget</span>
                                        <div className="bg-green-500/10 px-2 py-1 rounded text-[10px] font-bold text-green-400 border border-green-500/20">USD</div>
                                    </div>
                                    <div className="text-5xl font-black text-white tracking-tighter mb-6">${remaining.toLocaleString()}</div>
                                    <div className="space-y-2">
                                        <div className="flex justify-between text-xs font-medium text-white/60"><span>Spent: ${displayPaid.toLocaleString()}</span><span>Cap: ${displayLimit.toLocaleString()}</span></div>
                                        <div className="h-4 w-full bg-black/50 rounded-full border border-white/5 overflow-hidden relative">
                                            <div className="h-full bg-gradient-to-r from-green-500 to-emerald-400 transition-all duration-1000" style={{ width: `${percent}%` }} />
                                        </div>
                                    </div>
                                    <div className="mt-4 pt-4 border-t border-white/5">
                                        <span className="text-[10px] text-ios-textSec uppercase font-bold mb-2 block">Detected Costs</span>
                                        <div className="space-y-1 max-h-32 overflow-y-auto no-scrollbar">
                                            {plan.phases.flatMap(p => p.milestones.filter(m => (m.cost || 0) > 0)).map(m => (
                                                <div key={m.id} className="flex justify-between text-xs text-white/70">
                                                    <span>{m.title}</span>
                                                    <span>${m.paid || 0} / ${m.cost}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* TIMER MODULE RENDERER */}
                        {phase.type === 'TIMER' && <TimerModule phase={phase} />}

                        {/* DATA GRID RENDERER */}
                        {phase.type === 'DATA_TABLE' ? (
                            <DataTableModule phase={phase} onUpdate={(p) => onUpdate({ ...plan, phases: plan.phases.map(x => x.id === p.id ? p : x) })} />
                        ) : phase.type !== 'TIMER' && (
                            <div className="space-y-2">
                                {phase.milestones.map(m => (
                                    <MilestoneItem 
                                        key={m.id} 
                                        milestone={m} 
                                        type={phase.type}
                                        expanded={expandedMilestoneId === m.id}
                                        onExpand={() => setExpandedMilestoneId(expandedMilestoneId === m.id ? null : m.id)}
                                        onStatusChange={(s) => setSpecificStatus(phase.id, m.id, s)}
                                        onClick={() => setEditingMilestone({ pId: phase.id, m })}
                                    />
                                ))}
                            </div>
                        )}

                        {phase.type !== 'TIMER' && (
                            <button onClick={() => openNewMilestoneModal(phase.id, phase.type)} className="mt-4 w-full py-3 border border-dashed border-white/10 rounded-xl text-xs font-bold text-ios-textSec hover:text-white hover:bg-white/5 transition-colors flex items-center justify-center gap-2">
                                <Plus size={14} /> Add {phase.type === 'DATA_TABLE' ? 'Row' : 'Entry'}
                            </button>
                        )}
                    </div>
                </div>
            </div>
        )
    };

    // Helper Wrappers
    const getModuleIcon = (type: ModuleType) => { switch(type) { case 'TIMELINE': return <LayoutList size={16} className="text-purple-500"/>; case 'BUDGET': return <DollarSign size={16} className="text-green-500"/>; case 'TIMER': return <Timer size={16} className="text-red-500"/>; case 'DATA_TABLE': return <Database size={16} className="text-orange-500"/>; case 'TODO': return <CheckSquare size={16} className="text-blue-500"/>; default: return <StickyNote size={16} className="text-yellow-500"/>; } };
    const togglePhaseWidth = (id: string) => { const newPhases = plan.phases.map(p => p.id === id ? { ...p, width: p.width === 'full' ? 'half' as const : 'full' as const } : p); onUpdate({ ...plan, phases: newPhases }); };
    const setSpecificStatus = (phaseId: string, mId: string, status: 'todo' | 'doing' | 'done') => { const newPhases = plan.phases.map(p => { if (p.id === phaseId) { return { ...p, milestones: p.milestones.map(m => m.id === mId ? { ...m, status, isCompleted: status === 'done' } : m) }; } return p; }); onUpdate({ ...plan, phases: newPhases }); };
    const deletePhase = (pId: string) => onUpdate({ ...plan, phases: plan.phases.filter(p => p.id !== pId) });
    const handlePhaseSave = (p: PlanPhase) => { const newPhases = plan.phases.map(existing => existing.id === p.id ? p : existing); onUpdate({ ...plan, phases: newPhases }); setEditingPhase(null); };
    const handleMilestoneSave = (m: PlanMilestone) => { if (!editingMilestone) return; const newPhases = plan.phases.map(p => { if (p.id === editingMilestone.pId) { const exists = p.milestones.find(ex => ex.id === m.id); return { ...p, milestones: exists ? p.milestones.map(ex => ex.id === m.id ? m : ex) : [...p.milestones, m] }; } return p; }); onUpdate({ ...plan, phases: newPhases }); setEditingMilestone(null); };
    const openNewMilestoneModal = (pId: string, type: ModuleType) => { const newMilestone: PlanMilestone = { id: Math.random().toString(36).substr(2, 9), title: '', isCompleted: false, status: 'todo', cost: 0, paid: 0, tableRowData: type === 'DATA_TABLE' ? {} : undefined }; setEditingMilestone({ pId, m: newMilestone }); }
    
    // Layout Logic
    const renderLayout = () => {
        const elements: React.ReactElement[] = [];
        let i = 0; const phases = plan.phases || [];
        while (i < phases.length) {
            const phase = phases[i]; const isHalf = phase.width === 'half'; const nextPhase = phases[i + 1]; const isNextHalf = nextPhase && nextPhase.width === 'half';
            if (isHalf && isNextHalf) { elements.push(<div key={`row-${phase.id}`} className="flex flex-col md:flex-row gap-6 mb-6"><div className="flex-1 min-w-0">{renderPhaseCard(phase, i)}</div><div className="flex-1 min-w-0">{renderPhaseCard(nextPhase, i + 1)}</div></div>); i += 2; } else { elements.push(<div key={`single-${phase.id}`} className={`mb-6 ${isHalf ? 'md:w-1/2 md:pr-3' : 'w-full'}`}>{renderPhaseCard(phase, i)}</div>); i += 1; }
        }
        return elements;
    };

    return (
        <div className="flex-1 h-full overflow-y-auto no-scrollbar bg-black animate-in slide-in-from-right duration-300 relative">
            <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl border-b border-white/10 px-6 py-4 flex items-center justify-between shadow-lg">
                <button onClick={onBack} className="text-ios-purple flex items-center gap-1 font-bold active:scale-95 transition-transform"><ChevronLeft /> Dashboard</button>
                <div className="flex items-center gap-4"><button onClick={onDelete} className="p-2 text-ios-textSec hover:text-red-500 transition-colors"><Trash2 size={18} /></button></div>
            </div>
            <div className="p-6 pb-48 max-w-7xl mx-auto">
                <div className="mb-8 text-center"><h1 className="text-5xl md:text-7xl font-black text-white mb-4 tracking-tighter">{plan.title}</h1><p className="text-ios-textSec text-xl max-w-2xl mx-auto">{plan.description}</p></div>
                <TimeDilationUnit endDate={plan.endDate} />
                
                {/* TOOLBAR */}
                <div className="flex flex-col md:flex-row justify-between items-center mb-8 border-b border-white/10 pb-4 gap-4">
                    <h3 className="text-2xl font-bold text-white flex items-center gap-2"><Layers className="text-ios-blue" /> Construct Matrix</h3>
                    <div className="flex gap-2">
                        <button onClick={() => setShowTemplatePicker(true)} className="text-sm font-bold text-white bg-white/10 hover:bg-white/20 px-6 py-3 rounded-xl transition-all flex items-center gap-2">
                            <LayoutTemplate size={18} /> Templates
                        </button>
                        <button onClick={() => setShowModulePicker(true)} className="text-sm font-bold text-white bg-ios-purple hover:bg-ios-purple/80 px-6 py-3 rounded-xl transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(191,90,242,0.4)]">
                            <Plus size={18} /> Add Module
                        </button>
                    </div>
                </div>
                
                <div className="min-h-[500px]">{renderLayout()}</div>

                {/* FINISH BUTTON FIXED */}
                <div className="fixed bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black via-black/95 to-transparent z-[100] flex justify-center">
                    <button 
                        onClick={onFinish}
                        disabled={!isPlanComplete}
                        className={`
                            px-12 py-5 rounded-full font-black text-xl uppercase tracking-widest shadow-2xl transition-all duration-500 transform
                            ${isPlanComplete 
                                ? 'bg-gradient-to-r from-ios-yellow via-orange-500 to-red-500 text-white hover:scale-105 shadow-[0_0_60px_rgba(255,214,10,0.6)] animate-pulse' 
                                : 'bg-[#1C1C1E] text-white/20 border border-white/10 cursor-not-allowed grayscale'}
                        `}
                    >
                        {isPlanComplete ? 'Claim Legacy' : 'Objectives Pending'}
                    </button>
                </div>
            </div>

            {/* MODALS */}
            {showModulePicker && (<div className="fixed inset-0 z-[70] bg-black/80 backdrop-blur flex items-center justify-center p-6" onClick={() => setShowModulePicker(false)}><div className="bg-[#1C1C1E] w-full max-w-4xl rounded-3xl p-8 border border-white/10 animate-in zoom-in-95 shadow-2xl" onClick={e => e.stopPropagation()}><h2 className="text-3xl font-black text-white mb-8 text-center">Install Construct</h2><div className="grid grid-cols-2 md:grid-cols-3 gap-4"><ModuleOption icon={<LayoutList size={24} className="text-purple-500"/>} title="Timeline" desc="Tasks & Dates" onClick={() => initSetup('TIMELINE')} /><ModuleOption icon={<CheckSquare size={24} className="text-blue-500"/>} title="Todo Stream" desc="Quick Checklist" onClick={() => initSetup('TODO')} /><ModuleOption icon={<DollarSign size={24} className="text-green-500"/>} title="Budget" desc="Finance Tracker" onClick={() => initSetup('BUDGET')} /><ModuleOption icon={<Database size={24} className="text-orange-500"/>} title="Data Grid" desc="Spreadsheet" onClick={() => initSetup('DATA_TABLE')} /><ModuleOption icon={<Timer size={24} className="text-red-500"/>} title="Chronometer" desc="Stopwatch" onClick={() => initSetup('TIMER')} /><ModuleOption icon={<StickyNote size={24} className="text-yellow-500"/>} title="Note" desc="Text Block" onClick={() => initSetup('NOTE')} /></div></div></div>)}
            
            {showTemplatePicker && (
                <div className="fixed inset-0 z-[70] bg-black/80 backdrop-blur flex items-center justify-center p-6" onClick={() => setShowTemplatePicker(false)}>
                    <div className="bg-[#1C1C1E] w-full max-w-4xl rounded-3xl p-8 border border-white/10 animate-in zoom-in-95 shadow-2xl" onClick={e => e.stopPropagation()}>
                        <h2 className="text-3xl font-black text-white mb-8 text-center">Select Architecture</h2>
                        <div className="grid grid-cols-3 gap-4">
                            {['1: Genesis', '2: Titan', '3: Odyssey', '4: Scholar', '5: Monarch', '6: Architect', '7: Zenith', '8: Vortex', '9: Horizon'].map(t => (
                                <button key={t} onClick={() => handleApplyTemplate(t.split(':')[0])} className="bg-black/40 border border-white/10 hover:border-ios-purple rounded-xl p-6 text-center group hover:bg-white/5 transition-all">
                                    <h3 className="font-bold text-white text-lg group-hover:scale-110 transition-transform">{t}</h3>
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {setupModuleType && (<ModuleSetupModal type={setupModuleType} onClose={() => setSetupModuleType(null)} onConfirm={confirmNewModule} />)}
            {editingPhase && <PhaseEditorModal phase={editingPhase} onClose={() => setEditingPhase(null)} onSave={handlePhaseSave} planStart={plan.startDate} planEnd={plan.endDate} />}
            {editingMilestone && <MilestoneEditorModal milestone={editingMilestone.m} onClose={() => setEditingMilestone(null)} onSave={handleMilestoneSave} columns={plan.phases?.find(p => p.id === editingMilestone.pId)?.tableColumns} />}
        </div>
    )
}

// --- SUB-COMPONENTS ---

const TimerModule: React.FC<{ phase: PlanPhase }> = ({ phase }) => {
    const [time, setTime] = useState(0);
    const [isRunning, setIsRunning] = useState(false);
    const intervalRef = useRef<number | null>(null);

    const toggleTimer = () => {
        if(isRunning) {
            if(intervalRef.current) clearInterval(intervalRef.current);
            setIsRunning(false);
        } else {
            setIsRunning(true);
            intervalRef.current = window.setInterval(() => {
                setTime(t => t + 1);
            }, 1000);
        }
    }

    const resetTimer = () => {
        setIsRunning(false);
        setTime(0);
        if(intervalRef.current) clearInterval(intervalRef.current);
    }

    const format = (s: number) => {
        const min = Math.floor(s / 60);
        const sec = s % 60;
        return `${min.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    }

    return (
        <div className="flex flex-col items-center justify-center p-8 bg-black/40 rounded-2xl border border-white/5">
            <div className={`text-6xl font-mono font-black mb-6 ${isRunning ? 'text-white drop-shadow-[0_0_15px_white]' : 'text-white/50'}`}>
                {format(time)}
            </div>
            <div className="flex gap-4">
                <button onClick={toggleTimer} className={`w-16 h-16 rounded-full flex items-center justify-center text-xl transition-all ${isRunning ? 'bg-red-500 text-white' : 'bg-green-500 text-black'}`}>
                    {isRunning ? <Pause /> : <Play />}
                </button>
                <button onClick={resetTimer} className="w-16 h-16 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20">
                    <RotateCcw />
                </button>
            </div>
        </div>
    )
}

const DataTableModule: React.FC<{ phase: PlanPhase, onUpdate: (p: PlanPhase) => void }> = ({ phase, onUpdate }) => {
    const columns = phase.tableColumns || [];
    
    const addColumn = () => {
        const name = prompt("Column Name:");
        if (name) {
            onUpdate({
                ...phase,
                tableColumns: [...columns, { id: Math.random().toString(), name, type: 'text' }]
            });
        }
    };

    return (
        <div className="overflow-x-auto rounded-xl border border-white/10">
            <table className="w-full text-left text-sm">
                <thead className="bg-white/5 text-ios-textSec uppercase text-[10px]">
                    <tr>
                        {columns.map(c => <th key={c.id} className="p-3 border-b border-white/10">{c.name}</th>)}
                        <th className="p-3 border-b border-white/10 text-right"><button onClick={addColumn}>+ Col</button></th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                    {phase.milestones.map(row => (
                        <tr key={row.id}>
                            {columns.map(c => (
                                <td key={c.id} className="p-3 text-white/80">{row.tableRowData?.[c.id] || '-'}</td>
                            ))}
                            <td className="p-3"></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

const MilestoneItem: React.FC<{ 
    milestone: PlanMilestone, 
    type: ModuleType, 
    onStatusChange: (s: 'todo'|'doing'|'done') => void, 
    onClick: () => void,
    expanded: boolean,
    onExpand: () => void
}> = ({ milestone, type, onStatusChange, onClick, expanded, onExpand }) => {
    return (
        <div className="flex flex-col bg-white/5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors group overflow-hidden">
             <div className="flex items-center gap-3 p-3 cursor-pointer" onClick={onExpand}>
                 <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                     <button onClick={() => onStatusChange('todo')} className={`w-3 h-3 rounded-full border border-white/10 transition-all ${milestone.status === 'todo' ? 'bg-red-500 scale-125 shadow-[0_0_8px_red]' : 'bg-white/10 hover:bg-red-500/50'}`} title="To Do"/>
                     <button onClick={() => onStatusChange('doing')} className={`w-3 h-3 rounded-full border border-white/10 transition-all ${milestone.status === 'doing' ? 'bg-yellow-500 scale-125 shadow-[0_0_8px_yellow]' : 'bg-white/10 hover:bg-yellow-500/50'}`} title="In Progress"/>
                     <button onClick={() => onStatusChange('done')} className={`w-3 h-3 rounded-full border border-white/10 transition-all ${milestone.status === 'done' ? 'bg-green-500 scale-125 shadow-[0_0_8px_green]' : 'bg-white/10 hover:bg-green-500/50'}`} title="Done"/>
                 </div>
                 
                 <div className="flex-1 min-w-0 ml-2">
                     <div className="flex justify-between items-center">
                        <span className={`text-sm font-medium truncate ${milestone.status === 'done' ? 'text-white/30 line-through' : 'text-white'}`}>{milestone.title || 'Untitled'}</span>
                        {milestone.cost ? (<span className="text-xs font-mono text-white/70 bg-black/30 px-1 rounded">${milestone.paid || 0}/${milestone.cost}</span>) : null}
                     </div>
                 </div>
                 <div className="flex gap-2">
                     <button onClick={(e) => { e.stopPropagation(); onClick(); }} className="p-1 hover:bg-white/20 rounded"><Edit3 size={14}/></button>
                     <ChevronDown size={14} className={`text-white/30 transition-transform ${expanded ? 'rotate-180' : ''}`} />
                 </div>
             </div>
             
             {expanded && (
                 <div className="p-3 pt-0 text-xs text-ios-textSec border-t border-white/5 mt-1 animate-in slide-in-from-top-2">
                     {milestone.description ? <p className="mb-2">{milestone.description}</p> : <p className="italic opacity-50 mb-2">No description.</p>}
                     {milestone.attachments && milestone.attachments.length > 0 && (
                         <div className="flex gap-2 flex-wrap">
                             {milestone.attachments.map(a => (
                                 <span key={a.id} className="bg-black/30 px-2 py-1 rounded flex items-center gap-1 text-white/80 border border-white/5">
                                     {a.type === 'link' ? <Link size={10}/> : <File size={10}/>} {a.name}
                                 </span>
                             ))}
                         </div>
                     )}
                 </div>
             )}
        </div>
    )
}

// ... CreatePlanModal, MilestoneEditorModal, ModuleOption, ModuleSetupModal, PhaseEditorModal from previous response ...
// (These components remain largely the same, ensuring MilestoneEditorModal supports the new props)

const CreatePlanModal: React.FC<{ onClose: () => void, onSave: (p: Plan) => void }> = ({ onClose, onSave }) => {
    // ... (Same implementation as previous step)
    const [title, setTitle] = useState('');
    const [desc, setDesc] = useState('');
    const [cat, setCat] = useState<PlanCategory>('Physical');
    const [priority, setPriority] = useState<'High' | 'Medium' | 'Low'>('Medium');
    const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
    const [endDate, setEndDate] = useState(new Date(Date.now() + 86400000 * 30).toISOString().split('T')[0]);
    const [xp, setXp] = useState(1000);

    return (
        <div className="fixed inset-0 z-[80] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4">
            <div className="bg-[#1C1C1E] w-full max-w-lg rounded-3xl p-8 border border-white/10 shadow-2xl animate-in zoom-in-95 overflow-y-auto max-h-[90vh] no-scrollbar">
                <h2 className="text-3xl font-black text-white mb-8 text-center">Initialize Protocol</h2>
                <div className="space-y-6">
                    <div><label className="text-xs font-bold text-ios-textSec uppercase block mb-2">Mission Title</label><input autoFocus value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-black/50 text-white p-4 rounded-xl border border-white/10 outline-none focus:border-ios-purple transition-all text-lg font-bold" placeholder="e.g. Operation Apollo"/></div>
                    <div><label className="text-xs font-bold text-ios-textSec uppercase block mb-2">Briefing</label><textarea value={desc} onChange={e => setDesc(e.target.value)} className="w-full bg-black/50 text-white p-4 rounded-xl border border-white/10 outline-none focus:border-ios-purple transition-all h-24 resize-none" placeholder="Describe the objectives..."/></div>
                    <div className="grid grid-cols-2 gap-4"><div><label className="text-xs font-bold text-ios-textSec uppercase block mb-2">Start Date</label><input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="w-full bg-black/50 text-white p-3 rounded-xl border border-white/10 outline-none focus:border-ios-purple"/></div><div><label className="text-xs font-bold text-ios-textSec uppercase block mb-2">End Date</label><input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="w-full bg-black/50 text-white p-3 rounded-xl border border-white/10 outline-none focus:border-ios-purple"/></div></div>
                    <div><label className="text-xs font-bold text-ios-textSec uppercase block mb-2">XP Bounty</label><div className="flex items-center gap-4 bg-black/50 p-4 rounded-xl border border-white/10"><span className="text-2xl font-black text-ios-yellow min-w-[80px]">{xp} XP</span><input type="range" min="500" max="10000" step="500" value={xp} onChange={e => setXp(Number(e.target.value))} className="flex-1 accent-ios-yellow h-2 bg-white/20 rounded-lg appearance-none"/></div></div>
                    <div><label className="text-xs font-bold text-ios-textSec uppercase block mb-2">Sector</label><div className="flex flex-wrap gap-2">{(['Physical', 'Career', 'Financial', 'Lifestyle', 'Skill'] as PlanCategory[]).map(c => (<button key={c} onClick={() => setCat(c)} className={`text-xs font-bold px-4 py-2 rounded-full border transition-all ${cat === c ? 'bg-ios-purple border-ios-purple text-white' : 'bg-white/5 border-white/10 text-ios-textSec hover:text-white'}`}>{c}</button>))}</div></div>
                    <div><label className="text-xs font-bold text-ios-textSec uppercase block mb-2">Priority</label><div className="grid grid-cols-3 gap-3"><button onClick={() => setPriority('High')} className={`p-3 rounded-xl border text-xs font-bold uppercase ${priority === 'High' ? 'bg-red-500/20 border-red-500 text-red-500' : 'bg-white/5 border-white/10 text-ios-textSec'}`}>High</button><button onClick={() => setPriority('Medium')} className={`p-3 rounded-xl border text-xs font-bold uppercase ${priority === 'Medium' ? 'bg-yellow-500/20 border-yellow-500 text-yellow-500' : 'bg-white/5 border-white/10 text-ios-textSec'}`}>Medium</button><button onClick={() => setPriority('Low')} className={`p-3 rounded-xl border text-xs font-bold uppercase ${priority === 'Low' ? 'bg-blue-500/20 border-blue-500 text-blue-500' : 'bg-white/5 border-white/10 text-ios-textSec'}`}>Low</button></div></div>
                </div>
                <div className="flex gap-3 mt-10"><button onClick={onClose} className="flex-1 py-4 text-white/50 hover:text-white transition-colors font-bold">Cancel</button><button onClick={() => { if(title) onSave({ id: Math.random().toString(), title, description: desc, category: cat, status: 'Active', createdAt: new Date().toISOString(), xpReward: xp, phases: [], startDate, endDate, priority }); }} className="flex-1 bg-white text-black font-black text-lg py-4 rounded-2xl hover:scale-105 transition-transform shadow-xl">Launch</button></div>
            </div>
        </div>
    )
}

const MilestoneEditorModal: React.FC<{ 
    milestone: PlanMilestone, 
    onClose: () => void, 
    onSave: (m: PlanMilestone) => void,
    columns?: TableColumn[]
}> = ({ milestone, onClose, onSave, columns }) => {
    const [title, setTitle] = useState(milestone.title);
    const [desc, setDesc] = useState(milestone.description || '');
    const [status, setStatus] = useState(milestone.status);
    const [cost, setCost] = useState(milestone.cost || 0);
    const [paid, setPaid] = useState(milestone.paid || 0);
    const [attachments, setAttachments] = useState<Attachment[]>(milestone.attachments || []);
    const [activeTab, setActiveTab] = useState<'DETAILS'|'BUDGET'|'FILES'>('DETAILS');
    const [rowData, setRowData] = useState<Record<string, string>>(milestone.tableRowData || {});

    const updateRowData = (colId: string, val: string) => setRowData(prev => ({ ...prev, [colId]: val }));

    const handleSave = () => {
        onSave({
            ...milestone,
            title,
            description: desc,
            status,
            isCompleted: status === 'done',
            cost,
            paid,
            attachments,
            tableRowData: Object.keys(rowData).length > 0 ? rowData : undefined
        });
    }

    return (
        <div className="fixed inset-0 z-[90] bg-black/80 backdrop-blur flex items-center justify-center p-4">
             <div className="bg-[#1C1C1E] w-full max-w-md rounded-2xl border border-white/10 shadow-2xl animate-in zoom-in-95 flex flex-col max-h-[80vh]">
                 <div className="flex justify-between items-center p-6 border-b border-white/5">
                     <h3 className="text-xl font-bold text-white">Edit Entry</h3>
                     <button onClick={onClose}><X className="text-ios-textSec" /></button>
                 </div>
                 
                 <div className="flex border-b border-white/5 px-6">
                     <button onClick={() => setActiveTab('DETAILS')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider ${activeTab === 'DETAILS' ? 'text-ios-purple border-b-2 border-ios-purple' : 'text-ios-textSec'}`}>Details</button>
                     <button onClick={() => setActiveTab('BUDGET')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider ${activeTab === 'BUDGET' ? 'text-ios-purple border-b-2 border-ios-purple' : 'text-ios-textSec'}`}>Budget</button>
                     <button onClick={() => setActiveTab('FILES')} className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider ${activeTab === 'FILES' ? 'text-ios-purple border-b-2 border-ios-purple' : 'text-ios-textSec'}`}>Files</button>
                 </div>

                 <div className="p-6 overflow-y-auto custom-scrollbar flex-1 space-y-4">
                     {activeTab === 'DETAILS' && (
                         <>
                            <div><label className="text-xs font-bold text-ios-textSec uppercase">Title</label><input value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1"/></div>
                            <div><label className="text-xs font-bold text-ios-textSec uppercase">Description</label><textarea value={desc} onChange={e => setDesc(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1 h-20 resize-none"/></div>
                            <div>
                                <label className="text-xs font-bold text-ios-textSec uppercase mb-2 block">Status</label>
                                <div className="flex gap-2">
                                    <button onClick={() => setStatus('todo')} className={`flex-1 py-3 rounded-lg border flex items-center justify-center gap-2 font-bold ${status === 'todo' ? 'bg-red-500/20 border-red-500 text-red-500' : 'border-white/10 bg-white/5'}`}><Circle size={14}/> To Do</button>
                                    <button onClick={() => setStatus('doing')} className={`flex-1 py-3 rounded-lg border flex items-center justify-center gap-2 font-bold ${status === 'doing' ? 'bg-yellow-500/20 border-yellow-500 text-yellow-500' : 'border-white/10 bg-white/5'}`}><Activity size={14}/> Doing</button>
                                    <button onClick={() => setStatus('done')} className={`flex-1 py-3 rounded-lg border flex items-center justify-center gap-2 font-bold ${status === 'done' ? 'bg-green-500/20 border-green-500 text-green-500' : 'border-white/10 bg-white/5'}`}><CheckCircle2 size={14}/> Done</button>
                                </div>
                            </div>
                            {columns && (
                                <div className="space-y-3 pt-4 border-t border-white/10">
                                    <h4 className="text-xs font-bold text-white uppercase">Data Fields</h4>
                                    {columns.map(col => (
                                        <div key={col.id}>
                                            <label className="text-[10px] font-bold text-ios-textSec uppercase">{col.name}</label>
                                            <input value={rowData[col.id] || ''} onChange={e => updateRowData(col.id, e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-2 text-sm text-white mt-1" />
                                        </div>
                                    ))}
                                </div>
                            )}
                         </>
                     )}

                     {activeTab === 'BUDGET' && (
                         <div className="space-y-6 text-center">
                             <div className="bg-gradient-to-br from-green-500/10 to-transparent p-6 rounded-2xl border border-green-500/20">
                                 <DollarSign size={40} className="text-green-500 mx-auto mb-4" />
                                 <p className="text-sm text-white/70 mb-4">Allocate budget for this specific task. This will automatically sync with the Master Budget Module.</p>
                                 <div className="grid grid-cols-2 gap-4 text-left">
                                     <div><label className="text-xs font-bold text-green-400 uppercase">Allocated Cost</label><input type="number" value={cost} onChange={e => setCost(Number(e.target.value))} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1"/></div>
                                     <div><label className="text-xs font-bold text-green-400 uppercase">Amount Paid</label><input type="number" value={paid} onChange={e => setPaid(Number(e.target.value))} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1"/></div>
                                 </div>
                             </div>
                         </div>
                     )}

                     {activeTab === 'FILES' && (
                         <div className="space-y-4">
                             <div className="grid grid-cols-4 gap-2">
                                 <button onClick={() => setAttachments([...attachments, {id:Date.now().toString(), type:'image', name:'Img', content:''}])} className="aspect-square bg-white/5 rounded-xl flex flex-col items-center justify-center hover:bg-white/10"><ImageIcon size={20} className="mb-1"/><span className="text-[10px]">Img</span></button>
                                 <button onClick={() => setAttachments([...attachments, {id:Date.now().toString(), type:'link', name:'Link', content:''}])} className="aspect-square bg-white/5 rounded-xl flex flex-col items-center justify-center hover:bg-white/10"><Link size={20} className="mb-1"/><span className="text-[10px]">Link</span></button>
                                 <button onClick={() => setAttachments([...attachments, {id:Date.now().toString(), type:'file', name:'Doc', content:''}])} className="aspect-square bg-white/5 rounded-xl flex flex-col items-center justify-center hover:bg-white/10"><Paperclip size={20} className="mb-1"/><span className="text-[10px]">Doc</span></button>
                                 <button onClick={() => setAttachments([...attachments, {id:Date.now().toString(), type:'voice', name:'Voice', content:''}])} className="aspect-square bg-white/5 rounded-xl flex flex-col items-center justify-center hover:bg-white/10"><Mic size={20} className="mb-1"/><span className="text-[10px]">Voice</span></button>
                             </div>
                             <div className="space-y-2">
                                 {attachments.map((a, i) => (
                                     <div key={i} className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/5">
                                         <div className="flex items-center gap-2">
                                             <div className="w-8 h-8 bg-black rounded flex items-center justify-center text-white/50">{a.type === 'image' ? <ImageIcon size={14}/> : <Link size={14}/>}</div>
                                             <input value={a.name} onChange={e => {const n = [...attachments]; n[i].name = e.target.value; setAttachments(n)}} className="bg-transparent text-sm text-white outline-none"/>
                                         </div>
                                         <button onClick={() => setAttachments(attachments.filter((_, idx) => idx !== i))}><X size={14} className="text-white/30 hover:text-red-500"/></button>
                                     </div>
                                 ))}
                             </div>
                         </div>
                     )}
                 </div>

                 <div className="p-6 pt-0">
                    <button onClick={handleSave} className="w-full bg-white text-black font-bold rounded-xl py-4 hover:scale-105 transition-transform shadow-lg">Save Changes</button>
                 </div>
             </div>
        </div>
    )
}

const ModuleOption: React.FC<{ icon: React.ReactNode, title: string, desc: string, onClick: () => void }> = ({ icon, title, desc, onClick }) => (
    <button onClick={onClick} className="flex flex-col items-center justify-center gap-3 bg-black/40 border border-white/10 hover:border-ios-purple hover:bg-white/5 rounded-2xl p-6 transition-all group">
        <div className="p-3 bg-white/5 rounded-full group-hover:scale-110 transition-transform">{icon}</div>
        <div className="text-center">
            <h3 className="font-bold text-white mb-1">{title}</h3>
            <p className="text-xs text-ios-textSec">{desc}</p>
        </div>
    </button>
)

const ModuleSetupModal: React.FC<{ type: ModuleType, onClose: () => void, onConfirm: (config: { title: string, budgetLimit?: number, desc?: string }) => void }> = ({ type, onClose, onConfirm }) => {
    const [title, setTitle] = useState('');
    const [desc, setDesc] = useState('');
    const [budget, setBudget] = useState(1000);

    return (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur flex items-center justify-center p-4">
            <div className="bg-[#1C1C1E] w-full max-w-md rounded-2xl border border-white/10 p-6 animate-in zoom-in-95 shadow-2xl">
                 <h2 className="text-xl font-bold text-white mb-6">Configure {type}</h2>
                 <div className="space-y-4">
                     <div><label className="text-xs font-bold text-ios-textSec uppercase">Title</label><input autoFocus value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1" placeholder="Module Name"/></div>
                     <div><label className="text-xs font-bold text-ios-textSec uppercase">Description</label><input value={desc} onChange={e => setDesc(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1" placeholder="Optional context..."/></div>
                     {type === 'BUDGET' && (
                         <div><label className="text-xs font-bold text-ios-textSec uppercase">Budget Limit</label><input type="number" value={budget} onChange={e => setBudget(Number(e.target.value))} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1"/></div>
                     )}
                 </div>
                 <div className="flex gap-3 mt-6">
                     <button onClick={onClose} className="flex-1 py-3 text-ios-textSec hover:text-white font-bold">Cancel</button>
                     <button onClick={() => { if(title) onConfirm({ title, desc, budgetLimit: type==='BUDGET' ? budget : undefined }) }} className="flex-1 bg-white text-black font-bold rounded-xl py-3 hover:scale-105 transition-transform">Create</button>
                 </div>
            </div>
        </div>
    )
}

const PhaseEditorModal: React.FC<{ phase: PlanPhase, onClose: () => void, onSave: (p: PlanPhase) => void, planStart: string, planEnd: string }> = ({ phase, onClose, onSave, planStart, planEnd }) => {
    const [title, setTitle] = useState(phase.title);
    const [start, setStart] = useState(phase.startDate);
    const [end, setEnd] = useState(phase.endDate);
    const [color, setColor] = useState(phase.color);

    return (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur flex items-center justify-center p-4">
            <div className="bg-[#1C1C1E] w-full max-w-md rounded-2xl border border-white/10 p-6 animate-in zoom-in-95 shadow-2xl">
                 <h2 className="text-xl font-bold text-white mb-6">Edit Module</h2>
                 <div className="space-y-4">
                     <div><label className="text-xs font-bold text-ios-textSec uppercase">Title</label><input value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1"/></div>
                     <div className="grid grid-cols-2 gap-4">
                         <div><label className="text-xs font-bold text-ios-textSec uppercase">Start</label><input type="date" value={start} min={planStart} max={planEnd} onChange={e => setStart(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1"/></div>
                         <div><label className="text-xs font-bold text-ios-textSec uppercase">End</label><input type="date" value={end} min={planStart} max={planEnd} onChange={e => setEnd(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white mt-1"/></div>
                     </div>
                     <div>
                         <label className="text-xs font-bold text-ios-textSec uppercase mb-2 block">Color Theme</label>
                         <div className="flex gap-2">
                             {['#BF5AF2', '#30D158', '#0A84FF', '#FF9F0A', '#FF375F', '#FFD60A'].map(c => (
                                 <button key={c} onClick={() => setColor(c)} className={`w-8 h-8 rounded-full border-2 ${color === c ? 'border-white scale-110' : 'border-transparent'}`} style={{backgroundColor: c}} />
                             ))}
                         </div>
                     </div>
                 </div>
                 <div className="flex gap-3 mt-6">
                     <button onClick={onClose} className="flex-1 py-3 text-ios-textSec hover:text-white font-bold">Cancel</button>
                     <button onClick={() => onSave({...phase, title, startDate: start, endDate: end, color})} className="flex-1 bg-white text-black font-bold rounded-xl py-3 hover:scale-105 transition-transform">Save</button>
                 </div>
            </div>
        </div>
    )
}
