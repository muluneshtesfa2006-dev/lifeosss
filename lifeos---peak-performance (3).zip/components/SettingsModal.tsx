
import React, { useState, useEffect } from 'react';
import { X, User, Save, Shield, Database, Bell, Settings } from 'lucide-react';
import { StorageService } from '../services/storageService';
import { UserIdentity } from '../types';

interface SettingsModalProps {
    onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
    const [user, setUser] = useState<UserIdentity | null>(null);
    const [name, setName] = useState('');
    const [goal, setGoal] = useState('');
    const [birthDate, setBirthDate] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const u = StorageService.getUser();
        setUser(u);
        if (u) {
            setName(u.name);
            setGoal(u.mainGoal);
            setBirthDate(u.birthDate || '');
        }
    }, []);

    const handleSave = () => {
        if (!user) return;
        setIsLoading(true);
        const age = new Date().getFullYear() - new Date(birthDate).getFullYear();
        const updatedUser = { ...user, name, mainGoal: goal, birthDate, age: age.toString() };
        StorageService.saveUser(updatedUser);
        setTimeout(() => {
            setIsLoading(false);
            onClose();
            window.location.reload(); // Simple reload to refresh context
        }, 800);
    };

    return (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-6 animate-in fade-in duration-200">
            <div className="bg-[#050505] w-full max-w-2xl rounded-3xl border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className="flex justify-between items-center p-6 border-b border-white/5 bg-[#0A0A0A]">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-ios-purple/10 flex items-center justify-center text-ios-purple border border-ios-purple/20">
                            <Settings size={20} />
                        </div>
                        <h2 className="text-xl font-bold text-white">System Configuration</h2>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full text-white/50 hover:text-white transition-colors">
                        <X size={20} />
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
                    
                    {/* PROFILE SECTION */}
                    <div className="space-y-4">
                        <h3 className="text-xs font-bold text-ios-textSec uppercase tracking-widest flex items-center gap-2">
                            <User size={14}/> Neural Profile
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-xs font-bold text-white/40 mb-2">Callsign</label>
                                <input 
                                    value={name}
                                    onChange={e => setName(e.target.value)}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-ios-purple outline-none transition-colors"
                                />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-white/40 mb-2">Origin Date</label>
                                <input 
                                    type="date"
                                    value={birthDate}
                                    onChange={e => setBirthDate(e.target.value)}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-ios-purple outline-none transition-colors"
                                />
                            </div>
                            <div className="md:col-span-2">
                                <label className="block text-xs font-bold text-white/40 mb-2">Prime Directive (North Star)</label>
                                <input 
                                    value={goal}
                                    onChange={e => setGoal(e.target.value)}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-ios-purple outline-none transition-colors"
                                />
                            </div>
                        </div>
                    </div>

                    {/* DATA SECTION */}
                    <div className="space-y-4 pt-6 border-t border-white/5">
                        <h3 className="text-xs font-bold text-ios-textSec uppercase tracking-widest flex items-center gap-2">
                            <Database size={14}/> Data Sovereignty
                        </h3>
                        <div className="bg-white/5 rounded-2xl p-4 border border-white/5 flex items-center justify-between">
                            <div>
                                <h4 className="text-white font-bold text-sm">Local Storage</h4>
                                <p className="text-xs text-white/40 mt-1">Your data resides on this device.</p>
                            </div>
                            <button className="text-xs font-bold text-ios-purple border border-ios-purple/30 px-3 py-1.5 rounded-lg hover:bg-ios-purple/10">Export JSON</button>
                        </div>
                    </div>

                    <div className="space-y-4 pt-6 border-t border-white/5">
                        <h3 className="text-xs font-bold text-ios-textSec uppercase tracking-widest flex items-center gap-2">
                            <Shield size={14}/> Security
                        </h3>
                        <button className="w-full text-left bg-white/5 rounded-2xl p-4 border border-white/5 hover:border-white/10 transition-colors flex justify-between items-center group">
                            <div>
                                <h4 className="text-white font-bold text-sm group-hover:text-ios-purple transition-colors">Reset Access Key</h4>
                                <p className="text-xs text-white/40 mt-1">Change your local password.</p>
                            </div>
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                        </button>
                    </div>

                </div>

                <div className="p-6 border-t border-white/5 bg-[#0A0A0A] flex justify-end gap-3">
                    <button onClick={onClose} className="px-6 py-3 rounded-xl text-xs font-bold text-white/50 hover:text-white transition-colors">Cancel</button>
                    <button 
                        onClick={handleSave}
                        disabled={isLoading}
                        className="px-8 py-3 bg-white text-black rounded-xl text-xs font-bold uppercase tracking-widest hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
                    >
                        {isLoading ? 'Saving...' : <>Save Changes <Save size={14}/></>}
                    </button>
                </div>
            </div>
        </div>
    );
};
