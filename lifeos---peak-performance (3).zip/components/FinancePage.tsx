
import React from 'react';
import { 
    Search, MoreHorizontal, Zap, Users, ShoppingCart, Activity,
    ChevronDown, Mail, Phone, TrendingUp, LayoutGrid, BarChart3,
    Briefcase, DollarSign
} from 'lucide-react';
import { 
    ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, Tooltip
} from 'recharts';

// --- MOCK DATA TO MATCH REFERENCE IMAGE ---
const REVENUE_DATA = [
    { name: 'M', value: 4000 },
    { name: 'T', value: 3000 },
    { name: 'W', value: 5000 },
    { name: 'T', value: 2780 },
    { name: 'F', value: 1890 },
    { name: 'S', value: 2390 },
    { name: 'S', value: 3490 },
];

const DONUT_DATA = [
    { name: 'Electronic', value: 45, color: '#bef264' }, // Lime
    { name: 'Fashion', value: 25, color: '#ffffff' },    // White
    { name: 'Decor', value: 20, color: '#525252' },      // Gray
    { name: 'Sports', value: 10, color: '#262626' },     // Dark Gray
];

const TRANSACTIONS = [
    { id: 1, name: 'Danny Liu', email: 'danny@gmail.com', deals: 1023, value: '$37,431', img: 'https://i.pravatar.cc/150?u=1' },
    { id: 2, name: 'Bella Deviant', email: 'bella@gmail.com', deals: 963, value: '$30,423', img: 'https://i.pravatar.cc/150?u=2' },
    { id: 3, name: 'Darrell Steward', email: 'darrell@gmail.com', deals: 843, value: '$28,549', img: 'https://i.pravatar.cc/150?u=3' },
    { id: 4, name: 'Guy Hawkins', email: 'guy@gmail.com', deals: 721, value: '$24,100', img: 'https://i.pravatar.cc/150?u=4' },
];

const NOTIFICATIONS = [
    { title: 'New users registered', time: 'Just now', icon: Users, color: 'text-lime-400', count: 56 },
    { title: 'Orders placed', time: '59 minutes ago', icon: ShoppingCart, color: 'text-white', count: 132 },
    { title: 'Funds withdrawn', time: '12 Hours ago', icon: DollarSign, color: 'text-white', count: null },
    { title: 'Unread messages', time: 'Today, 11:59 AM', icon: Mail, color: 'text-white', count: 5 }
];

const ACTIVITIES = [
    { title: 'Changed the style', time: 'Just now', user: 'https://i.pravatar.cc/150?u=8' },
    { title: '177 New products added', time: '47 Minutes ago', user: 'https://i.pravatar.cc/150?u=9' },
    { title: '11 Products archived', time: '1 Day ago', user: 'https://i.pravatar.cc/150?u=10' },
    { title: 'Page "Toys" has been removed', time: 'Feb 2, 2024', user: 'https://i.pravatar.cc/150?u=11' },
];

const CONTACTS = [
    { name: 'Daniel Craig', active: false, img: 'https://i.pravatar.cc/150?u=20' },
    { name: 'Kate Morrison', active: false, img: 'https://i.pravatar.cc/150?u=21' },
    { name: 'Nataniel Donovan', active: true, img: 'https://i.pravatar.cc/150?u=22' },
    { name: 'Elisabeth Wayne', active: false, img: 'https://i.pravatar.cc/150?u=23' },
    { name: 'Felicia Raspet', active: false, img: 'https://i.pravatar.cc/150?u=24' },
];

export const FinancePage: React.FC = () => {
    return (
        <div className="flex h-full w-full bg-[#09090b] text-white font-sans overflow-hidden">
            
            {/* MAIN CONTENT AREA */}
            <div className="flex-1 flex flex-col h-full overflow-hidden relative">
                
                {/* TOP BAR */}
                <header className="h-20 px-8 flex items-center justify-between border-b border-white/5 shrink-0 bg-[#09090b] z-20">
                    <div className="flex items-center gap-4 text-sm font-medium text-zinc-400">
                        <LayoutGrid size={18} className="text-white"/>
                        <span>Dashboards</span>
                        <span className="text-zinc-600">/</span>
                        <span className="text-white">Overview</span>
                    </div>
                    <div className="flex items-center gap-6">
                        <div className="relative group">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500 group-focus-within:text-white transition-colors" size={16}/>
                            <input 
                                className="bg-[#18181b] border border-white/5 rounded-full py-2.5 pl-10 pr-4 text-sm text-white placeholder-zinc-600 w-64 focus:outline-none focus:border-white/10 transition-colors"
                                placeholder="Search..."
                            />
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 flex gap-1">
                                <span className="text-[10px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded border border-white/5 font-bold">⌘K</span>
                            </div>
                        </div>
                    </div>
                </header>

                {/* SCROLLABLE DASHBOARD CONTENT */}
                <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                    <div className="max-w-7xl mx-auto space-y-6">
                        
                        {/* TITLE ROW */}
                        <div className="flex justify-between items-end mb-2">
                            <h1 className="text-3xl font-bold tracking-tight text-white">Overview</h1>
                            <div className="flex items-center gap-2 text-sm text-zinc-400 hover:text-white cursor-pointer transition-colors">
                                <span>Today</span>
                                <ChevronDown size={16}/>
                            </div>
                        </div>

                        {/* KPI ROW */}
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            {/* NET REVENUE */}
                            <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex flex-col justify-between h-40 group hover:border-lime-400/20 transition-colors">
                                <div>
                                    <div className="text-zinc-400 text-xs font-bold uppercase tracking-wider mb-2">Net revenue</div>
                                    <div className="text-3xl font-black text-white tracking-tight">$3,131,021</div>
                                </div>
                                <div className="flex items-center gap-2 text-lime-400 text-xs font-bold">
                                    <TrendingUp size={14}/> 0.4% vs last month
                                </div>
                            </div>

                            {/* ARR */}
                            <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex flex-col justify-between h-40 group hover:border-lime-400/20 transition-colors">
                                <div>
                                    <div className="text-zinc-400 text-xs font-bold uppercase tracking-wider mb-2">Monthly Inflow</div>
                                    <div className="text-3xl font-black text-white tracking-tight">$1,511,121</div>
                                </div>
                                <div className="flex items-center gap-2 text-lime-400 text-xs font-bold">
                                    <TrendingUp size={14}/> 32% vs last quarter
                                </div>
                            </div>

                            {/* GAUGE GOAL */}
                            <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex items-center justify-between h-40 relative group hover:border-lime-400/20 transition-colors">
                                <div className="flex flex-col justify-between h-full">
                                    <div className="text-zinc-400 text-xs font-bold uppercase tracking-wider">Quarterly Goal</div>
                                    <div>
                                        <div className="text-3xl font-black text-white tracking-tight">71%</div>
                                        <div className="text-zinc-500 text-[10px] uppercase tracking-widest mt-1">Goal: $1.1M</div>
                                    </div>
                                </div>
                                <div className="relative w-24 h-24 flex items-center justify-center">
                                    <svg className="w-full h-full transform -rotate-90">
                                        <circle cx="48" cy="48" r="36" stroke="#27272a" strokeWidth="8" fill="none"/>
                                        <circle cx="48" cy="48" r="36" stroke="#bef264" strokeWidth="8" fill="none" strokeDasharray="226" strokeDashoffset="65" strokeLinecap="round"/>
                                    </svg>
                                    <div className="absolute inset-0 flex items-center justify-center">
                                        <div className="w-1 h-8 bg-zinc-700 rounded-full transform rotate-[45deg] origin-bottom translate-y-[-50%]"></div>
                                    </div>
                                </div>
                            </div>

                            {/* NEW ORDERS */}
                            <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex flex-col justify-between h-40 group hover:border-lime-400/20 transition-colors">
                                <div>
                                    <div className="text-zinc-400 text-xs font-bold uppercase tracking-wider mb-2">Transactions</div>
                                    <div className="text-3xl font-black text-white tracking-tight">18,221</div>
                                </div>
                                <div className="flex items-center gap-2 text-lime-400 text-xs font-bold">
                                    <TrendingUp size={14}/> 11% vs last quarter
                                </div>
                            </div>
                        </div>

                        {/* MIDDLE ROW */}
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                            
                            {/* SALES OVERVIEW (DONUT) */}
                            <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex flex-col relative min-h-[320px]">
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="font-bold text-white text-lg">Sales Overview</h3>
                                    <MoreHorizontal size={20} className="text-zinc-500 cursor-pointer hover:text-white"/>
                                </div>
                                
                                <div className="flex-1 flex flex-col items-center justify-center relative">
                                    <div className="w-48 h-48 relative">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <PieChart>
                                                <Pie 
                                                    data={DONUT_DATA} 
                                                    innerRadius={60} 
                                                    outerRadius={80} 
                                                    paddingAngle={0} 
                                                    dataKey="value"
                                                    stroke="none"
                                                >
                                                    {DONUT_DATA.map((entry, index) => (
                                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                                    ))}
                                                </Pie>
                                            </PieChart>
                                        </ResponsiveContainer>
                                        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                                            <span className="text-3xl font-black text-white">102k</span>
                                            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Weekly Visits</span>
                                        </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-2 gap-x-8 gap-y-3 mt-6 w-full px-4">
                                        {DONUT_DATA.map(d => (
                                            <div key={d.name} className="flex items-center gap-2">
                                                <div className="w-2 h-2 rounded-full" style={{backgroundColor: d.color}}></div>
                                                <div className="flex flex-col">
                                                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wide">{d.name}</span>
                                                    <span className="text-sm font-bold text-white">${(d.value * 1240).toLocaleString()}</span>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            {/* RIGHT COLUMN OF MIDDLE ROW */}
                            <div className="lg:col-span-2 flex flex-col gap-4">
                                {/* Small Cards Row */}
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex flex-col justify-between h-40 relative group">
                                        <div className="absolute top-4 right-4 bg-[#27272a] p-2 rounded-full text-lime-400"><Briefcase size={16}/></div>
                                        <div className="text-zinc-400 text-xs font-bold uppercase tracking-wider">New Customers</div>
                                        <div className="text-3xl font-black text-white">862 <span className="text-xs font-medium text-zinc-500 ml-2">-8%</span></div>
                                        <div className="text-[10px] text-zinc-600 font-medium">Last Week</div>
                                    </div>
                                    <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex flex-col justify-between h-40 relative group">
                                        <div className="absolute top-4 right-4 bg-[#27272a] p-2 rounded-full text-lime-400"><BarChart3 size={16}/></div>
                                        <div className="text-zinc-400 text-xs font-bold uppercase tracking-wider">Total Profit</div>
                                        <div className="text-3xl font-black text-white">$25.6k <span className="text-xs font-medium text-zinc-500 ml-2">+42%</span></div>
                                        <div className="text-[10px] text-zinc-600 font-medium">Weekly Profit</div>
                                    </div>
                                </div>

                                {/* Total Profit Chart */}
                                <div className="bg-[#18181b] p-6 rounded-[2rem] border border-white/5 flex-1 relative overflow-hidden flex flex-col justify-between min-h-[180px]">
                                    <div className="relative z-10">
                                        <div className="text-zinc-400 text-xs font-bold uppercase tracking-wider mb-1">Total Profit</div>
                                        <div className="text-4xl font-black text-white tracking-tighter">$136,755.77</div>
                                    </div>
                                    <div className="absolute bottom-0 left-0 right-0 h-32 w-full">
                                        <ResponsiveContainer width="100%" height="100%">
                                            <AreaChart data={REVENUE_DATA}>
                                                <defs>
                                                    <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                                                        <stop offset="5%" stopColor="#bef264" stopOpacity={0.3}/>
                                                        <stop offset="95%" stopColor="#bef264" stopOpacity={0}/>
                                                    </linearGradient>
                                                </defs>
                                                <Area type="monotone" dataKey="value" stroke="#bef264" strokeWidth={3} fill="url(#colorProfit)" />
                                            </AreaChart>
                                        </ResponsiveContainer>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* BOTTOM ROW */}
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                            
                            {/* CUSTOMER LIST */}
                            <div className="lg:col-span-2 bg-[#18181b] rounded-[2rem] border border-white/5 p-6">
                                <div className="flex justify-between items-center mb-6">
                                    <h3 className="font-bold text-white text-lg">Customer List</h3>
                                    <MoreHorizontal size={20} className="text-zinc-500 cursor-pointer hover:text-white"/>
                                </div>
                                <div className="space-y-4">
                                    <div className="grid grid-cols-12 text-[10px] font-bold text-zinc-500 uppercase tracking-wider pb-2 border-b border-white/5">
                                        <div className="col-span-6 pl-2">Name</div>
                                        <div className="col-span-3">Deals</div>
                                        <div className="col-span-3 text-right pr-2">Total Deal Value</div>
                                    </div>
                                    {TRANSACTIONS.map(tx => (
                                        <div key={tx.id} className="grid grid-cols-12 items-center group p-2 hover:bg-white/5 rounded-xl transition-colors cursor-pointer">
                                            <div className="col-span-6 flex items-center gap-3">
                                                <img src={tx.img} alt={tx.name} className="w-8 h-8 rounded-full bg-zinc-800 object-cover"/>
                                                <div>
                                                    <div className="font-bold text-white text-sm group-hover:text-lime-400 transition-colors">{tx.name}</div>
                                                    <div className="text-[10px] text-zinc-500">{tx.email}</div>
                                                </div>
                                            </div>
                                            <div className="col-span-3 text-white font-medium text-sm">{tx.deals}</div>
                                            <div className="col-span-3 text-right text-white font-bold text-sm">{tx.value}</div>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            {/* PREMIUM PLAN CARD */}
                            <div className="bg-gradient-to-br from-[#14532d] to-[#000000] rounded-[2rem] p-8 relative overflow-hidden flex flex-col justify-between border border-lime-900/30 min-h-[300px] group">
                                <div className="relative z-10">
                                    <div className="flex justify-between items-start mb-6">
                                        <span className="bg-lime-400/20 text-lime-400 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border border-lime-400/20 flex items-center gap-1 backdrop-blur-md">
                                            <Zap size={10} fill="currentColor"/> Premium Plan
                                        </span>
                                        <MoreHorizontal size={16} className="text-white/30 hover:text-white cursor-pointer"/>
                                    </div>
                                    <div className="flex items-baseline gap-1 mb-2">
                                        <span className="text-5xl font-black text-white tracking-tighter">$30</span>
                                        <span className="text-zinc-400 text-sm font-medium">/ month</span>
                                    </div>
                                    <div className="text-zinc-400 text-sm font-medium mb-1">Per User</div>
                                    <p className="text-lime-100/60 text-xs leading-relaxed mt-4 mb-8">
                                        Improve your workplace, view and analyze your profits and losses.
                                    </p>
                                </div>
                                <button className="relative z-10 w-full py-4 bg-lime-400 hover:bg-lime-300 text-black font-black text-sm uppercase tracking-widest rounded-xl transition-all shadow-[0_0_20px_rgba(163,230,53,0.3)] hover:shadow-[0_0_30px_rgba(163,230,53,0.5)]">
                                    Get Started
                                </button>
                                
                                {/* Background Patterns */}
                                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 mix-blend-overlay"></div>
                                <div className="absolute top-[-20%] right-[-20%] w-64 h-64 bg-lime-500/20 rounded-full blur-[80px]"></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            {/* RIGHT SIDEBAR - FIXED */}
            <div className="w-80 bg-[#09090b] border-l border-white/5 flex flex-col p-6 hidden xl:flex shrink-0 overflow-y-auto custom-scrollbar">
                
                {/* NOTIFICATIONS */}
                <div className="mb-10">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-white text-lg font-bold">Notifications</h3>
                    </div>
                    <div className="space-y-6 relative">
                        {/* Timeline Line */}
                        <div className="absolute left-[11px] top-2 bottom-2 w-px bg-zinc-800"></div>
                        
                        {NOTIFICATIONS.map((n, i) => (
                            <div key={i} className="flex gap-4 relative z-10 group cursor-pointer">
                                <div className={`w-6 h-6 rounded-full bg-[#09090b] border-2 border-zinc-800 flex items-center justify-center shrink-0 group-hover:border-white/20 transition-colors ${n.color}`}>
                                    <n.icon size={12}/>
                                </div>
                                <div>
                                    <div className="text-sm font-bold text-white leading-tight mb-1 group-hover:text-lime-400 transition-colors">
                                        {n.count && <span>{n.count} </span>}
                                        {n.title}
                                    </div>
                                    <div className="text-[10px] text-zinc-500 font-medium uppercase tracking-wide">{n.time}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* ACTIVITIES */}
                <div className="mb-10">
                    <h3 className="text-white text-lg font-bold mb-6">Activities</h3>
                    <div className="space-y-5">
                        {ACTIVITIES.map((a, i) => (
                            <div key={i} className="flex items-center gap-3 group cursor-pointer">
                                <div className="relative">
                                    <img src={a.user} className="w-8 h-8 rounded-full bg-zinc-800 object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all"/>
                                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-black rounded-full flex items-center justify-center">
                                        <div className="w-1.5 h-1.5 bg-lime-400 rounded-full"></div>
                                    </div>
                                </div>
                                <div className="text-xs">
                                    <span className="text-white font-bold block mb-0.5 group-hover:text-lime-400 transition-colors">{a.title}</span>
                                    <span className="text-zinc-500 block font-medium">{a.time}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* CONTACTS */}
                <div className="mt-auto">
                    <h3 className="text-zinc-400 text-xs font-bold uppercase tracking-wider mb-6">Contacts of your managers</h3>
                    <div className="space-y-2">
                        {CONTACTS.map((c, i) => (
                            <div key={i} className={`flex items-center justify-between p-2 rounded-xl transition-all cursor-pointer group ${c.active ? 'bg-lime-400 text-black shadow-[0_0_20px_rgba(163,230,53,0.3)] scale-105' : 'hover:bg-white/5 text-zinc-400 hover:text-white'}`}>
                                <div className="flex items-center gap-3">
                                    <img src={c.img} className="w-8 h-8 rounded-full bg-zinc-800 object-cover"/>
                                    <span className="text-xs font-bold">{c.name}</span>
                                </div>
                                {c.active ? (
                                    <div className="flex gap-2 mr-2">
                                        <div className="bg-black/10 p-1.5 rounded-full"><Mail size={12}/></div>
                                        <div className="bg-black/10 p-1.5 rounded-full"><Phone size={12}/></div>
                                    </div>
                                ) : (
                                    <MoreHorizontal size={14} className="mr-2 opacity-0 group-hover:opacity-100 transition-opacity"/>
                                )}
                            </div>
                        ))}
                    </div>
                </div>

            </div>
        </div>
    );
};
