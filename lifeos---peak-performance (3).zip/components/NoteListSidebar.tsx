
import React, { useState } from 'react';
import { Note, Folder } from '../types';
import { Search, Plus, FileText, Folder as FolderIcon, Clock, Star } from 'lucide-react';

interface NoteListSidebarProps {
    notes: Note[];
    selectedNoteId: string | null;
    onSelectNote: (note: Note) => void;
    onCreateNote: () => void;
}

export const NoteListSidebar: React.FC<NoteListSidebarProps> = ({ notes, selectedNoteId, onSelectNote, onCreateNote }) => {
    const [searchTerm, setSearchTerm] = useState('');
    
    const filteredNotes = notes.filter(n => 
        n.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
        n.blocks.some(b => b.content.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    const formatLastModified = (dateString: string) => {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now.getTime() - date.getTime();
        const days = Math.floor(diff / (1000 * 3600 * 24));
        
        if (days === 0) return date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        if (days < 7) return `${days}d ago`;
        return date.toLocaleDateString();
    }

    return (
        <div className="w-80 h-full bg-[#0A0A0A] border-r border-white/5 flex flex-col relative z-30">
            {/* Header */}
            <div className="p-4 border-b border-white/5">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-black text-white tracking-tight">Archives</h2>
                    <button onClick={onCreateNote} className="p-2 bg-white text-black rounded-lg hover:scale-105 transition-transform">
                        <Plus size={16} strokeWidth={3} />
                    </button>
                </div>
                <div className="relative">
                    <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
                    <input 
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        placeholder="Search knowledge base..."
                        className="w-full bg-black/50 border border-white/10 rounded-xl py-2 pl-9 pr-3 text-sm text-white focus:border-blue-500 outline-none transition-colors"
                    />
                </div>
            </div>

            {/* Note List */}
            <div className="flex-1 overflow-y-auto no-scrollbar p-2 space-y-1">
                {filteredNotes.length === 0 ? (
                    <div className="text-center py-10 text-white/30 text-xs">No entries found.</div>
                ) : (
                    filteredNotes.map(note => {
                        const snippet = note.blocks.find(b => b.type === 'body')?.content.replace(/<[^>]*>?/gm, '').slice(0, 60) || 'No preview';
                        const isSelected = selectedNoteId === note.id;
                        
                        return (
                            <button 
                                key={note.id}
                                onClick={() => onSelectNote(note)}
                                className={`
                                    w-full text-left p-3 rounded-xl transition-all duration-200 border
                                    ${isSelected 
                                        ? 'bg-white/10 border-white/10 shadow-lg' 
                                        : 'bg-transparent border-transparent hover:bg-white/5 hover:border-white/5'}
                                `}
                            >
                                <div className="flex justify-between items-start mb-1">
                                    <h3 className={`font-bold text-sm truncate pr-2 ${isSelected ? 'text-white' : 'text-white/80'}`}>
                                        {note.title || 'Untitled Entry'}
                                    </h3>
                                    {note.pinned && <Star size={10} className="text-yellow-500 fill-yellow-500 flex-shrink-0 mt-1" />}
                                </div>
                                <p className="text-xs text-white/40 line-clamp-2 mb-2 font-medium">{snippet}</p>
                                <div className="flex items-center gap-2 text-[10px] text-white/30 font-mono">
                                    <Clock size={10} />
                                    <span>{formatLastModified(note.updatedAt)}</span>
                                </div>
                            </button>
                        )
                    })
                )}
            </div>
            
            {/* Status Bar */}
            <div className="p-3 border-t border-white/5 text-[10px] font-bold uppercase tracking-widest text-white/30 text-center">
                {filteredNotes.length} Items Indexed
            </div>
        </div>
    );
};
