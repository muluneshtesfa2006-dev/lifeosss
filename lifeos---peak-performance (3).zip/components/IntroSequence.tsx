
import React, { useState, useEffect } from 'react';
import { Zap, Fingerprint, ScanFace } from 'lucide-react';

interface IntroSequenceProps {
    onComplete: () => void;
}

export const IntroSequence: React.FC<IntroSequenceProps> = ({ onComplete }) => {
    const [progress, setProgress] = useState(0);
    const [status, setStatus] = useState("Establishing Link...");

    useEffect(() => {
        const interval = setInterval(() => {
            setProgress(prev => {
                if (prev >= 100) {
                    clearInterval(interval);
                    return 100;
                }
                return prev + 1;
            });
        }, 30);

        const statusTimers = [
            setTimeout(() => setStatus("Verifying Biometrics..."), 1000),
            setTimeout(() => setStatus("Syncing Neural Cloud..."), 2000),
            setTimeout(() => setStatus("Optimizing Interface..."), 3000),
            setTimeout(() => {
                setStatus("Access Granted.");
                setTimeout(onComplete, 800); 
            }, 3500)
        ];

        return () => {
            clearInterval(interval);
            statusTimers.forEach(clearTimeout);
        };
    }, [onComplete]);

    return (
        <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-8 cursor-wait overflow-hidden">
            {/* Ambient Background */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(168,85,247,0.1),transparent_60%)] animate-pulse-slow" />
            
            <div className="relative z-10 flex flex-col items-center gap-8 w-full max-w-xs">
                {/* Central Ring Loader */}
                <div className="relative w-32 h-32 flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full border-2 border-white/10"></div>
                    <div className="absolute inset-0 rounded-full border-2 border-primary border-t-transparent animate-spin"></div>
                    <div className="absolute inset-4 rounded-full border-2 border-primary/30 border-b-transparent animate-spin-reverse"></div>
                    
                    <div className="relative z-20 bg-primary/10 p-4 rounded-full border border-primary/20 shadow-[0_0_30px_rgba(168,85,247,0.4)] animate-pulse">
                        <Fingerprint size={32} className="text-primary" />
                    </div>
                </div>

                {/* Status Text */}
                <div className="text-center space-y-2">
                    <h2 className="text-2xl font-black tracking-tight text-white uppercase">{progress < 100 ? 'System Init' : 'Welcome'}</h2>
                    <p className="text-xs font-mono text-primary uppercase tracking-widest">{status}</p>
                </div>

                {/* Progress Bar */}
                <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                    <div 
                        className="h-full bg-primary shadow-[0_0_10px_#A855F7] transition-all duration-75 ease-out" 
                        style={{ width: `${progress}%` }}
                    />
                </div>
            </div>
        </div>
    );
};
