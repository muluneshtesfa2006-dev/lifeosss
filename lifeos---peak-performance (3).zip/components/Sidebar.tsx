
import React, { memo, useState } from 'react';
import { 
  LayoutDashboard, FileText, CheckCircle2, Target, Book, 
  Calendar as CalendarIcon, Wallet, Plus, Users,
  Folder as FolderIcon, Archive, Globe, Home, Zap, 
  Settings, ChevronRight, Hash, Bell, LogOut, Search,
  MousePointer2
} from 'lucide-react';
import { Note, Folder as FolderType } from '../types';
import { StorageService } from '../services/storageService';

interface SidebarProps {
  notes: Note[];
  folders: FolderType[];
  selectedNoteId: string | null;
  onSelectNote: (note: Note) => void;
  onCreateNote: () => void;
  isOpen: boolean;
  onCloseMobile: () => void;
  activeTab: string;
  onNavigate: (tab: any) => void;
  toggleTheme: () => void;
  isDarkMode: boolean;
  onOpenSettings: () => void;
}

export const Sidebar: React.FC<SidebarProps> = memo(({ 
  activeTab, onNavigate, onOpenSettings, isOpen, onCloseMobile, onCreateNote
}) => {
  const [isPanelOpen, setIsPanelOpen] = useState(true);
  const user = StorageService.getUser();

  const NAV_ITEMS = [
      { id: 'DASHBOARD', icon: Home, label: 'Home' },
      { id: 'CALENDAR', icon: CalendarIcon, label: 'Calendar' },
      { id: 'PLANS', icon: Target, label: 'Plans' },
      { id: 'ROUTINES', icon: CheckCircle2, label: 'Rituals' },
      { id: 'NOTES', icon: FileText, label: 'Notes' },
      { id: 'WHITEBOARD', icon: MousePointer2, label: 'Canvas' },
      { id: 'MONEY', icon: Wallet, label: 'Finance' },
  ];

  const handleRailClick = (id: string) => {
      if (activeTab === id) {
          setIsPanelOpen(!isPanelOpen);
      } else {
          onNavigate(id);
          setIsPanelOpen(true); // Ensure panel opens when switching tabs
      }
      if (window.innerWidth < 768) onCloseMobile();
  };

  return (
    <>
      {/* Mobile Overlay (Only for small screens) */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden transition-opacity"
          onClick={onCloseMobile}
        />
      )}

      {/* 
          SIDEBAR CONTAINER (IN FLOW) 
          Flex container holding Rail and Panel.
          gap-0 ensures they touch.
      */}
      <div className={`hidden md:flex h-full flex-row shrink-0 bg-[#020202] z-50 pl-4 py-4`}>
          
          {/* --- COLUMN 1: THE "RAIL" (Toolbar 1) --- */}
          {/* 
              Style: Purple to Black Gradient
              Updated: Faster transitions (duration-200)
          */}
          <aside 
            className={`
              relative flex flex-col items-center py-6 w-[60px] h-full
              bg-gradient-to-b from-[#2e1065] via-[#050505] to-[#000000]
              border border-white/10
              shadow-[0_0_40px_rgba(0,0,0,0.8)] z-[52]
              transition-all duration-200 ease-out
              ${isPanelOpen 
                  ? 'rounded-l-[32px] rounded-r-none border-r-0' 
                  : 'rounded-[32px]'}
            `}
          >
              {/* No Logo */}
              <div className="mt-2" /> 

              {/* Navigation Icons */}
              <div className="flex flex-col gap-4 w-full px-1 items-center mt-4">
                  {NAV_ITEMS.map(item => (
                      <RailIcon 
                        key={item.id} 
                        icon={item.icon} 
                        active={activeTab === item.id} 
                        onClick={() => handleRailClick(item.id)} 
                      />
                  ))}
              </div>

              {/* Spacer */}
              <div className="flex-1" />

              {/* Bottom Actions */}
              <div className="flex flex-col gap-6 items-center w-full px-1 mb-2">
                   <button onClick={onOpenSettings} className="w-10 h-10 rounded-full hover:bg-white/10 flex items-center justify-center text-white/50 hover:text-white transition-colors group">
                      <Settings size={20} className="group-hover:rotate-90 transition-transform duration-500"/>
                   </button>
                   
                   <div 
                      className="w-9 h-9 rounded-full bg-gradient-to-br from-[#333] to-black border border-white/20 cursor-pointer hover:border-white/50 transition-colors shadow-lg overflow-hidden shrink-0 relative group" 
                      onClick={onOpenSettings}
                   >
                      {user?.profilePic ? (
                          <img src={user.profilePic} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                      ) : (
                          <div className="w-full h-full flex items-center justify-center text-[10px] font-bold text-white/50">
                              {user?.name?.charAt(0) || 'U'}
                          </div>
                      )}
                   </div>
              </div>
          </aside>

          {/* --- COLUMN 2: THE PANEL (Toolbar 2 / Tools Display) --- */}
          {/* 
              Style: "Purple Cool Shiny at Edges" (Neon Dark)
              Updated: Faster transitions (duration-200)
          */}
          <div 
              className={`
                  h-full transition-all duration-200 ease-out
                  flex flex-col justify-center overflow-hidden
                  ${isPanelOpen ? 'w-[200px] opacity-100' : 'w-0 opacity-0'}
              `}
          >
              <div 
                  className={`
                    w-[200px] h-full flex flex-col py-6 pl-2 pr-4 
                    bg-[#050505] 
                    border-y border-r border-purple-500/20 
                    rounded-r-[32px] rounded-l-none 
                    relative overflow-hidden
                    shadow-[0_0_30px_rgba(168,85,247,0.1)]
                  `}
              >
                  {/* "Shiny" Top Edge Highlight */}
                  <div className="absolute inset-0 pointer-events-none rounded-r-[32px] shadow-[inset_0_1px_0_0_rgba(255,255,255,0.1)]" />
                  
                  {/* Subtle Purple Mist in Background */}
                  <div className="absolute top-0 right-0 w-full h-1/2 bg-gradient-to-b from-purple-900/10 to-transparent pointer-events-none" />

                  {/* Subtle Separator Line (The "Contact" Point) */}
                  <div className="absolute top-4 bottom-4 left-0 w-[1px] bg-white/5" />

                  {/* Header Spacer - Keeping visual balance */}
                  <div className="h-12 mb-8 pl-6 flex items-center shrink-0 relative z-10">
                      <span className="text-[10px] font-black text-purple-500/50 tracking-[0.3em] uppercase drop-shadow-md">Navigation</span>
                  </div>

                  {/* Menu Items */}
                  <div className="flex flex-col gap-1 w-full px-2 relative z-10">
                      {NAV_ITEMS.map(item => (
                          <button 
                            key={item.id}
                            onClick={() => onNavigate(item.id)}
                            className={`
                                h-12 flex items-center px-5 rounded-r-xl text-xs font-bold uppercase tracking-wider transition-all duration-200 text-left w-full
                                relative overflow-hidden group
                                ${activeTab === item.id 
                                    ? 'text-white bg-purple-500/10' 
                                    : 'text-white/30 hover:text-white hover:bg-white/5'}
                            `}
                          >
                              {/* Active Purple Indicator Bar */}
                              {activeTab === item.id && (
                                  <>
                                    <div className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-[2px] bg-purple-500 shadow-[0_0_10px_#A855F7]" />
                                    <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-transparent opacity-50" />
                                  </>
                              )}

                              <span className="relative z-10">{item.label}</span>
                          </button>
                      ))}
                  </div>

                  <div className="flex-1" />

                  {/* Footer Items */}
                  <div className="flex flex-col gap-4 w-full px-6 mb-4 relative z-10">
                        <div className="flex items-center justify-between text-[10px] font-bold text-white/20 uppercase tracking-widest hover:text-white transition-colors cursor-pointer group">
                            <span>System</span>
                            <div className="w-1.5 h-1.5 rounded-full bg-purple-600 group-hover:bg-purple-400 shadow-[0_0_8px_rgba(168,85,247,0.6)] group-hover:scale-125 transition-all" />
                        </div>
                        <div className="text-[10px] font-bold text-white/20 uppercase tracking-widest hover:text-white transition-colors cursor-pointer">
                            v4.2.0
                        </div>
                  </div>
              </div>
          </div>

      </div>
    </>
  );
});

// --- SUB COMPONENTS ---

// Updated Rail Icon: 
// 1. Reduced glow opacity (bg-purple-500/10)
// 2. Reduced blur (blur-sm)
// 3. Reduced drop-shadow intensity
// 4. Faster transition (duration-200)
const RailIcon: React.FC<{ icon: any, active?: boolean, onClick?: () => void }> = ({ icon: Icon, active, onClick }) => (
    <button 
        onClick={onClick}
        className={`
            relative w-12 h-12 flex items-center justify-center rounded-2xl transition-all duration-200 shrink-0 group
            ${active 
                ? 'text-white' 
                : 'text-white/30 hover:text-white hover:bg-white/10'}
        `}
    >
        {/* Active Background Glow (Subtler) */}
        {active && (
            <div className="absolute inset-0 bg-purple-500/10 rounded-2xl blur-sm scale-75" />
        )}

        {/* The Icon */}
        <Icon 
            size={22} 
            strokeWidth={active ? 2.5 : 2} 
            className={`
                relative z-10 transition-transform duration-200 
                ${active ? 'scale-105 drop-shadow-[0_0_5px_rgba(255,255,255,0.1)]' : 'group-hover:scale-105'}
            `} 
        />
        
        {/* Active Indicator (Vertical Bar on Left) - Purple */}
        {active && (
            <div className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-[3px] bg-purple-500 rounded-r-full shadow-[0_0_10px_rgba(168,85,247,0.4)]" />
        )}
    </button>
);
