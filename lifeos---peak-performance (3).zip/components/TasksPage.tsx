
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
    CheckSquare, Layers, Activity, 
    TrendingUp, AlertCircle, Lock,
    CheckCircle2, Target, Brain, Shield,
    ChevronRight, Zap, Database, Circle,
    Calendar, Clock, Server, Eye
} from 'lucide-react';
import { Task, Routine, RoutineLog } from '../types';
import { StorageService } from '../services/storageService';
import { 
    ResponsiveContainer, AreaChart, Area, Tooltip, CartesianGrid,
    RadialBarChart, RadialBar, BarChart, Bar, Cell, XAxis
} from 'recharts';

export const TasksPage: React.FC<{ onNavigate?: (tab: any) => void }> = ({ onNavigate }) => {
    // Data State
    const [tasks, setTasks] = useState<Task[]>([]);
    const [routines, setRoutines] = useState<Routine[]>([]);
    const [logs, setLogs] = useState<RoutineLog[]>([]);
    const [tick, setTick] = useState(0);
    
    // UI State (Scroll Spy)
    const [activeSection, setActiveSection] = useState<'DAILY' | 'WEEKLY' | 'MONTHLY'>('DAILY');
    const scrollContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        setTasks(StorageService.getTasks());
        setRoutines(StorageService.getRoutines());
        setLogs(StorageService.getLogs());
    }, [tick]);

    // Scroll Spy Logic
    useEffect(() => {
        const handleScroll = () => {
            if (!scrollContainerRef.current) return;
            const scrollPos = scrollContainerRef.current.scrollTop + 200; // Offset for trigger
            
            const daily = document.getElementById('section-daily');
            const weekly = document.getElementById('section-weekly');
            const monthly = document.getElementById('section-monthly');

            if (monthly && scrollPos >= monthly.offsetTop) {
                setActiveSection('MONTHLY');
            } else if (weekly && scrollPos >= weekly.offsetTop) {
                setActiveSection('WEEKLY');
            } else {
                setActiveSection('DAILY');
            }
        };

        const container = scrollContainerRef.current;
        if (container) {
            container.addEventListener('scroll', handleScroll);
            return () => container.removeEventListener('scroll', handleScroll);
        }
    }, []);

    const scrollToSection = (id: string) => {
        const el = document.getElementById(id);
        if (el && scrollContainerRef.current) {
            scrollContainerRef.current.scrollTo({
                top: el.offsetTop,
                behavior: 'smooth'
            });
        }
    };

    const handleToggleTask = (task: Task) => {
        const newStatus = task.completed ? 'todo' : 'done';
        const updated = tasks.map(t => t.id === task.id ? { ...t, status: newStatus, completed: !task.completed } : t);
        setTasks(updated);
        StorageService.saveTasks(updated);
        setTick(t => t + 1);
    };

    const handleToggleRoutine = (routine: Routine) => {
        const today = new Date().toISOString().split('T')[0];
        const isDone = logs.some(l => l.routineId === routine.id && l.date === today);
        let newLogs;
        if (isDone) {
            newLogs = logs.filter(l => !(l.routineId === routine.id && l.date === today));
        } else {
            newLogs = [...logs, { date: today, routineId: routine.id, completed: true }];
        }
        setLogs(newLogs);
        StorageService.saveLog({ date: today, routineId: routine.id, completed: !isDone });
        setTick(t => t + 1);
    };

    // --- DATA FILTERING ---
    const today = new Date().toISOString().split('T')[0];
    
    // Daily
    const dailyRoutines = routines.filter(r => r.frequency === 'Daily');
    const dailyTasks = tasks.filter(t => t.date === today || (!t.completed && t.date < today));

    // Weekly
    const weeklyRoutines = routines.filter(r => r.frequency === 'Weekly');
    const weeklyTasks = tasks.filter(t => isDateInCurrentWeek(t.date));
    
    // Monthly
    const monthlyRoutines = routines.filter(r => r.frequency === 'Monthly');
    const monthlyTasks = tasks.filter(t => t.date.startsWith(today.substring(0,7)));

    // --- CHART DATA ---
    const dailyChartData = useMemo(() => {
        return Array.from({length: 24}, (_, i) => ({
            name: `${i}:00`,
            value: 10 + Math.random() * 90,
        }));
    }, []);

    const weeklyBarData = useMemo(() => {
        return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => ({
            day: d,
            val: Math.floor(Math.random() * 100)
        }));
    }, []);

    const circularData = [
        { name: 'Energy', value: 85, fill: '#A855F7' },
        { name: 'Focus', value: 65, fill: '#FFFFFF' },
        { name: 'Will', value: 90, fill: '#3B82F6' },
    ];

    return (
        <div className="flex h-full w-full bg-[#020202] text-white font-sans overflow-hidden relative selection:bg-purple-500/50 selection:text-white">
            
            {/* Fixed Background Grid */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(168,85,247,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(168,85,247,0.02)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none fixed z-0"></div>

            {/* --- MAIN CONTINUOUS SCROLL CONTAINER --- */}
            {/* Added style to strictly enforce no scrollbar while keeping scroll functionality */}
            <div 
                ref={scrollContainerRef}
                className="flex-1 relative overflow-y-auto scroll-smooth pb-32 [&::-webkit-scrollbar]:hidden"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
            >
                {/* =========================================================================
                    SECTION 1: DAILY DASHBOARD
                   ========================================================================= */}
                <div id="section-daily" className="w-full flex flex-col p-8 lg:p-12 relative border-b border-white/5 bg-[#020202]">
                    
                    {/* HERO HEADER */}
                    <div className="relative w-full h-32 flex items-center justify-between px-2 mb-12 shrink-0">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse shadow-[0_0_10px_#A855F7]"></div>
                                <span className="text-[10px] font-bold text-purple-300 uppercase tracking-[0.4em]">System Active</span>
                            </div>
                            <h1 className="text-6xl font-black text-white tracking-tighter uppercase italic drop-shadow-2xl">
                                Ritual <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-purple-500">Matrix</span>
                            </h1>
                        </div>
                        <div className="text-right">
                            <span className="text-8xl font-black text-white/5 tracking-widest">01</span>
                        </div>
                    </div>

                    {/* TOP ROW: LISTS & CIRCULAR DATA */}
                    <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
                        
                        {/* LEFT: LISTS (Routines + Tasks) */}
                        <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                            {/* Routines - Auto Height */}
                            <div className="bg-[#050505] border border-white/10 rounded-3xl flex flex-col relative group hover:border-purple-500/40 transition-colors">
                                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-50"></div>
                                <div className="p-6 border-b border-white/5 bg-[#080808] flex justify-between items-center">
                                    <h3 className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-2">
                                        <Layers size={14} className="text-purple-500"/> Daily Protocols
                                    </h3>
                                    <span className="text-[10px] bg-white/5 px-2 py-1 rounded text-white/50">{dailyRoutines.length}</span>
                                </div>
                                <div className="p-4 space-y-3">
                                    {dailyRoutines.map(r => {
                                        const isDone = logs.some(l => l.routineId === r.id && l.date === today);
                                        return (
                                            <div key={r.id} onClick={() => handleToggleRoutine(r)} className={`p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-all duration-200 ${isDone ? 'bg-purple-900/10 border-purple-500/30' : 'bg-[#0A0A0A] border-white/5 hover:bg-[#111]'}`}>
                                                <span className={`text-sm font-bold ${isDone ? 'text-purple-400' : 'text-white'}`}>{r.title}</span>
                                                <div className={`w-5 h-5 rounded flex items-center justify-center border transition-all ${isDone ? 'bg-purple-500 border-purple-500' : 'border-white/20'}`}>
                                                    {isDone && <CheckCircle2 size={12} className="text-white" strokeWidth={4}/>}
                                                </div>
                                            </div>
                                        )
                                    })}
                                    {dailyRoutines.length === 0 && <div className="text-white/20 text-center text-xs py-4">No routines set</div>}
                                </div>
                            </div>

                            {/* Tasks - Auto Height */}
                            <div className="bg-[#050505] border border-white/10 rounded-3xl flex flex-col relative group hover:border-purple-500/40 transition-colors">
                                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-50"></div>
                                <div className="p-6 border-b border-white/5 bg-[#080808] flex justify-between items-center">
                                    <h3 className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-2">
                                        <CheckSquare size={14} className="text-blue-400"/> Daily Objectives
                                    </h3>
                                    <span className="text-[10px] bg-white/5 px-2 py-1 rounded text-white/50">{dailyTasks.length}</span>
                                </div>
                                <div className="p-4 space-y-3">
                                    {dailyTasks.map(t => (
                                        <div key={t.id} onClick={() => handleToggleTask(t)} className={`p-4 rounded-xl border flex items-center justify-between cursor-pointer transition-all duration-200 ${t.completed ? 'bg-white/5 border-white/20 opacity-50' : 'bg-[#0A0A0A] border-white/5 hover:bg-[#111]'}`}>
                                            <span className={`text-sm font-bold truncate ${t.completed ? 'line-through text-white/50' : 'text-white'}`}>{t.title}</span>
                                            <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${t.completed ? 'bg-white border-white' : 'border-white/20'}`}>
                                                {t.completed && <CheckCircle2 size={12} className="text-black" strokeWidth={4}/>}
                                            </div>
                                        </div>
                                    ))}
                                    {dailyTasks.length === 0 && <div className="text-white/20 text-center text-xs py-4">No active tasks</div>}
                                </div>
                            </div>
                        </div>

                        {/* RIGHT: CIRCULAR STATS (Sticky-ish) */}
                        <div className="lg:col-span-4 flex flex-col gap-6 h-full">
                            <div className="flex-1 bg-[#050505] border border-white/10 rounded-3xl p-8 relative flex flex-col items-center justify-center min-h-[300px]">
                                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent opacity-30"></div>
                                <h4 className="text-[10px] font-bold text-white/40 uppercase tracking-[0.3em] mb-4">Neural Capacity</h4>
                                
                                <div className="relative w-64 h-64">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <RadialBarChart innerRadius="40%" outerRadius="100%" data={circularData} startAngle={180} endAngle={0} barSize={20}>
                                            <RadialBar background dataKey="value" cornerRadius={10} />
                                            <Tooltip contentStyle={{background:'#000', border:'1px solid #333', borderRadius:'8px'}}/>
                                        </RadialBarChart>
                                    </ResponsiveContainer>
                                    <div className="absolute inset-0 flex flex-col items-center justify-center mt-10">
                                        <span className="text-5xl font-black text-white">85%</span>
                                        <span className="text-[10px] text-white/30 uppercase tracking-widest">Efficiency</span>
                                    </div>
                                </div>

                                <div className="flex gap-6 mt-8">
                                    {circularData.map(d => (
                                        <div key={d.name} className="flex flex-col items-center">
                                            <div className="w-2 h-2 rounded-full mb-2" style={{backgroundColor: d.fill}}></div>
                                            <span className="text-[9px] font-bold text-white/40 uppercase">{d.name}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className="h-40 grid grid-cols-2 gap-4">
                                <div className="bg-[#080808] border border-white/5 rounded-2xl flex flex-col items-center justify-center hover:border-purple-500/30 transition-colors">
                                    <Activity size={24} className="text-purple-500 mb-2" />
                                    <span className="text-3xl font-black text-white">4.2h</span>
                                    <span className="text-[9px] text-white/30 uppercase tracking-widest">Deep Work</span>
                                </div>
                                <div className="bg-[#080808] border border-white/5 rounded-2xl flex flex-col items-center justify-center hover:border-white/20 transition-colors">
                                    <Zap size={24} className="text-white mb-2" />
                                    <span className="text-3xl font-black text-white">12</span>
                                    <span className="text-[9px] text-white/30 uppercase tracking-widest">Streak</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* BOTTOM: SYSTEM GRAPH (Full Width) */}
                    <div className="h-64 w-full bg-[#050505] rounded-3xl border border-white/10 p-1 relative overflow-hidden group hover:border-purple-500/30 transition-colors mt-4">
                        <div className="absolute top-6 left-6 z-10">
                            <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest bg-black/50 px-3 py-1.5 rounded backdrop-blur-md border border-white/5">System Sync</span>
                        </div>
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(168,85,247,0.1),transparent_50%)]"></div>
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={dailyChartData}>
                                <defs>
                                    <linearGradient id="glowColor" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#A855F7" stopOpacity={0.5}/><stop offset="95%" stopColor="#A855F7" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                                <Area type="monotone" dataKey="value" stroke="#A855F7" strokeWidth={3} fill="url(#glowColor)" />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* =========================================================================
                    SECTION 2: WEEKLY SYNTHESIS (Mechanical Dashboard Look)
                   ========================================================================= */}
                <div id="section-weekly" className="w-full flex flex-col p-8 lg:p-12 bg-[#030303] relative border-b border-white/5 overflow-hidden">
                    
                    {/* Background Gears/Tech Animation */}
                    <div className="absolute right-0 top-0 w-[800px] h-[800px] opacity-[0.02] pointer-events-none animate-spin-slow origin-center">
                        <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-white">
                            <path d="M50 50 m-40 0 a 40 40 0 1 0 80 0 a 40 40 0 1 0 -80 0" strokeDasharray="5,5" />
                            <path d="M50 50 m-30 0 a 30 30 0 1 0 60 0 a 30 30 0 1 0 -60 0" />
                            <circle cx="50" cy="50" r="10" />
                            <path d="M50 10 L50 90 M10 50 L90 50" />
                        </svg>
                    </div>

                    <div className="mb-12 flex justify-between items-end relative z-10">
                        <div>
                            <h2 className="text-6xl font-black text-white uppercase tracking-tighter mb-2">Weekly Synthesis</h2>
                            <div className="h-1 w-32 bg-purple-600 shadow-[0_0_20px_#A855F7]"></div>
                        </div>
                        <span className="text-8xl font-black text-white/5 tracking-widest">02</span>
                    </div>

                    <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-8 relative z-10">
                        {/* Weekly Protocols List - Auto Height */}
                        <div className="bg-[#0A0A0A] border border-white/10 rounded-3xl p-8 flex flex-col shadow-2xl h-auto">
                            <div className="flex justify-between items-center mb-8">
                                <h3 className="text-sm font-bold text-white/50 uppercase tracking-widest">Weekly Objectives</h3>
                                <div className="flex gap-2">
                                    <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse"></div>
                                    <div className="w-2 h-2 rounded-full bg-white/20"></div>
                                </div>
                            </div>
                            <div className="space-y-3">
                                {weeklyRoutines.map(r => (
                                    <div key={r.id} className="p-5 bg-[#111] rounded-2xl border border-white/5 flex items-center justify-between group hover:border-purple-500/30 transition-all hover:translate-x-1">
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-xl bg-purple-900/10 flex items-center justify-center text-purple-500 group-hover:scale-110 transition-transform">
                                                <Layers size={20} />
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-white text-lg">{r.title}</h4>
                                                <p className="text-[10px] text-white/30 uppercase tracking-wider">{r.time} • {r.frequency}</p>
                                            </div>
                                        </div>
                                        <div className="w-6 h-6 rounded-full border-2 border-white/10 group-hover:border-purple-500 transition-colors"></div>
                                    </div>
                                ))}
                                {weeklyTasks.map(t => (
                                    <div key={t.id} className="p-5 bg-[#111] rounded-2xl border border-white/5 flex items-center justify-between group hover:border-white/20 transition-all hover:translate-x-1">
                                        <div className="flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                                                <Target size={20} />
                                            </div>
                                            <div>
                                                <h4 className="font-bold text-white text-lg">{t.title}</h4>
                                                <p className="text-[10px] text-white/30 uppercase tracking-wider">Due this week</p>
                                            </div>
                                        </div>
                                        <div className={`w-6 h-6 rounded-sm border-2 flex items-center justify-center ${t.completed ? 'bg-white border-white' : 'border-white/10'}`}>
                                            {t.completed && <CheckCircle2 size={14} className="text-black"/>}
                                        </div>
                                    </div>
                                ))}
                                {weeklyRoutines.length === 0 && weeklyTasks.length === 0 && (
                                    <div className="text-center py-10 text-white/20 text-xs">No weekly items</div>
                                )}
                            </div>
                        </div>

                        {/* Weekly Graphs & Stats */}
                        <div className="flex flex-col gap-8">
                            <div className="bg-[#0A0A0A] border border-white/10 rounded-3xl p-8 relative overflow-hidden flex flex-col h-[300px]">
                                <h3 className="text-sm font-bold text-white/50 uppercase tracking-widest mb-6">Output Velocity</h3>
                                <div className="flex-1 w-full relative">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={weeklyBarData}>
                                            <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                                            <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#666', fontSize: 12, fontWeight:'bold'}} />
                                            <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} content={<></>} />
                                            <Bar dataKey="val" radius={[4, 4, 0, 0]}>
                                                {weeklyBarData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={index === 6 ? '#A855F7' : '#333'} />
                                                ))}
                                            </Bar>
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>
                            
                            <div className="h-40 bg-[#0A0A0A] border border-white/10 rounded-3xl p-8 flex items-center justify-between shadow-2xl">
                                <div>
                                    <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-2">Completion Status</div>
                                    <div className="text-5xl font-black text-white">78%</div>
                                </div>
                                <div className="w-48 h-3 bg-white/10 rounded-full overflow-hidden">
                                    <div className="h-full bg-purple-500 w-[78%] shadow-[0_0_20px_#A855F7] animate-pulse"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* =========================================================================
                    SECTION 3: MONTHLY VISION (Macro Summary & Tools)
                   ========================================================================= */}
                <div id="section-monthly" className="w-full flex flex-col p-8 lg:p-12 bg-[#020202] relative">
                    
                    <div className="mb-12 flex justify-between items-end">
                        <div>
                            <h2 className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-b from-white to-purple-900 tracking-tighter uppercase mb-2">Macro Vision</h2>
                            <p className="text-purple-500 text-xs font-mono uppercase tracking-[0.5em]">Monthly Ritual Summary</p>
                        </div>
                        <span className="text-8xl font-black text-white/5 tracking-widest">03</span>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-1">
                        
                        {/* MONTHLY MILESTONES (Col 8) */}
                        <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6 auto-rows-min">
                            {monthlyRoutines.map(r => (
                                <div key={r.id} className="bg-[#080808] border border-white/5 rounded-3xl p-8 hover:border-purple-500/30 transition-all group flex flex-col justify-between h-80 relative overflow-hidden">
                                    <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
                                        <Target size={100} className="text-white"/>
                                    </div>
                                    
                                    <div className="relative z-10">
                                        <span className="inline-block px-3 py-1 rounded-full bg-purple-900/20 border border-purple-500/30 text-purple-400 text-[10px] font-bold uppercase tracking-widest mb-4">
                                            Monthly Protocol
                                        </span>
                                        <h3 className="text-3xl font-black text-white mb-2">{r.title}</h3>
                                        <p className="text-white/40 text-sm leading-relaxed">{r.description || "High impact monthly review session."}</p>
                                    </div>

                                    <button className="w-full py-4 bg-white/5 hover:bg-white/10 border border-white/5 text-white font-bold uppercase tracking-widest text-xs rounded-xl transition-all flex items-center justify-center gap-2 group/btn">
                                        Initialize <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform"/>
                                    </button>
                                </div>
                            ))}
                            
                            {/* Filler Card */}
                            <div className="bg-[#080808] border border-white/5 rounded-3xl p-8 flex flex-col items-center justify-center text-center opacity-50 hover:opacity-100 transition-opacity h-80 border-dashed">
                                <Shield size={48} className="text-white/20 mb-4"/>
                                <h3 className="text-xl font-bold text-white mb-2">Strategy Review</h3>
                                <p className="text-white/40 text-xs uppercase tracking-widest">Scheduled for 1st of Month</p>
                            </div>
                        </div>

                        {/* STRATEGIC TOOLS (Col 4) */}
                        <div className="lg:col-span-4 flex flex-col gap-6">
                            <h3 className="text-xs font-bold text-white/30 uppercase tracking-[0.2em] mb-2">Strategic Tools</h3>
                            
                            <div className="bg-[#0E0E0E] border border-white/10 rounded-3xl p-6 hover:border-purple-500/30 transition-all group flex items-center gap-5 cursor-pointer h-32">
                                <div className="w-16 h-16 rounded-2xl bg-purple-900/20 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(168,85,247,0.1)]">
                                    <Target size={32} />
                                </div>
                                <div>
                                    <h4 className="font-bold text-white text-xl">Strategy Board</h4>
                                    <p className="text-[10px] text-white/40 uppercase tracking-wider mt-1">Visual Planning</p>
                                </div>
                            </div>

                            <div className="bg-[#0E0E0E] border border-white/10 rounded-3xl p-6 hover:border-blue-500/30 transition-all group flex items-center gap-5 cursor-pointer h-32">
                                <div className="w-16 h-16 rounded-2xl bg-blue-900/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(59,130,246,0.1)]">
                                    <Database size={32} />
                                </div>
                                <div>
                                    <h4 className="font-bold text-white text-xl">Data Vault</h4>
                                    <p className="text-[10px] text-white/40 uppercase tracking-wider mt-1">Archives</p>
                                </div>
                            </div>

                            <div className="bg-[#0E0E0E] border border-white/10 rounded-3xl p-6 hover:border-green-500/30 transition-all group flex items-center gap-5 cursor-pointer h-32">
                                <div className="w-16 h-16 rounded-2xl bg-green-900/20 flex items-center justify-center text-green-400 group-hover:scale-110 transition-transform shadow-[0_0_20px_rgba(34,197,94,0.1)]">
                                    <Server size={32} />
                                </div>
                                <div>
                                    <h4 className="font-bold text-white text-xl">System Audit</h4>
                                    <p className="text-[10px] text-white/40 uppercase tracking-wider mt-1">Optimization</p>
                                </div>
                            </div>
                            
                            <div className="flex-1 bg-[#0A0A0A] border border-white/5 rounded-3xl flex items-center justify-center text-white/20 hover:text-white/50 transition-colors cursor-pointer border-dashed min-h-[128px]">
                                <Eye size={32}/>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer Spacer */}
                <div className="h-32 bg-[#020202]"></div>
            </div>

            {/* --- RIGHT SIDE NAVIGATION SIDEBAR (ANCHOR NAV) --- */}
            <div className="w-32 relative z-50 bg-[#050505] border-l border-white/5 flex flex-col justify-center items-center shadow-[-20px_0_60px_rgba(0,0,0,0.9)]">
                {/* Decoration Line */}
                <div className="absolute inset-y-0 left-0 w-[1px] bg-gradient-to-b from-transparent via-purple-500/20 to-transparent"></div>

                <div className="flex flex-col gap-0 w-full">
                    <NavBtn label="DAILY" active={activeSection === 'DAILY'} onClick={() => scrollToSection('section-daily')} />
                    <NavBtn label="WEEKLY" active={activeSection === 'WEEKLY'} onClick={() => scrollToSection('section-weekly')} />
                    <NavBtn label="MONTHLY" active={activeSection === 'MONTHLY'} onClick={() => scrollToSection('section-monthly')} />
                </div>
            </div>
        </div>
    )
}

// --- SUB-COMPONENTS ---

const NavBtn: React.FC<{ label: string, active: boolean, onClick: () => void }> = ({ label, active, onClick }) => (
    <button 
        onClick={onClick}
        className={`
            relative w-full h-48 flex items-center justify-center transition-all duration-500 group overflow-hidden
            ${active ? 'bg-purple-900/5' : 'hover:bg-white/5'}
        `}
    >
        {/* Active Indicator Line */}
        <div className={`absolute right-0 top-1/2 -translate-y-1/2 h-12 w-1 bg-purple-500 shadow-[0_0_15px_#A855F7] rounded-l-full transition-all duration-500 ${active ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}`} />
        
        {/* Text */}
        <span 
            className={`
                text-xs font-black tracking-[0.3em] transition-all duration-500 
                [writing-mode:vertical-rl] rotate-180
                ${active 
                    ? 'text-white drop-shadow-[0_0_10px_rgba(168,85,247,0.8)] scale-110' 
                    : 'text-white/20 group-hover:text-white/60'}
            `}
        >
            {label}
        </span>
    </button>
)

// Helper functions for date logic
function getWeekStart() {
    const d = new Date();
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    const start = new Date(d.setDate(diff));
    return start.toISOString().split('T')[0];
}

function isDateInCurrentWeek(dateStr: string) {
    const d = new Date(dateStr);
    const now = new Date();
    const start = new Date(now.setDate(now.getDate() - now.getDay()));
    const end = new Date(now.setDate(now.getDate() + 6));
    return d >= start && d <= end;
}
