
import React, { useState, useEffect } from 'react';
import { Mail, Lock, ArrowRight, Github, Chrome, Zap, ScanFace, FastForward } from 'lucide-react';
import { StorageService } from '../services/storageService';

interface LoginProps {
    onLogin: () => void;
    onSignup: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin, onSignup }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [scanActive, setScanActive] = useState(false);

    useEffect(() => {
        // Subtle ambient animation logic could go here
    }, []);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setScanActive(true);
        
        setTimeout(() => {
            setIsLoading(false);
            setScanActive(false);
            onLogin();
        }, 2000);
    };

    const handleSkip = () => {
        setIsLoading(true);
        const dummyUser = {
            name: "Guest Architect",
            email: "guest@lifeos.ai",
            age: "25",
            birthDate: "1999-01-01",
            mainGoal: "System Optimization",
            obstacle: "Time Management",
            onboarded: true
        };
        StorageService.saveUser(dummyUser);
        
        // Ensure storage is seeded if it's a first run
        StorageService.seedData();
        
        setTimeout(() => {
            setIsLoading(false);
            onLogin();
        }, 1500);
    };

    return (
        <div className="fixed inset-0 bg-[#020202] flex items-center justify-center p-4 overflow-hidden font-sans">
            {/* Cinematic Background */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#1a0b2e_0%,_#000000_100%)] animate-pulse-slow pointer-events-none opacity-60" />
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-purple-500/30 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />
            
            {/* Stars / Dust */}
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-10 animate-float-slow pointer-events-none"></div>

            {/* Login Portal Card */}
            <div className="relative w-full max-w-md bg-[#050505]/80 backdrop-blur-2xl border border-white/5 rounded-[3rem] p-8 md:p-12 shadow-[0_0_100px_rgba(168,85,247,0.1)] animate-in zoom-in-95 duration-1000 overflow-hidden group hover:border-ios-purple/20 transition-colors">
                
                {/* Scanner Effect */}
                {scanActive && (
                    <div className="absolute top-0 left-0 right-0 h-1 bg-green-500/80 shadow-[0_0_20px_#22c55e] z-50 animate-[scan_2s_ease-in-out_infinite]" />
                )}

                <div className="flex flex-col items-center mb-12 text-center">
                    <div className="w-20 h-20 bg-gradient-to-br from-[#2e1065] to-black rounded-3xl flex items-center justify-center shadow-[0_0_40px_rgba(168,85,247,0.3)] mb-8 border border-white/10 relative">
                        <div className="absolute inset-0 bg-white/20 rounded-3xl animate-pulse-slow"></div>
                        <Zap className="text-white fill-white relative z-10" size={36} />
                    </div>
                    <h2 className="text-4xl font-black text-white tracking-tighter mb-2">LifeOS <span className="text-purple-500">Gateway</span></h2>
                    <p className="text-white/40 text-xs uppercase tracking-[0.2em] font-medium">Secure Neural Link Required</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
                    <div className="space-y-4">
                        <div className="relative group/input">
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                placeholder="IDENTITY (EMAIL)"
                                className="w-full bg-white/5 border border-white/5 rounded-2xl py-5 px-6 text-white placeholder-white/20 outline-none focus:border-purple-500/50 focus:bg-white/10 transition-all font-mono text-sm tracking-wide"
                            />
                        </div>
                        <div className="relative group/input">
                            <input 
                                type="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="ACCESS KEY (PASSWORD)"
                                className="w-full bg-white/5 border border-white/5 rounded-2xl py-5 px-6 text-white placeholder-white/20 outline-none focus:border-purple-500/50 focus:bg-white/10 transition-all font-mono text-sm tracking-wide"
                            />
                        </div>
                    </div>

                    <button 
                        type="submit"
                        disabled={isLoading}
                        className="w-full bg-white text-black font-black text-sm uppercase tracking-widest py-5 rounded-2xl hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_30px_rgba(255,255,255,0.2)] flex items-center justify-center gap-3 relative overflow-hidden group/btn hover:shadow-[0_0_40px_rgba(168,85,247,0.4)]"
                    >
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-black/10 to-transparent -translate-x-full group-hover/btn:animate-shine transition-all"/>
                        {isLoading ? (
                            <span className="flex items-center gap-2">VERIFYING <ScanFace size={16} className="animate-pulse"/></span>
                        ) : (
                            <>INITIALIZE <ArrowRight size={16} /></>
                        )}
                    </button>
                </form>

                <div className="flex flex-col gap-4 mt-8 pt-8 border-t border-white/5 items-center relative z-20">
                    <button 
                        onClick={handleSkip}
                        className="text-[10px] font-bold text-white/40 hover:text-white uppercase tracking-widest transition-colors flex items-center gap-2 group p-2 hover:bg-white/5 rounded-lg"
                    >
                        {isLoading ? (
                            <span className="animate-pulse">Simulating Neural Link...</span>
                        ) : (
                            <><FastForward size={14} className="group-hover:text-purple-500 transition-colors" /> Skip & Simulate Data</>
                        )}
                    </button>
                    <div className="flex w-full justify-between">
                        <span className="text-[10px] font-bold text-white/30 uppercase tracking-widest">System v4.2</span>
                        <button className="text-[10px] font-bold text-white/50 hover:text-white uppercase tracking-widest transition-colors">Recover Key</button>
                    </div>
                </div>
            </div>
        </div>
    );
};
